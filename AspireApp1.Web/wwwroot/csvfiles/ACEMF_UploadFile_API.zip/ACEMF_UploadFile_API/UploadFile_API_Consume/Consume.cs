﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UploadFile_API_Consume
{
    public class Consume
    {
        public string API_Url { get; set; }

        public bool isUpload()
    }
}
