﻿using ICSharpCode.SharpZipLib.Zip;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Web;

namespace ACEMF_UploadFile_API.Models
{
    public class Validator
    {
        private string[] Conn_Strings = new string[] { "Provider=Microsoft.Jet.OLEDB.4.0;Data Source = {0};Extended Properties=dBASE IV;", "Provider=Microsoft.Jet.OLEDB.12.0;Data Source = {0};Extended Properties=dBASE IV;", "Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0}; Extended Properties=\"Excel 8.0;HDR=YES; IMEX=1;\"", "Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0}; Extended Properties=\"Excel 12.0;HDR=YES;IMEX=1;\"", "Driver=Microsoft dBase Driver (*.dbf);SourceType=DBF;SourceDB={0};Exclusive=No; Collate=Machine;NULL=NO;DELETED=NO;BACKGROUNDFETCH=NO;", "Provider=Microsoft.Jet.OLEDB.4.0; Data Source = {0};Extended Properties =\"dBase III;\"", "Provider=VFPOLEDB.1; Data Source = {0};Extended Properties =\"dBase III;HDR=YES;\"" };

        public OleDbConnection GetOLEBDConnObject(string filepath)
        {
            OleDbConnection objConn = null;
            foreach (string strConn in Conn_Strings)
            {
                try
                {
                    objConn = new OleDbConnection(string.Format(strConn, filepath));
                    objConn.Open();
                    break;
                }
                catch (Exception) { }
            }
            return objConn;
        }
        public bool isXls(string filepath)
        {
            try
            {
                string connectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + filepath + ";Extended Properties=\"Excel 8.0;HDR=Yes;\"";
                using (OleDbConnection oleDbConnection = new OleDbConnection())
                {
                    DataTable dt = new DataTable();
                    oleDbConnection.ConnectionString = connectionString;
                    oleDbConnection.Open();
                    DataTable columnDetails = oleDbConnection.GetOleDbSchemaTable(System.Data.OleDb.OleDbSchemaGuid.Columns, null);
                    var rows = columnDetails.Rows.Cast<DataRow>();
                    var query = (from r in rows group r by r["Table_Name"] into results select new { results.Key, count = results.Count() });
                    var activeSheets = (from sheet in query select sheet.Key).ToList();
                    string Sheet1 = activeSheets[0].ToString();
                    string queryStr = "SELECT TOP 1 * FROM [" + Sheet1 + "]";
                    OleDbDataAdapter da = new OleDbDataAdapter(queryStr, oleDbConnection);
                    da.Fill(dt);
                    da.Dispose();
                    oleDbConnection.Close();
                }
                return true;
            }
            catch (Exception err)
            {
                HttpContext con = HttpContext.Current;
                Common.createfile(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.ToString() + " Method Name : " + System.Reflection.MethodBase.GetCurrentMethod().ToString(), con.Request.Url.ToString(), err.Message.ToString(), err.GetType().ToString(), "");
                return false;
            }
        }
        public bool isXlsx(string filepath)
        {
            try
            {
                string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filepath + "; Extended Properties=\"Excel 12.0;HDR=YES;IMEX=1;\"";
                using (OleDbConnection oleDbConnection = new OleDbConnection())
                {
                    DataTable dt = new DataTable();
                    oleDbConnection.ConnectionString = connectionString;
                    oleDbConnection.Open();
                    DataTable columnDetails = oleDbConnection.GetOleDbSchemaTable(System.Data.OleDb.OleDbSchemaGuid.Columns, null);
                    var rows = columnDetails.Rows.Cast<DataRow>();
                    var query = (from r in rows group r by r["Table_Name"] into results select new { results.Key, count = results.Count() });
                    var activeSheets = (from sheet in query select sheet.Key).ToList();
                    string Sheet1 = activeSheets[0].ToString();
                    string queryStr = "SELECT TOP 1 * FROM [" + Sheet1 + "]";
                    OleDbDataAdapter da = new OleDbDataAdapter(queryStr, oleDbConnection);
                    da.Fill(dt);
                    da.Dispose();
                    oleDbConnection.Close();
                }
                return true;
            }
            catch (Exception err)
            {
                HttpContext con = HttpContext.Current;
                Common.createfile(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.ToString() + " Method Name : " + System.Reflection.MethodBase.GetCurrentMethod().ToString(), con.Request.Url.ToString(), err.Message.ToString(), err.GetType().ToString(), "");
                return false;
            }
        }
        public bool isDbf(string filepath)
        {
            try
            {
                DataTable dt = new DataTable();
                OleDbConnection conn = GetOLEBDConnObject(filepath);
                string queryStr = "SELECT TOP 1 * FROM " + Path.GetFileName(filepath) + " ORDER BY 1";
                OleDbDataAdapter da = new OleDbDataAdapter(queryStr, conn);
                da.Fill(dt); return true;
            }
            catch (Exception err)
            {
                HttpContext con = HttpContext.Current;
                Common.createfile(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.ToString() + " Method Name : " + System.Reflection.MethodBase.GetCurrentMethod().ToString(), con.Request.Url.ToString(), err.Message.ToString(), err.GetType().ToString(), "");
                return false;
            }
        }
        public bool IsZip(string filepath, string uniqueZipPath)
        {
            try
            {
                DirectoryInfo dir = new DirectoryInfo(filepath);
                string fullpath = dir.Parent.FullName + @"/ZipFiles/" + uniqueZipPath;
                if (!Directory.Exists(fullpath))
                {
                    Directory.CreateDirectory(fullpath);
                }
                using (ZipInputStream s = new ZipInputStream(File.OpenRead(filepath)))
                {
                    ZipEntry theEntry;
                    int totalByte = 0;
                    while ((theEntry = s.GetNextEntry()) != null)
                    {
                        if (theEntry.Name != String.Empty)
                        {
                            string Ext = Path.GetExtension(theEntry.Name);
                            bool pass=false;
                            if (Ext.ToLower() == ".dbf")
                            {
                                pass = true;
                            }
                            if (Ext.ToLower() == ".xls" && !pass)
                            {
                                pass = true;
                            }
                            if (Ext.ToLower() == ".xlsx" && !pass)
                            {
                                pass = true;
                            }
                            using (FileStream streamWriter = File.Create(fullpath + @"\" + theEntry.Name))
                            {
                                totalByte = (int)theEntry.Size;
                                int size = 2048;
                                byte[] data = new byte[2048];
                                while (true)
                                {
                                    size = s.Read(data, 0, data.Length);
                                    if (size > 0)
                                    {
                                        streamWriter.Write(data, 0, size);
                                        totalByte += size;
                                    }
                                    else
                                    {
                                        break;
                                    }
                                }
                                streamWriter.Close();
                            }
                            if (Ext.ToLower() == ".dbf")
                            {
                                return isDbf(fullpath + @"\" + theEntry.Name);
                            }
                            if (Ext.ToLower() == ".xls")
                            {
                                return isXls(fullpath + @"\" + theEntry.Name);
                            }
                            if (Ext.ToLower() == ".xlsx")
                            {
                                return isXlsx(fullpath + @"\" + theEntry.Name);
                            }
                        }
                    }
                }
                return true;
            }
            catch (Exception err)
            {
                HttpContext con = HttpContext.Current;
                Common.createfile(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.ToString() + " Method Name : " + System.Reflection.MethodBase.GetCurrentMethod().ToString(), con.Request.Url.ToString(), err.Message.ToString(), err.GetType().ToString(), "");
                return false;
            }
        }
    }
}