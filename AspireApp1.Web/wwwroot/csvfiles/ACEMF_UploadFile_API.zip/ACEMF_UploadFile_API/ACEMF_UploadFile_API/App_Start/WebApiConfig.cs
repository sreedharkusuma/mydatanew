﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;

namespace ACEMF_UploadFile_API
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            // Web API configuration and services
            config.EnableCors();
            // Web API routes
            config.MapHttpAttributeRoutes();
            
            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );
            config.Routes.MapHttpRoute(
              name: "checkfile/sanitizefile",
              routeTemplate: "api/{controller}/{clientname}/{filename}",
              defaults: new { id = RouteParameter.Optional }
            );
        }
    }
}
