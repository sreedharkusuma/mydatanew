﻿using System.Web;
using System.Web.Mvc;

namespace ACEMF_UploadFile_API
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
