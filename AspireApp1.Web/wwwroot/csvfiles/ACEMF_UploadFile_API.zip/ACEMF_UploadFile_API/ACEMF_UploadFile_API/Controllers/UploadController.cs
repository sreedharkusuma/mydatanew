﻿using ACEMF_UploadFile_API.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Web.Http.Cors;
using Excel = Microsoft.Office.Interop.Excel;
namespace ACEMF_UploadFile_API.Controllers
{
    public class UploadController : ApiController
    {
        private string[] Conn_Strings = new string[] { "Provider=Microsoft.Jet.OLEDB.4.0;Data Source = {0};Extended Properties=dBASE IV;", "Provider=Microsoft.Jet.OLEDB.12.0;Data Source = {0};Extended Properties=dBASE IV;", "Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0}; Extended Properties=\"Excel 8.0;HDR=YES; IMEX=1;\"", "Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0}; Extended Properties=\"Excel 12.0;HDR=YES;IMEX=1;\"", "Driver=Microsoft dBase Driver (*.dbf);SourceType=DBF;SourceDB={0};Exclusive=No; Collate=Machine;NULL=NO;DELETED=NO;BACKGROUNDFETCH=NO;", "Provider=Microsoft.Jet.OLEDB.4.0; Data Source = {0};Extended Properties =\"dBase III;\"", "Provider=VFPOLEDB.1; Data Source = {0};Extended Properties =\"dBase III;HDR=YES;\"" };

        //[EnableCors(origins: "http://localhost:51348/", headers: "*", methods: "*")]
        [HttpPost]
        [Route("api/Upload/proceed")]
        public HttpResponseMessage proceed()
        {
            try
            {
                var httpRequest = HttpContext.Current.Request;

                string requestfoldername = httpRequest.Form["clientname"].ToString();
                string path = HttpContext.Current.Server.MapPath("~/Uploads/" + requestfoldername + "/");
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }
                if (httpRequest.Files.Count > 0)
                {
                    HttpPostedFile postedFile = httpRequest.Files[0];
                    //string ss = httpRequest.Form["clientname"].ToString();
                    string ext = Path.GetExtension(postedFile.FileName);
                    if (ext.ToLower() == ".xls"
                        || ext.ToLower() == ".xlsx"
                        || ext.ToLower() == ".zip"
                        || ext.ToLower() == ".dbf"
                        || ext.ToLower() == ".csv"
                        )
                    {
                        string fileName = httpRequest.Form["filename"].ToString() + Path.GetExtension(postedFile.FileName);
                        postedFile.SaveAs(path + fileName);
                        /*string mimeType = "application/vnd.ms-excel";
                        string ext___ = System.IO.Path.GetExtension(fileName).ToLower();
                        Microsoft.Win32.RegistryKey regKey = Microsoft.Win32.Registry.ClassesRoot.OpenSubKey(ext___);
                        if (regKey != null && regKey.GetValue("Content Type") != null)
                            mimeType = regKey.GetValue("Content Type").ToString();*/
                        return Request.CreateResponse(HttpStatusCode.OK, fileName);
                    }
                    else
                    {
                        return Request.CreateResponse(HttpStatusCode.Forbidden);
                    }
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.BadRequest);
                }
            }
            catch (Exception err)
            {
                HttpContext con = HttpContext.Current;
                Common.createfile(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.ToString() + " Method Name : " + System.Reflection.MethodBase.GetCurrentMethod().ToString(), con.Request.Url.ToString(), err.Message.ToString(), err.GetType().ToString(), "");
                return Request.CreateResponse(HttpStatusCode.BadRequest);
                // value = string.Empty;
            }
        }

        [HttpGet]
        [Route("api/Upload/checkfile/{clientname}/{filename}/{ext}")]
        public void checkfile(string clientname, string filename, string ext)
        {
            string value = "";
            try
            {
                string requestfoldername = clientname;
                string path = HttpContext.Current.Server.MapPath("~/Uploads/" + requestfoldername + @"/" + filename + "." + ext);
                if (File.Exists(path))
                {
                    var scanner = new AntiVirus.Scanner();
                    var result = scanner.ScanAndClean(path);
                    if (result == AntiVirus.ScanResult.VirusNotFound)
                    {
                        value = "exists";
                    }
                    else
                    {
                        value = "virus";
                    }
                }
                else
                {
                    value = "notexists";
                }
            }
            catch (Exception err)
            {
                HttpContext con = HttpContext.Current;
                Common.createfile(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.ToString() + " Method Name : " + System.Reflection.MethodBase.GetCurrentMethod().ToString(), con.Request.Url.ToString(), err.Message.ToString(), err.GetType().ToString(), "");
                value = string.Empty;
            }
            HttpContext.Current.Response.Write(value);
            HttpContext.Current.Response.End();
        }
        public OleDbConnection GetOLEBDConnObject(string filepath)
        {
            OleDbConnection objConn = null;
            foreach (string strConn in Conn_Strings)
            {
                try
                {
                    objConn = new OleDbConnection(string.Format(strConn, filepath));
                    objConn.Open();
                    break;
                }
                catch (Exception) { }
            }
            return objConn;
        }
        [HttpGet]
        [Route("api/Upload/sanitizefile/{clientname}/{filename}/{ext}")]
        public void sanitizefile(string clientname, string filename, string ext)
        {
            string value = "";
            try
            {
                string requestfoldername = clientname;
                string path = HttpContext.Current.Server.MapPath("~/Uploads/" + requestfoldername + @"/" + filename + "." + ext);
                if (File.Exists(path))
                {
                    DataTable dt = new DataTable();
                    var scanner = new AntiVirus.Scanner();
                    var result = scanner.ScanAndClean(path);
                    if (result == AntiVirus.ScanResult.VirusNotFound)
                    {
                        Validator validator = new Validator();
                        if (ext.ToLower() == "xls")
                        {
                            value = (validator.isXls(path)) ? "valid" : "notvalid";
                        }
                        else if (ext.ToLower() == "xlsx")
                        {
                            value = (validator.isXlsx(path)) ? "valid" : "notvalid";
                        }
                        else if (ext.ToLower() == "dbf")
                        {
                            value = (validator.isDbf(path)) ? "valid" : "notvalid";
                        }
                        else if (ext.ToLower() == "zip")
                        {
                            string uniqueZipPath = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss.fff", System.Globalization.CultureInfo.InvariantCulture).Replace("-", "").Replace(":", "").Replace(".", "").Replace(" ", "");
                            value = (validator.IsZip(path, uniqueZipPath)) ? "valid" : "notvalid";
                        }
                    }
                    else
                    {
                        value = "virus";
                    }
                }
                else
                {
                    value = "notexists";
                }
            }
            catch (Exception err)
            {
                HttpContext con = HttpContext.Current;
                Common.createfile(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.ToString() + " Method Name : " + System.Reflection.MethodBase.GetCurrentMethod().ToString(), con.Request.Url.ToString(), err.Message.ToString(), err.GetType().ToString(), "");
                value = string.Empty;
            }
            HttpContext.Current.Response.Write(value);
            HttpContext.Current.Response.End();
        }
        [HttpGet]
        [Route("api/Upload/sanitizefile_old/{clientname}/{filename}/{ext}")]
        public void sanitizefile_old(string clientname, string filename, string ext)
        {
            string value = "";
            try
            {
                string requestfoldername = clientname;
                string path = HttpContext.Current.Server.MapPath("~/Uploads/" + requestfoldername + @"/" + filename + "." + ext);
                if (File.Exists(path))
                {
                    DataTable dt = new DataTable();
                    var scanner = new AntiVirus.Scanner();
                    var result = scanner.ScanAndClean(path);
                    if (result == AntiVirus.ScanResult.VirusNotFound)
                    {
                        if (ext.ToLower() == "xls" || ext.ToLower() == "xlsx" || ext.ToLower() == "csv")
                        {


                            try
                            {
                                string connectionString = (ext.ToLower() == "xls" ? @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties=\"Excel 8.0;HDR=Yes;\"" : "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + "; Extended Properties=\"Excel 12.0;HDR=YES;IMEX=1;\"");
                                bool iscsv = false;
                                string filenameUnique = "";
                                if (ext.ToLower() == "csv")
                                {
                                    iscsv = true;
                                    filenameUnique = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss.fff", System.Globalization.CultureInfo.InvariantCulture).Replace("-", "").Replace(":", "").Replace(".", "").Replace(" ", "");
                                    File.Copy(HttpContext.Current.Server.MapPath("~/Uploads/" + requestfoldername + @"/" + filename + "." + ext), HttpContext.Current.Server.MapPath("~/Uploads/" + requestfoldername + @"/" + filenameUnique + ".xlsx"));
                                    connectionString = string.Format(@"Provider=Microsoft.Jet.OleDb.4.0; Data Source={0};Extended Properties=""Text;HDR=YES;FMT=Delimited""", Path.GetDirectoryName(path));
                                }

                                if (iscsv)
                                {
                                    ext = "xlsx";
                                    connectionString = (ext.ToLower() == "xls" ? @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + HttpContext.Current.Server.MapPath("~/Uploads/" + requestfoldername + @"/" + filenameUnique + ".xlsx") + ";Extended Properties=\"Excel 8.0;HDR=Yes;\"" : "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + HttpContext.Current.Server.MapPath("~/Uploads/" + requestfoldername + @"/" + filenameUnique + ".xlsx") + "; Extended Properties=\"Excel 12.0;HDR=YES;IMEX=1;\"");
                                };
                                if (ext.ToLower() == "csv")
                                {
                                    OleDbConnection conn = new OleDbConnection();
                                    conn.ConnectionString = connectionString;
                                    conn.Open();
                                    string queryStr = "SELECT TOP 1 * FROM [" + filename + ".csv]";
                                    OleDbDataAdapter da = new OleDbDataAdapter(queryStr, conn);
                                    da.Fill(dt);
                                    da.Dispose();
                                    conn.Close();
                                }
                                else
                                {
                                    OleDbConnection conn = new OleDbConnection();
                                    conn.ConnectionString = connectionString;
                                    conn.Open();
                                    DataTable columnDetails = conn.GetOleDbSchemaTable(System.Data.OleDb.OleDbSchemaGuid.Columns, null);
                                    var rows = columnDetails.Rows.Cast<DataRow>();
                                    var query = (from r in rows group r by r["Table_Name"] into results select new { results.Key, count = results.Count() });
                                    var activeSheets = (from sheet in query select sheet.Key).ToList();
                                    string Sheet1 = activeSheets[0].ToString();
                                    string queryStr = "SELECT TOP 1 * FROM [" + Sheet1 + "]";
                                    OleDbDataAdapter da = new OleDbDataAdapter(queryStr, conn);
                                    da.Fill(dt);
                                    da.Dispose();
                                    conn.Close();
                                }
                                value = "valid";
                            }
                            catch (Exception ex)
                            {
                                value = "notvalid";
                            }
                        }
                        else if (ext.ToLower() == "dbf")
                        {
                            try
                            {
                                OleDbConnection conn = GetOLEBDConnObject(path);
                                string queryStr = "SELECT TOP 1 * FROM " + filename + " ORDER BY 1";
                                OleDbDataAdapter da = new OleDbDataAdapter(queryStr, conn);
                                da.Fill(dt);
                            }
                            catch (Exception ex)
                            {
                                value = "notvalid";
                            }
                        }
                    }
                    else
                    {
                        value = "virus";
                    }
                }
                else
                {
                    value = "notexists";
                }
            }
            catch (Exception)
            {
                value = string.Empty;
            }
            HttpContext.Current.Response.Write(value);
            HttpContext.Current.Response.End();
        }
    }
}
