﻿#region ChangeRequest
/// Created By  : Komal Patil
/// Created On  : 17-Feb-2017
/// Created for : For SQL Connection.
#endregion
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Configuration;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace SampleAPI.Models
{
    public class DBHelper
    {
        public string GetConnectionString()
        {
            return ConfigurationManager.AppSettings["MFBackOff"].ToString();

        }
        public static string ConnectionString()
        {
            return ConfigurationManager.AppSettings["MFBackOff"].ToString();

        }
        public static string GetClientFlag()
        {
            return ConfigurationManager.AppSettings["Client"].ToString();

        }
    }
}