﻿#region ChangeRequest
/// Created By  : Komal Patil
/// Created On  : 17-Feb-2017
/// Created for : Signature(Param).
#endregion
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SampleAPI.Models
{
    public class Signature
    {
        //public int ID { get; set; }
        public string ClientID { get; set; }
        public string PAN { get; set; }
        public string From_Date { get; set; }
        public string To_Date { get; set; }
        public string On_Date { get; set; }
        public string Redeemed_Folios { get; set; }
        public string TypeID { get; set; }
        public string Type { get; set; }
        public string AssetType { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string PRODUCTCODE { get; set; }
        public string FOLIONO { get; set; }
        public string OnDate { get; set; }
    }
}