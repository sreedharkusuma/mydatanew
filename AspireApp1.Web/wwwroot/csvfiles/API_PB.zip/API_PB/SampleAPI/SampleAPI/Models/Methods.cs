﻿#region ChangeRequest
/// Created By  : Komal Patil
/// Created On  : 17-Feb-2017
/// Created for : Execute procedures and Operations.
#endregion
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using AppBlock;
using System.Configuration;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;
using System.Data.Odbc;
using System.Data.SqlClient;
using System.Collections.Specialized;




/// <ChangeManagement>
/// SrNo.   Modified By     Date        Given By    Task Detail
/// 1.      Komal Patil     17-Feb-2017 sam sir     Added GetDataSet function for execute the procedures.          
/// 2.      Komal Patil     17-Feb-2017 -"-         Added SelectDistinct function for select distinct value.
/// 3.      Komal Patil     17-Feb-2017 -"-         Added CheckForDuplicate for check the duplicate values.
/// 4.      Komal Patil     17-Feb-2017 -"-         Added LoginChk for check user creditials.
/// 5.      Komal Patil     17-Feb-2017 -"-         Added GetDataTable for return DT.
/// </ChangeManagement>
namespace SampleAPI.Models
{
    public class Methods
    {
        protected string SqlCmd, SqlCon;
        DBHelper objDBHelper = new DBHelper();
        public DataSet ds;

        /// <summary>
        /// Added By Komal Patil on 17-Feb-2017
        /// </summary>
        /// <param name="Stored_Procedure"></param>
        /// <param name="NameValueCollection"></param>
        /// <returns></returns>
        public DataSet GetDataSet(string Stored_Procedure, NameValueCollection nv)
        {
            DataSet ds = new DataSet();
            //SqlConnection cn = new SqlConnection("data source=10.20.50.94;user id=sa;password=Acc$eqmf;database=Acemf_IIFL_New_UI;Connect TimeOut=180;Max Pool Size=10000");
            //SqlCommand cmd = new SqlCommand(Stored_Procedure, cn);
            //SqlConnection cn = new SqlConnection(DBHelper.ConnectionString());
            //SqlConnection cn = new SqlConnection(SampleAPI.Models.DBHelper.ConnectionString());
            SqlConnection cn = new SqlConnection(objDBHelper.GetConnectionString());
            SqlCommand cmd = new SqlCommand(Stored_Procedure, cn);

            for (int i = 0; i < nv.Count; i++)
            {
                SqlParameter param;
                if (nv.Get(nv.AllKeys[i]) == null)
                    param = new SqlParameter(nv.AllKeys[i], DBNull.Value);
                else
                    param = new SqlParameter(nv.AllKeys[i], nv.Get(nv.AllKeys[i]));
                cmd.Parameters.Add(param);
            }
            cmd.CommandTimeout = 0;
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            try
            {
                cn.Open();
                da.Fill(ds);
            }
            catch (Exception ex)
            {

                da.Dispose();
                cmd.Connection.Close();
                cn.Close();
                throw ex;
            }
            finally
            {
                da.Dispose();
                cmd.Connection.Close();
                cn.Close();
            }
            return ds;
        }

        /// <summary>
        /// Added By Komal Patil on 17-Feb-2017
        /// </summary>
        /// <param name="TableName"></param>
        /// <param name="SourceTable"></param>
        /// <param name="FieldName"></param>
        /// <returns></returns>
        public DataTable SelectDistinct(string TableName, DataTable SourceTable, string FieldName)
        {
            DataTable dt = new DataTable(TableName);
            string[] fArray = FieldName.Split(',');
            dt.Columns.Add(FieldName, typeof(string));

            foreach (DataRow dr in SourceTable.Rows)
            {
                string sValue = "";
                foreach (string fname in fArray)
                    sValue += dr[fname].ToString().Trim();
                if (CheckForDuplicate(dt, FieldName, sValue))
                    if (sValue != string.Empty) dt.Rows.Add(new object[] { sValue });
            }
            return dt;
        }

        /// <summary>
        /// Added By Komal Patil 17-Feb-2017
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="ColumnName"></param>
        /// <param name="ValueToCheck"></param>
        /// <returns></returns>
        private bool CheckForDuplicate(DataTable dt, string ColumnName, string ValueToCheck)
        {
            if (dt.Select("" + ColumnName + " = '" + ValueToCheck.Trim() + "'").Length > 0)
                return false;
            else
                return true;
        }

        /// <summary>
        /// Added By Komal Patil
        /// match Login_ID & password and return user detail from T_UserMaster Table
        /// Pass Opt:
        /// 1) ChkLgnIDPass - to match both Login_ID & Password
        /// 2) ChkLgnID - to match Login_ID only
        /// </summary>
        public DataSet LoginChk(string Login_ID, string Password, string Opt)
        {
            try
            {
                SqlCon = objDBHelper.GetConnectionString();
                SqlParameter[] param ={ SqlHelper.MakeParam("@Login_ID", Login_ID), 
                                    SqlHelper.MakeParam("@Password", Password),
                                    SqlHelper.MakeParam("@Opt", Opt),
                                  };
                ds = SqlHelper.ExecuteDataset(SqlCon, CommandType.StoredProcedure, "Login_Chk", param);
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
            return ds;
        }

        public DataTable GetDataTable(string Stored_Procedure, NameValueCollection nv)
        {
            DataTable dt = new DataTable();
            SqlDataReader dr = null;
            SqlConnection cn = new SqlConnection(objDBHelper.GetConnectionString());
            SqlCommand cmd = new SqlCommand(Stored_Procedure, cn);

            for (int i = 0; i < nv.Count; i++)
            {
                SqlParameter param;
                if (nv.Get(nv.AllKeys[i]) == null)
                    param = new SqlParameter(nv.AllKeys[i], DBNull.Value);
                else
                    param = new SqlParameter(nv.AllKeys[i], nv.Get(nv.AllKeys[i]));
                cmd.Parameters.Add(param);
            }
            cmd.CommandTimeout = 999999;
            cmd.CommandType = CommandType.StoredProcedure;
            cn.Open();
            dr = cmd.ExecuteReader();
            dt.Load(dr);
            dr.Dispose();
            cmd.Connection.Close();
            cn.Close();
            return dt;
        }


    }
}