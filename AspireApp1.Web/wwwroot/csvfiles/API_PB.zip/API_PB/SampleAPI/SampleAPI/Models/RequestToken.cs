﻿#region ChangeRequest
/// Created By  : Komal Patil
/// Created On  : 23-Feb-2017
/// Created for : Added for get parameter in decrypt format.
#endregion
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
namespace SampleAPI.Models
{
    public class RequestToken
    {
        public string Token { get; set; }
        EncryptDecrypt ObjEncDecrypt = new EncryptDecrypt();
        public string getParam(string strToken)
        {
            string decryptToken = ObjEncDecrypt.DecryptText_AES(strToken);
            string[] temporary = decryptToken.Split('|');
            return temporary[0];
        }
    }
}