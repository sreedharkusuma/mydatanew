﻿#region ChangeRequest
/// Created By  : Komal Patil
/// Created On  : 23-Feb-2017
/// Created for : Added for converting data in Encrypt or Decrypt format.
#endregion
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using System.IO;
using System.Security.Cryptography;
namespace SampleAPI.Models
{
    public class EncryptDecrypt
    {
        public string EncryptTextBy_AES(string value)
        {
            // Get the bytes of the string
            int paddingNo = 16 - value.Count() % 16;
            String paddingchar = "_";
            for (int i = 0; i < paddingNo; i++)
            {
                value = value + paddingchar;
            }
            
            byte[] bytesToBeEncrypted = Encoding.UTF8.GetBytes(value);
            string password = "uaybshvqo_dbays_";


            byte[] passwordBytes = Encoding.UTF8.GetBytes(password);

            // Hash the password with SHA256
            //passwordBytes = SHA256.Create().ComputeHash(passwordBytes);

            byte[] bytesEncrypted = AES_Encrypt(bytesToBeEncrypted, passwordBytes);

            string result = Convert.ToBase64String(bytesEncrypted);

            return result;
        }

        public string DecryptText_AES(string input)
        {
            // Get the bytes of the string
            string password = "uaybshvqo_dbays_";
            byte[] bytesToBeDecrypted = Convert.FromBase64String(input);
            byte[] passwordBytes = Encoding.UTF8.GetBytes(password);
            //    passwordBytes = SHA256.Create().ComputeHash(passwordBytes);

            byte[] bytesDecrypted = AES_Decrypt(bytesToBeDecrypted, passwordBytes);
            string result = Encoding.UTF8.GetString(bytesDecrypted);

            return result;
            //string strResult = result.Replace("_", "");
            //return strResult;
            
        }
        public byte[] AES_Encrypt(byte[] bytesToBeEncrypted, byte[] passwordBytes)
        {
            byte[] encryptedBytes = null;


            byte[] saltBytes = new byte[] { 1, 2, 3, 4, 5, 6, 7, 8 };

            using (MemoryStream ms = new MemoryStream())
            {
                using (RijndaelManaged AES = new RijndaelManaged())
                {
                    AES.KeySize = 256;
                    AES.BlockSize = 128;

                    var key = new Rfc2898DeriveBytes(passwordBytes, saltBytes, 1000);
                    AES.Key = passwordBytes; //key.GetBytes(AES.KeySize / 8);
                    AES.IV = Encoding.UTF8.GetBytes("qybacyshvpqie_d_");// key.GetBytes(AES.BlockSize / 8);
                    AES.Padding = PaddingMode.None;
                    



                    AES.Mode = CipherMode.CBC;

                    using (var cs = new CryptoStream(ms, AES.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(bytesToBeEncrypted, 0, bytesToBeEncrypted.Length);
                        cs.Close();
                    }
                    encryptedBytes = ms.ToArray();
                }
            }

            return encryptedBytes;
        }

        public byte[] AES_Decrypt(byte[] bytesToBeDecrypted, byte[] passwordBytes)
        {
            byte[] decryptedBytes = null;

            byte[] saltBytes = new byte[] { 1, 2, 3, 4, 5, 6, 7, 8 };

            using (MemoryStream ms = new MemoryStream())
            {
                using (RijndaelManaged AES = new RijndaelManaged())
                {
                    AES.KeySize = 256;
                    AES.BlockSize = 128;

                    var key = new Rfc2898DeriveBytes(passwordBytes, saltBytes, 1000);
                    AES.Key = passwordBytes; //key.GetBytes(AES.KeySize / 8);
                    AES.IV = Encoding.UTF8.GetBytes("qybacyshvpqie_d_");// key.GetBytes(AES.BlockSize / 8);
                    AES.Padding = PaddingMode.None;

                    AES.Mode = CipherMode.CBC;

                    using (var cs = new CryptoStream(ms, AES.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(bytesToBeDecrypted, 0, bytesToBeDecrypted.Length);
                        cs.Close();
                    }
                    decryptedBytes = ms.ToArray();
                }
            }

            return decryptedBytes;
        }

    }
}