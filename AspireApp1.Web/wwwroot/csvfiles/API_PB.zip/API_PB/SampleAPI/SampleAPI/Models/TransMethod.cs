﻿#region ChangeRequest
/// Created By  : Komal Patil
/// Created On  : 17-Feb-2017
/// Created for : Return the reports data in Table format.
#endregion
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;
using AppBlock;
using System.Data.SqlClient;
using System.Data;
using System.Collections.Specialized;
using System.Web.Security;
using System.IO;
using System.Xml;
/// <ChangeManagement>
/// SrNo.   Modified By     Date        Given By    Task Detail
/// 1.      Komal Patil     17-Feb-2017 Sam sir     Added Portfolio_Summary_Category_Wise function.          
/// 2.      Komal Patil     17-Feb-2017 -"-         Added Portfolio_Summary_Holding function.
/// 3.      Komal Patil     17-Feb-2017 -"-         Added All Functions for Client Portfolio reports.      
/// </ChangeManagement>

namespace SampleAPI.Models
{
    public class TransMethod
    {
        Methods TrObj = new Methods();
        DataTable dt = new DataTable();
        Common cs = new Common();

        string Value = "";
        System.Collections.Specialized.NameValueCollection nv = new System.Collections.Specialized.NameValueCollection();
        string schemecode, s_name, Folio_Number, Sch_Folio_Unitbal, currentvalue, costvalue, DivReINVST_AmountVal, dividend, Notional_ProfitLoss, WedAvgDays, AbsoluteReturn,
              simpleAnnulisedResults, XIIRCALC, CAGR, NetGain, Profit_Booked, className, NAV, GroupTotalVal, GrandTotalVal, AnnulResults, trxn_type_Nameval, Trxn_Dateval, Priceval,
              Unitsval, ToDate, _ID, strSelectValue;
        double Amountval, PortFolio_Unitbalval, Present_Valueval, Dividend_Amountval, NotionalPLval, Profit_Bookedval, NetGainval, Ageval, Absolute_Returnsval, DividendPayoutval,
               Sim_Ann_Returnsval, CAGRval;
        protected string SqlCmd, SqlCon;

        public DataSet Portfolio_Summary_Category_Wise(DataSet ds, string ON_DATE, string TypeID)
        {
            try
            {
                string ClientCode = "";
                if (ds.Tables[2].Rows.Count > 0)
                {
                    dt.Columns.Add("Folio_No");
                    dt.Columns.Add("ISIN");
                    dt.Columns.Add("Holding Type");
                    dt.Columns.Add("DP ID");
                    dt.Columns.Add("BSE Scheme Code");
                    dt.Columns.Add("Scheme Name");
                    dt.Columns.Add("Total Investment");
                    dt.Columns.Add("Current Investment");
                    dt.Columns.Add("Redeemed Amount");
                    dt.Columns.Add("Realized Profit");
                    dt.Columns.Add("Unrealized Profit");
                    dt.Columns.Add("Present Units");
                    dt.Columns.Add("Present NAV");
                    dt.Columns.Add("NAV Date");
                    dt.Columns.Add("Present Value");
                    dt.Columns.Add("Dividend_Reinvested");
                    dt.Columns.Add("Dividend_Paid_out");
                    dt.Columns.Add("Notional_Gain/Loss");
                    dt.Columns.Add("Absolute_Returns");
                    dt.Columns.Add("XIRR_Ann_Returns");
                    dt.Columns.Add("Wght_Avg_Days");

                    dt.Columns.Add("AMC Name");
                    dt.Columns.Add("ASSET_TYPE");
                    dt.Columns.Add("SCHEME CATEGORY");
                    dt.Columns.Add("SUB_CATEGORY");
                    dt.Columns.Add("AMC_CODE");
                    string hdnclient_id = "";
                    double InvestAmount_GrandT, CurrentInvestAmount_GrandT, Reedeemed_GrandT, Unit_GrandT, Present_GrandT, Dividened_GrandT, DividenedPaid_GrandT, NotonalPL_GrandT, Abslute_GrandT, XIRR_GrandT, RealizedGL_GrandT, UnRealizedGL_GrandT, WghtdDays_GrandT, ABSReturns_TotalG;
                    InvestAmount_GrandT = CurrentInvestAmount_GrandT = Reedeemed_GrandT = Unit_GrandT = Present_GrandT = Dividened_GrandT = DividenedPaid_GrandT = NotonalPL_GrandT = Abslute_GrandT = XIRR_GrandT = RealizedGL_GrandT = UnRealizedGL_GrandT = WghtdDays_GrandT = ABSReturns_TotalG = 0;
                    float[] Amount_weighted_TotalG = new float[2];

                    ClientCode = ds.Tables[0].Rows[0]["Client_ID"].ToString();
                    DataTable dt_ClientID = TrObj.SelectDistinct("Client_ID", ds.Tables[2], "Client_ID");

                    foreach (DataRow dr_ClientID in dt_ClientID.Rows)
                    {
                        double XIRR_Ind;

                        double InvestAmount_Value, CurrentInvestAmount_Value, Reedeemed_Value, Unit_Value, Present_TotalValue, Dividened_Value, DividenedPaid_Value, NotonalPL_Value, Abslute_Value, XIRR_Value, RealizedGL_Val, UnRealizedGL_Val, WghtdDays, InvestAmount_XValue, WeightedAmt, ABSReturns;
                        InvestAmount_Value = CurrentInvestAmount_Value = Reedeemed_Value = Unit_Value = Present_TotalValue = Dividened_Value = DividenedPaid_Value = NotonalPL_Value = Abslute_Value = XIRR_Value = RealizedGL_Val = UnRealizedGL_Val = WghtdDays = InvestAmount_XValue = WeightedAmt = ABSReturns = 0;
                        float[] Amount_weighted = new float[2];

                        DataRow[] dr_temp = ds.Tables[2].Select("Client_ID = '" + dr_ClientID["Client_ID"].ToString() + "'");
                        hdnclient_id = dr_ClientID["Client_ID"].ToString();
                        if (dr_temp.Length > 0)
                        {
                            string Prv_Folio = string.Empty;
                            foreach (DataRow dr in dr_temp)
                            {

                                XIRR_Ind = Convert.ToDouble(FormatFunctions.C_Format.M_FormatComma(Convert.ToString(Calculate_XIRR(hdnclient_id, "C", dr["Folio_Number"].ToString(), dr["schemecode"].ToString(), Convert.ToDouble(dr["Present_Value"].ToString()))), "2", "0").ToString());

                                DataRow _Rows = dt.NewRow();
                                _Rows["Folio_No"] = dr["Folio_Number"].ToString();
                                _Rows["ISIN"] = dr["ISIN_CODE"].ToString();
                                _Rows["Holding Type"] = dr["Holding Type"].ToString();
                                _Rows["DP ID"] = dr["DP ID"].ToString();
                                _Rows["BSE Scheme Code"] = dr["CAMS_CODE"].ToString();
                                _Rows["Scheme Name"] = dr["S_Name"].ToString();
                                _Rows["Total Investment"] = FormatFunctions.C_Format.M_FormatComma(dr["INVST_COST"].ToString(), "2", "N.A").ToString();
                                _Rows["Current Investment"] = FormatFunctions.C_Format.M_FormatComma(dr["Curr_INVST_COST"].ToString(), "2", "N.A").ToString();
                                _Rows["Redeemed Amount"] = FormatFunctions.C_Format.M_FormatComma(dr["Redeem_Amt"].ToString(), "2", "N.A").ToString();
                                _Rows["Realized Profit"] = FormatFunctions.C_Format.M_FormatComma(dr["Realized Gain/Loss"].ToString(), "2", "N.A").ToString();
                                _Rows["Unrealized Profit"] = FormatFunctions.C_Format.M_FormatComma(dr["UnRealized Gain/Loss"].ToString(), "2", "N.A").ToString();
                                //_Rows["Present Units"] = FormatFunctions.C_Format.M_FormatComma(dr["Present_Units"].ToString(), "2", "N.A").ToString();
                                _Rows["Present Units"] = dr["Present_Units"].ToString();
                                _Rows["Present NAV"] = dr["Latest_Nav"].ToString();
                                _Rows["NAV Date"] = dr["Latest_Nav_Date"].ToString();
                                _Rows["Present Value"] = dr["Present_Value"].ToString();
                                _Rows["Dividend_Reinvested"] = dr["Dividend_RInvst_AMT"].ToString();
                                _Rows["Dividend_Paid_out"] = dr["Dividend Payout"].ToString();
                                _Rows["Notional_Gain/Loss"] = dr["Notional P/L"].ToString();
                                _Rows["Absolute_Returns"] = dr["Absoute_Return"].ToString();
                                _Rows["XIRR_Ann_Returns"] = XIRR_Ind.ToString();
                                _Rows["Wght_Avg_Days"] = dr["Wtd_Days"].ToString();

                                _Rows["AMC Name"] = dr["FUND"].ToString();
                                _Rows["ASSET_TYPE"] = dr["ASSET_TYPE"].ToString();
                                _Rows["SCHEME CATEGORY"] = dr["CATEGORY"].ToString();
                                _Rows["SUB_CATEGORY"] = dr["SUB_CATEGORY"].ToString();
                                _Rows["AMC_CODE"] = dr["AMC_CODE"].ToString();
                                dt.Rows.Add(_Rows);

                                WeightedAmt = Convert.ToDouble(dr["Weighted_Abs_Amt"].ToString());
                                double _Age = Convert.ToDouble(dr["Wtd_Days"].ToString());

                                InvestAmount_XValue = Convert.ToDouble(dr["INVST_COST"].ToString());
                                InvestAmount_Value += Convert.ToDouble(dr["INVST_COST"].ToString());

                                CurrentInvestAmount_Value += Convert.ToDouble(dr["Curr_INVST_COST"].ToString());
                                Reedeemed_Value += Convert.ToDouble(dr["Redeem_Amt"].ToString());
                                Unit_Value += Convert.ToDouble(dr["Present_Units"].ToString());
                                Present_TotalValue += Convert.ToDouble(dr["Present_Value"].ToString());
                                Dividened_Value += Convert.ToDouble(dr["Dividend_RInvst_AMT"].ToString());
                                DividenedPaid_Value += Convert.ToDouble(dr["Dividend Payout"].ToString());
                                NotonalPL_Value += Convert.ToDouble(dr["Notional P/L"].ToString());
                                RealizedGL_Val += Convert.ToDouble(dr["Realized Gain/Loss"].ToString());
                                UnRealizedGL_Val += Convert.ToDouble(dr["UnRealized Gain/Loss"].ToString());


                                if ((dr["Absoute_Return"].ToString() == "") || (dr["Absoute_Return"].ToString() == " "))
                                {
                                    dr["Absoute_Return"] = 0.00;
                                }
                                ABSReturns += Convert.ToDouble(dr["Absoute_Return"].ToString()) * WeightedAmt;
                                if (Convert.ToDouble(dr["Absoute_Return"].ToString()) != 0) Amount_weighted[0] += (float)WeightedAmt;
                                if (_Age != 0) Amount_weighted[1] += (float)WeightedAmt;

                                WghtdDays += _Age * WeightedAmt;
                                Prv_Folio = dr["Folio_Number"].ToString();
                            }

                            Abslute_Value = (((Present_TotalValue - InvestAmount_Value) / InvestAmount_Value) * 100);

                            XIRR_Value = Convert.ToDouble(FormatFunctions.C_Format.M_FormatComma(Convert.ToString(Calculate_XIRR(hdnclient_id.ToString(), "C", "", "", Present_TotalValue)), "2", "0").ToString());

                            DataRow _RowsTT = dt.NewRow();
                            _RowsTT["Folio_No"] = "Total";
                            _RowsTT["ISIN"] = "";
                            _RowsTT["Holding Type"] = "";
                            _RowsTT["DP ID"] = "";
                            _RowsTT["BSE Scheme Code"] = "";
                            _RowsTT["Scheme Name"] = "";
                            _RowsTT["Total Investment"] = InvestAmount_Value.ToString("N2");
                            _RowsTT["Current Investment"] = CurrentInvestAmount_Value.ToString("N2");
                            _RowsTT["Redeemed Amount"] = Reedeemed_Value.ToString("N2");
                            _RowsTT["Realized Profit"] = RealizedGL_Val.ToString("N2");
                            _RowsTT["Unrealized Profit"] = UnRealizedGL_Val.ToString("N2");
                            _RowsTT["Present Units"] = "";
                            _RowsTT["Present NAV"] = "";
                            _RowsTT["NAV Date"] = "";
                            _RowsTT["Present Value"] = Present_TotalValue.ToString("N2");
                            _RowsTT["Dividend_Reinvested"] = Dividened_Value.ToString("N2");
                            _RowsTT["Dividend_Paid_out"] = DividenedPaid_Value.ToString("N2");
                            _RowsTT["Notional_Gain/Loss"] = NotonalPL_Value.ToString("N2");
                            _RowsTT["Absolute_Returns"] = ((double)(ABSReturns == 0 ? 0 : (ABSReturns / Amount_weighted[0]))).ToString("N2");
                            _RowsTT["XIRR_Ann_Returns"] = XIRR_Value.ToString("N2");
                            _RowsTT["Wght_Avg_Days"] = Convert.ToString(Math.Round((WghtdDays / Amount_weighted[1])));

                            _RowsTT["AMC Name"] = "";
                            _RowsTT["ASSET_TYPE"] = "";
                            _RowsTT["SCHEME CATEGORY"] = "";
                            _RowsTT["SUB_CATEGORY"] = "";
                            _RowsTT["AMC_CODE"] = "";
                            dt.Rows.Add(_RowsTT);
                            InvestAmount_GrandT += Convert.ToDouble(InvestAmount_Value.ToString());
                            CurrentInvestAmount_GrandT += Convert.ToDouble(CurrentInvestAmount_Value.ToString());
                            Reedeemed_GrandT += Convert.ToDouble(Reedeemed_Value.ToString());
                            Unit_GrandT += Convert.ToDouble(Unit_Value.ToString());
                            Present_GrandT += Convert.ToDouble(Present_TotalValue.ToString());
                            Dividened_GrandT += Convert.ToDouble(Dividened_Value.ToString());
                            DividenedPaid_GrandT += Convert.ToDouble(DividenedPaid_Value.ToString());
                            NotonalPL_GrandT += Convert.ToDouble(NotonalPL_Value.ToString());

                            RealizedGL_GrandT += Convert.ToDouble(RealizedGL_Val.ToString());
                            UnRealizedGL_GrandT += Convert.ToDouble(UnRealizedGL_Val.ToString());
                            WghtdDays_GrandT += Convert.ToDouble(WghtdDays.ToString());

                            ABSReturns_TotalG += Convert.ToDouble(ABSReturns.ToString());
                            Amount_weighted_TotalG[0] += Amount_weighted[0];

                            if (Amount_weighted[1] != 0) Amount_weighted_TotalG[1] += (float)Amount_weighted[1];

                        }
                    }
                    if (TypeID == "C")
                    {
                        Abslute_GrandT = ((Present_GrandT - InvestAmount_GrandT) / InvestAmount_GrandT * 100);
                        //XIRR_GrandT = Convert.ToDouble(FormatFunctions.C_Format.M_FormatComma(Convert.ToString(Calculate_XIRR(ClientCode, TypeID, "", "", Present_GrandT, "Portfolio_Summary_Category_wise")), "2", "0").ToString());
                        XIRR_GrandT = Convert.ToDouble(FormatFunctions.C_Format.M_FormatComma(Convert.ToString(Calculate_XIRR(ClientCode.ToString(), TypeID, "", "", Present_GrandT)), "2", "0").ToString());
                        DataRow _RowsGT = dt.NewRow();
                        _RowsGT["Folio_No"] = "Grand Total :";
                        _RowsGT["ISIN"] = "";
                        _RowsGT["Holding Type"] = "";
                        _RowsGT["DP ID"] = "";
                        _RowsGT["BSE Scheme Code"] = "";
                        _RowsGT["Scheme Name"] = "";
                        _RowsGT["Total Investment"] = InvestAmount_GrandT.ToString("N2");
                        _RowsGT["Current Investment"] = CurrentInvestAmount_GrandT.ToString("N2");
                        _RowsGT["Redeemed Amount"] = Reedeemed_GrandT.ToString("N2");
                        _RowsGT["Realized Profit"] = RealizedGL_GrandT.ToString("N2");
                        _RowsGT["Unrealized Profit"] = UnRealizedGL_GrandT.ToString("N2");
                        _RowsGT["Present Units"] = "";
                        _RowsGT["Present NAV"] = "";
                        _RowsGT["NAV Date"] = "";
                        _RowsGT["Present Value"] = Present_GrandT.ToString("N2");
                        _RowsGT["Dividend_Reinvested"] = Dividened_GrandT.ToString("N2");
                        _RowsGT["Dividend_Paid_out"] = DividenedPaid_GrandT.ToString("N2");
                        _RowsGT["Notional_Gain/Loss"] = NotonalPL_GrandT.ToString("N2");
                        _RowsGT["Absolute_Returns"] = ((double)(ABSReturns_TotalG == 0 ? 0 : (ABSReturns_TotalG / Amount_weighted_TotalG[0]))).ToString("N2");
                        _RowsGT["XIRR_Ann_Returns"] = XIRR_GrandT.ToString("N2");
                        _RowsGT["Wght_Avg_Days"] = Convert.ToString(Math.Round((WghtdDays_GrandT / Amount_weighted_TotalG[1])));

                        _RowsGT["AMC Name"] = "";
                        _RowsGT["ASSET_TYPE"] = "";
                        _RowsGT["SCHEME CATEGORY"] = "";
                        _RowsGT["SUB_CATEGORY"] = "";
                        _RowsGT["AMC_CODE"] = "";
                        dt.Rows.Add(_RowsGT);
                    }
                    else
                    {
                        Abslute_GrandT = ((Present_GrandT - InvestAmount_GrandT) / InvestAmount_GrandT * 100);
                        //XIRR_GrandT = Convert.ToDouble(FormatFunctions.C_Format.M_FormatComma(Convert.ToString(Calculate_XIRR(ClientCode, TypeID, "", "", Present_GrandT, "Portfolio_Summary_Category_wise")), "2", "0").ToString());
                        XIRR_GrandT = Convert.ToDouble(FormatFunctions.C_Format.M_FormatComma(Convert.ToString(Calculate_XIRR(ClientCode.ToString(), TypeID, "", "", Present_GrandT)), "2", "0").ToString());
                        DataRow _RowsGT = dt.NewRow();
                        _RowsGT["Folio_No"] = "Grand Total :";
                        _RowsGT["ISIN"] = "";
                        _RowsGT["Holding Type"] = "";
                        _RowsGT["DP ID"] = "";
                        _RowsGT["BSE Scheme Code"] = "";
                        _RowsGT["Scheme Name"] = "";
                        _RowsGT["Total Investment"] = InvestAmount_GrandT.ToString("N2");
                        _RowsGT["Current Investment"] = CurrentInvestAmount_GrandT.ToString("N2");
                        _RowsGT["Redeemed Amount"] = Reedeemed_GrandT.ToString("N2");
                        _RowsGT["Realized Profit"] = RealizedGL_GrandT.ToString("N2");
                        _RowsGT["Unrealized Profit"] = UnRealizedGL_GrandT.ToString("N2");
                        _RowsGT["Present Units"] = "";
                        _RowsGT["Present NAV"] = "";
                        _RowsGT["NAV Date"] = "";
                        _RowsGT["Present Value"] = Present_GrandT.ToString("N2");
                        _RowsGT["Dividend_Reinvested"] = Dividened_GrandT.ToString("N2");
                        _RowsGT["Dividend_Paid_out"] = DividenedPaid_GrandT.ToString("N2");
                        _RowsGT["Notional_Gain/Loss"] = NotonalPL_GrandT.ToString("N2");
                        _RowsGT["Absolute_Returns"] = ((double)(ABSReturns_TotalG == 0 ? 0 : (ABSReturns_TotalG / Amount_weighted_TotalG[0]))).ToString("N2");
                        _RowsGT["XIRR_Ann_Returns"] = XIRR_GrandT.ToString("N2");
                        _RowsGT["Wght_Avg_Days"] = Convert.ToString(Math.Round((WghtdDays_GrandT / Amount_weighted_TotalG[1])));

                        _RowsGT["AMC Name"] = "";
                        _RowsGT["ASSET_TYPE"] = "";
                        _RowsGT["SCHEME CATEGORY"] = "";
                        _RowsGT["SUB_CATEGORY"] = "";
                        _RowsGT["AMC_CODE"] = "";
                        dt.Rows.Add(_RowsGT);
                    }

                    ds.Tables.Add(dt);
                    return ds;
                }
                else
                {
                    DataTable table = new DataTable("Table3");
                    table.Columns.Add("DataValues", typeof(string));
                    table.Rows.Add("You do not have any investments as yet.");
                    ds.Tables.Add(table);
                    return ds;
                }

            }
            catch (Exception ex)
            {
                DataTable table = new DataTable("Table3");
                table.Columns.Add("DataValues", typeof(string));
                table.Rows.Add("Error Occured.");
                ds.Tables.Add(table);

                HttpContext con = HttpContext.Current;
                cs.createfile(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.ToString() + " Method Name : " + System.Reflection.MethodBase.GetCurrentMethod().ToString(), con.Request.Url.ToString(), ex.Message.ToString(), ex.GetType().ToString(), "");
                
                return ds;
            }
        }

        public DataSet Portfolio_Summary_Holding(DataSet ds)
        {
            String ClientID = "";
            try
            {
                if (ds.Tables[2].Rows.Count > 0)
                {

                    dt.Columns.Add("Scheme Name");
                    dt.Columns.Add("ISIN");
                    dt.Columns.Add("BSE Scheme Code");
                    dt.Columns.Add("Holding Type");
                    dt.Columns.Add("Folio_Number");
                    dt.Columns.Add("DP ID");
                    dt.Columns.Add("Current Units");
                    dt.Columns.Add("Current Value");
                    dt.Columns.Add("NAV Date");
                    dt.Columns.Add("Current NAV");
                    dt.Columns.Add("Current_Invest_Amount");
                    dt.Columns.Add("FUND");
                    dt.Columns.Add("ASSET_TYPE");
                    dt.Columns.Add("CATEGORY");
                    dt.Columns.Add("SUB_CATEGORY");
                    dt.Columns.Add("AMC_CODE");
                    string hdnclient_id = "";
                    double InvestAmount_GrandT, CurrentInvestAmount_GrandT, Reedeemed_GrandT, Unit_GrandT, Present_GrandT, Dividened_GrandT, DividenedPaid_GrandT, NotonalPL_GrandT, Abslute_GrandT, XIRR_GrandT, RealizedGL_GrandT, WghtdDays_GrandT, ABSReturns_TotalG;
                    InvestAmount_GrandT = CurrentInvestAmount_GrandT = Reedeemed_GrandT = Unit_GrandT = Present_GrandT = Dividened_GrandT = DividenedPaid_GrandT = NotonalPL_GrandT = Abslute_GrandT = XIRR_GrandT = RealizedGL_GrandT = WghtdDays_GrandT = ABSReturns_TotalG = 0;
                    float[] Amount_weighted_TotalG = new float[2];

                    ClientID = ds.Tables[0].Rows[0]["Client_ID"].ToString();
                    DataTable dt_ClientID = TrObj.SelectDistinct("Client_ID", ds.Tables[2], "Client_ID");

                    foreach (DataRow dr_ClientID in dt_ClientID.Rows)
                    {
                        double InvestAmount_Value, CurrentInvestAmount_Value, Reedeemed_Value, Unit_Value, Present_TotalValue, Dividened_Value, DividenedPaid_Value, NotonalPL_Value, Abslute_Value, XIRR_Value, RealizedGL_Val, WghtdDays, InvestAmount_XValue, WeightedAmt, ABSReturns;
                        InvestAmount_Value = CurrentInvestAmount_Value = Reedeemed_Value = Unit_Value = Present_TotalValue = Dividened_Value = DividenedPaid_Value = NotonalPL_Value = Abslute_Value = XIRR_Value = RealizedGL_Val = WghtdDays = InvestAmount_XValue = WeightedAmt = ABSReturns = 0;
                        float[] Amount_weighted = new float[2];

                        DataRow[] dr_temp = ds.Tables[2].Select("Client_ID = '" + dr_ClientID["Client_ID"].ToString() + "'");
                        hdnclient_id = dr_ClientID["Client_ID"].ToString();
                        if (dr_temp.Length > 0)
                        {
                            foreach (DataRow dr in dr_temp)
                            {

                                DataRow _Rows = dt.NewRow();
                                _Rows["Scheme Name"] = dr["Scheme Name"].ToString();
                                _Rows["ISIN"] = dr["ISIN"].ToString();
                                _Rows["BSE Scheme Code"] = dr["BSE Scheme Code"].ToString();
                                _Rows["Holding Type"] = dr["Holding Type"].ToString();
                                _Rows["Folio_Number"] = dr["Folio_Number"].ToString();
                                _Rows["DP ID"] = dr["DP ID"].ToString();
                                _Rows["Current Units"] = dr["Current Units"].ToString();
                                _Rows["Current Value"] = dr["Current Value"].ToString();
                                _Rows["NAV Date"] = dr["NAV Date"].ToString();
                                _Rows["Current NAV"] = dr["Current NAV"].ToString();
                                _Rows["Current_Invest_Amount"] = dr["Current_Invest_Amount"].ToString();
                                _Rows["FUND"] = dr["FUND"].ToString();
                                _Rows["ASSET_TYPE"] = dr["ASSET_TYPE"].ToString();
                                _Rows["CATEGORY"] = dr["CATEGORY"].ToString();
                                _Rows["SUB_CATEGORY"] = dr["SUB_CATEGORY"].ToString();
                                _Rows["AMC_CODE"] = dr["AMC_CODE"].ToString();
                                dt.Rows.Add(_Rows);

                                InvestAmount_XValue = Convert.ToDouble(dr["Total_Amount"].ToString());
                                InvestAmount_Value += Convert.ToDouble(dr["Total_Amount"].ToString());
                                CurrentInvestAmount_Value += Convert.ToDouble(dr["Current_Invest_Amount"].ToString());
                                Unit_Value += Convert.ToDouble(dr["Current Units"].ToString());
                                Present_TotalValue += Convert.ToDouble(dr["Current Value"].ToString());
                            }
                            DataRow _RowsTT = dt.NewRow();
                            _RowsTT["Scheme Name"] = "Total";
                            _RowsTT["ISIN"] = "";
                            _RowsTT["BSE Scheme Code"] = "";
                            _RowsTT["Holding Type"] = "";
                            _RowsTT["Folio_Number"] = "";
                            _RowsTT["DP ID"] = "";
                            _RowsTT["Current Units"] = "";
                            _RowsTT["Current Value"] = Present_TotalValue.ToString("N2");
                            _RowsTT["NAV Date"] = "";
                            _RowsTT["Current NAV"] = "";
                            _RowsTT["Current_Invest_Amount"] = CurrentInvestAmount_Value.ToString("N2");
                            _RowsTT["FUND"] = "";
                            _RowsTT["ASSET_TYPE"] = "";
                            _RowsTT["CATEGORY"] = "";
                            _RowsTT["SUB_CATEGORY"] = "";
                            _RowsTT["AMC_CODE"] = "";
                            dt.Rows.Add(_RowsTT);
                            InvestAmount_GrandT += Convert.ToDouble(InvestAmount_Value.ToString());
                            CurrentInvestAmount_GrandT += Convert.ToDouble(CurrentInvestAmount_Value.ToString());
                            Unit_GrandT += Convert.ToDouble(Unit_Value.ToString());
                            Present_GrandT += Convert.ToDouble(Present_TotalValue.ToString());
                        }
                    }

                    Abslute_GrandT = ((Present_GrandT - InvestAmount_GrandT) / InvestAmount_GrandT * 100);
                    DataRow _RowsGT = dt.NewRow();
                    _RowsGT["Scheme Name"] = "Grand Total :";
                    _RowsGT["ISIN"] = "";
                    _RowsGT["BSE Scheme Code"] = "";
                    _RowsGT["Holding Type"] = "";
                    _RowsGT["Folio_Number"] = "";
                    _RowsGT["DP ID"] = "";
                    _RowsGT["Current Units"] = "";
                    _RowsGT["Current Value"] = Present_GrandT.ToString("N2");
                    _RowsGT["NAV Date"] = "";
                    _RowsGT["Current NAV"] = "";
                    _RowsGT["Current_Invest_Amount"] = CurrentInvestAmount_GrandT.ToString("N2");
                    _RowsGT["FUND"] = "";
                    _RowsGT["ASSET_TYPE"] = "";
                    _RowsGT["CATEGORY"] = "";
                    _RowsGT["SUB_CATEGORY"] = "";
                    _RowsGT["AMC_CODE"] = "";
                    dt.Rows.Add(_RowsGT);
                    ds.Tables.Add(dt);
                    return ds;
                }
                else
                {
                    DataTable table = new DataTable("Table3");
                    table.Columns.Add("DataValues", typeof(string));
                    table.Rows.Add("You do not have any investments as yet.");
                    ds.Tables.Add(table);
                    return ds;
                }
            }
            catch (Exception ex)
            {
                DataTable table = new DataTable("Table3");
                table.Columns.Add("DataValues", typeof(string));
                table.Rows.Add("Error Occured.");
                ds.Tables.Add(table);
                HttpContext con = HttpContext.Current;
                cs.createfile(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.ToString() + " Method Name : " + System.Reflection.MethodBase.GetCurrentMethod().ToString(), con.Request.Url.ToString(), ex.Message.ToString(), ex.GetType().ToString(), "");
                return ds;
            }
        }

        public DataSet Portfolio_Summary_Category_Wise_PB(DataSet ds, string ON_DATE, string TypeID)
        {
            try
            {
                string ClientCode = "";
                if (ds.Tables[2].Rows.Count > 0)
                {
                    dt.Columns.Add("Folio_No");
                    dt.Columns.Add("Scheme Name");
                    dt.Columns.Add("Total Investment");
                    dt.Columns.Add("Current Investment");
                    dt.Columns.Add("Redeemed Amount");
                    dt.Columns.Add("Realized Profit");
                    dt.Columns.Add("Unrealized Profit");
                    dt.Columns.Add("Present Units");
                    dt.Columns.Add("Present NAV");
                    dt.Columns.Add("NAV Date");
                    dt.Columns.Add("Present Value");
                    dt.Columns.Add("Dividend_Reinvested");
                    dt.Columns.Add("Dividend_Paid_out");
                    dt.Columns.Add("Notional_Gain/Loss");
                    dt.Columns.Add("Absolute_Returns");
                    dt.Columns.Add("XIRR_Ann_Returns");
                    dt.Columns.Add("Wght_Avg_Days");

                    dt.Columns.Add("AMC Name");
                    dt.Columns.Add("ASSET_TYPE");
                    dt.Columns.Add("SCHEME CATEGORY");
                    dt.Columns.Add("SUB_CATEGORY");
                    dt.Columns.Add("AMC_CODE");
                    dt.Columns.Add("Series");
                    dt.Columns.Add("ISIN");
                    string hdnclient_id = "";
                    double InvestAmount_GrandT, CurrentInvestAmount_GrandT, Reedeemed_GrandT, Unit_GrandT, Present_GrandT, Dividened_GrandT, DividenedPaid_GrandT, NotonalPL_GrandT, Abslute_GrandT, XIRR_GrandT, RealizedGL_GrandT, UnRealizedGL_GrandT, WghtdDays_GrandT, ABSReturns_TotalG;
                    InvestAmount_GrandT = CurrentInvestAmount_GrandT = Reedeemed_GrandT = Unit_GrandT = Present_GrandT = Dividened_GrandT = DividenedPaid_GrandT = NotonalPL_GrandT = Abslute_GrandT = XIRR_GrandT = RealizedGL_GrandT = UnRealizedGL_GrandT = WghtdDays_GrandT = ABSReturns_TotalG = 0;
                    float[] Amount_weighted_TotalG = new float[2];

                    ClientCode = ds.Tables[0].Rows[0]["Client_ID"].ToString();
                    DataTable dt_ClientID = TrObj.SelectDistinct("Client_ID", ds.Tables[2], "Client_ID");

                    foreach (DataRow dr_ClientID in dt_ClientID.Rows)
                    {
                        double XIRR_Ind;

                        double InvestAmount_Value, CurrentInvestAmount_Value, Reedeemed_Value, Unit_Value, Present_TotalValue, Dividened_Value, DividenedPaid_Value, NotonalPL_Value, Abslute_Value, XIRR_Value, RealizedGL_Val, UnRealizedGL_Val, WghtdDays, InvestAmount_XValue, WeightedAmt, ABSReturns;
                        InvestAmount_Value = CurrentInvestAmount_Value = Reedeemed_Value = Unit_Value = Present_TotalValue = Dividened_Value = DividenedPaid_Value = NotonalPL_Value = Abslute_Value = XIRR_Value = RealizedGL_Val = UnRealizedGL_Val = WghtdDays = InvestAmount_XValue = WeightedAmt = ABSReturns = 0;
                        float[] Amount_weighted = new float[2];

                        DataRow[] dr_temp = ds.Tables[2].Select("Client_ID = '" + dr_ClientID["Client_ID"].ToString() + "'");
                        hdnclient_id = dr_ClientID["Client_ID"].ToString();
                        if (dr_temp.Length > 0)
                        {
                            string Prv_Folio = string.Empty;
                            foreach (DataRow dr in dr_temp)
                            {

                                XIRR_Ind = Convert.ToDouble(FormatFunctions.C_Format.M_FormatComma(Convert.ToString(Calculate_XIRR(hdnclient_id, "C", dr["Folio_Number"].ToString(), dr["schemecode"].ToString(), Convert.ToDouble(dr["Present_Value"].ToString()))), "2", "0").ToString());

                                DataRow _Rows = dt.NewRow();
                                _Rows["Folio_No"] = dr["Folio_Number"].ToString();
                                _Rows["Scheme Name"] = dr["S_Name"].ToString();
                                _Rows["Total Investment"] = FormatFunctions.C_Format.M_FormatComma(dr["INVST_COST"].ToString(), "2", "N.A").ToString();
                                _Rows["Current Investment"] = FormatFunctions.C_Format.M_FormatComma(dr["Curr_INVST_COST"].ToString(), "2", "N.A").ToString();
                                _Rows["Redeemed Amount"] = FormatFunctions.C_Format.M_FormatComma(dr["Redeem_Amt"].ToString(), "2", "N.A").ToString();
                                _Rows["Realized Profit"] = FormatFunctions.C_Format.M_FormatComma(dr["Realized Gain/Loss"].ToString(), "2", "N.A").ToString();
                                _Rows["Unrealized Profit"] = FormatFunctions.C_Format.M_FormatComma(dr["UnRealized Gain/Loss"].ToString(), "2", "N.A").ToString();
                                //_Rows["Present Units"] = FormatFunctions.C_Format.M_FormatComma(dr["Present_Units"].ToString(), "2", "N.A").ToString();
                                _Rows["Present Units"] = dr["Present_Units"].ToString();
                                _Rows["Present NAV"] = dr["Latest_Nav"].ToString();
                                _Rows["NAV Date"] = dr["Latest_Nav_Date"].ToString();
                                _Rows["Present Value"] = dr["Present_Value"].ToString();
                                _Rows["Dividend_Reinvested"] = dr["Dividend_RInvst_AMT"].ToString();
                                _Rows["Dividend_Paid_out"] = dr["Dividend Payout"].ToString();
                                _Rows["Notional_Gain/Loss"] = dr["Notional P/L"].ToString();
                                _Rows["Absolute_Returns"] = dr["Absoute_Return"].ToString();
                                _Rows["XIRR_Ann_Returns"] = XIRR_Ind.ToString();
                                _Rows["Wght_Avg_Days"] = dr["Wtd_Days"].ToString();

                                _Rows["AMC Name"] = dr["FUND"].ToString();
                                _Rows["ASSET_TYPE"] = dr["ASSET_TYPE"].ToString();
                                //if (dr["CATEGORY"].ToString().Contains("'") || dr["CATEGORY"].ToString().Contains("-") || dr["CATEGORY"].ToString().Contains("&"))
                                //{
                                //    if (dr["CATEGORY"].ToString().Contains("'"))
                                //    {
                                //        _Rows["SCHEME CATEGORY"] = dr["CATEGORY"].ToString().Replace("'", "");
                                //    }
                                //    else if (dr["CATEGORY"].ToString().Contains("-"))
                                //    {
                                //        _Rows["SCHEME CATEGORY"] = dr["CATEGORY"].ToString().Replace("-", "");
                                //    }
                                //    else if (dr["CATEGORY"].ToString().Contains("&"))
                                //    {
                                //        _Rows["SCHEME CATEGORY"] = dr["CATEGORY"].ToString().Replace("&", "");
                                //    }
                                //}
                                //else
                                //{
                                //    _Rows["SCHEME CATEGORY"] = dr["CATEGORY"].ToString().Replace("'", "");
                                //}

                                //if (dr["SUB_CATEGORY"].ToString().Contains("'") || dr["SUB_CATEGORY"].ToString().Contains("-") || dr["SUB_CATEGORY"].ToString().Contains("&"))
                                //{
                                //    if (dr["SUB_CATEGORY"].ToString().Contains("'"))
                                //    {
                                //        _Rows["SUB_CATEGORY"] = dr["SUB_CATEGORY"].ToString().Replace("'", "");
                                //    }
                                //    else if (dr["SUB_CATEGORY"].ToString().Contains("-"))
                                //    {
                                //        _Rows["SUB_CATEGORY"] = dr["SUB_CATEGORY"].ToString().Replace("-", "");
                                //    }
                                //    else if (dr["SUB_CATEGORY"].ToString().Contains("&"))
                                //    {
                                //        _Rows["SUB_CATEGORY"] = dr["SUB_CATEGORY"].ToString().Replace("&", "");
                                //    }
                                //}
                                //else
                                //{
                                //    _Rows["SUB_CATEGORY"] = dr["SUB_CATEGORY"].ToString().Replace("'", "");
                                //}

                                //_Rows["SCHEME CATEGORY"] = dr["CATEGORY"].ToString();
                                _Rows["SCHEME CATEGORY"] = "";
                                _Rows["SUB_CATEGORY"] = dr["SUB_CATEGORY"].ToString();
                                _Rows["AMC_CODE"] = dr["AMC_CODE"].ToString();
                                _Rows["Series"] = dr["Series"].ToString();
                                _Rows["ISIN"] = dr["ISIN"].ToString();
                                dt.Rows.Add(_Rows);

                                WeightedAmt = Convert.ToDouble(dr["Weighted_Abs_Amt"].ToString());
                                double _Age = Convert.ToDouble(dr["Wtd_Days"].ToString());

                                InvestAmount_XValue = Convert.ToDouble(dr["INVST_COST"].ToString());
                                InvestAmount_Value += Convert.ToDouble(dr["INVST_COST"].ToString());

                                CurrentInvestAmount_Value += Convert.ToDouble(dr["Curr_INVST_COST"].ToString());
                                Reedeemed_Value += Convert.ToDouble(dr["Redeem_Amt"].ToString());
                                Unit_Value += Convert.ToDouble(dr["Present_Units"].ToString());
                                Present_TotalValue += Convert.ToDouble(dr["Present_Value"].ToString());
                                Dividened_Value += Convert.ToDouble(dr["Dividend_RInvst_AMT"].ToString());
                                DividenedPaid_Value += Convert.ToDouble(dr["Dividend Payout"].ToString());
                                NotonalPL_Value += Convert.ToDouble(dr["Notional P/L"].ToString());
                                RealizedGL_Val += Convert.ToDouble(dr["Realized Gain/Loss"].ToString());
                                UnRealizedGL_Val += Convert.ToDouble(dr["UnRealized Gain/Loss"].ToString());


                                if ((dr["Absoute_Return"].ToString() == "") || (dr["Absoute_Return"].ToString() == " "))
                                {
                                    dr["Absoute_Return"] = 0.00;
                                }
                                ABSReturns += Convert.ToDouble(dr["Absoute_Return"].ToString()) * WeightedAmt;
                                if (Convert.ToDouble(dr["Absoute_Return"].ToString()) != 0) Amount_weighted[0] += (float)WeightedAmt;
                                if (_Age != 0) Amount_weighted[1] += (float)WeightedAmt;

                                WghtdDays += _Age * WeightedAmt;
                                Prv_Folio = dr["Folio_Number"].ToString();
                            }

                            Abslute_Value = (((Present_TotalValue - InvestAmount_Value) / InvestAmount_Value) * 100);

                            XIRR_Value = Convert.ToDouble(FormatFunctions.C_Format.M_FormatComma(Convert.ToString(Calculate_XIRR(hdnclient_id.ToString(), "C", "", "", Present_TotalValue)), "2", "0").ToString());

                            DataRow _RowsTT = dt.NewRow();
                            _RowsTT["Folio_No"] = "Total";
                            _RowsTT["Scheme Name"] = "";
                            _RowsTT["Total Investment"] = InvestAmount_Value.ToString("N2");
                            _RowsTT["Current Investment"] = CurrentInvestAmount_Value.ToString("N2");
                            _RowsTT["Redeemed Amount"] = Reedeemed_Value.ToString("N2");
                            _RowsTT["Realized Profit"] = RealizedGL_Val.ToString("N2");
                            _RowsTT["Unrealized Profit"] = UnRealizedGL_Val.ToString("N2");
                            _RowsTT["Present Units"] = "";
                            _RowsTT["Present NAV"] = "";
                            _RowsTT["NAV Date"] = "";
                            _RowsTT["Present Value"] = Present_TotalValue.ToString("N2");
                            _RowsTT["Dividend_Reinvested"] = Dividened_Value.ToString("N2");
                            _RowsTT["Dividend_Paid_out"] = DividenedPaid_Value.ToString("N2");
                            _RowsTT["Notional_Gain/Loss"] = NotonalPL_Value.ToString("N2");
                            _RowsTT["Absolute_Returns"] = ((double)(ABSReturns == 0 ? 0 : (ABSReturns / Amount_weighted[0]))).ToString("N2");
                            _RowsTT["XIRR_Ann_Returns"] = XIRR_Value.ToString("N2");
                            _RowsTT["Wght_Avg_Days"] = Convert.ToString(Math.Round((WghtdDays / Amount_weighted[1])));

                            _RowsTT["AMC Name"] = "";
                            _RowsTT["ASSET_TYPE"] = "";
                            _RowsTT["SCHEME CATEGORY"] = "";
                            _RowsTT["SUB_CATEGORY"] = "";
                            _RowsTT["AMC_CODE"] = "";
                            _RowsTT["Series"] = "";
                            _RowsTT["ISIN"] = "";
                            dt.Rows.Add(_RowsTT);
                            InvestAmount_GrandT += Convert.ToDouble(InvestAmount_Value.ToString());
                            CurrentInvestAmount_GrandT += Convert.ToDouble(CurrentInvestAmount_Value.ToString());
                            Reedeemed_GrandT += Convert.ToDouble(Reedeemed_Value.ToString());
                            Unit_GrandT += Convert.ToDouble(Unit_Value.ToString());
                            Present_GrandT += Convert.ToDouble(Present_TotalValue.ToString());
                            Dividened_GrandT += Convert.ToDouble(Dividened_Value.ToString());
                            DividenedPaid_GrandT += Convert.ToDouble(DividenedPaid_Value.ToString());
                            NotonalPL_GrandT += Convert.ToDouble(NotonalPL_Value.ToString());

                            RealizedGL_GrandT += Convert.ToDouble(RealizedGL_Val.ToString());
                            UnRealizedGL_GrandT += Convert.ToDouble(UnRealizedGL_Val.ToString());
                            WghtdDays_GrandT += Convert.ToDouble(WghtdDays.ToString());

                            ABSReturns_TotalG += Convert.ToDouble(ABSReturns.ToString());
                            Amount_weighted_TotalG[0] += Amount_weighted[0];

                            if (Amount_weighted[1] != 0) Amount_weighted_TotalG[1] += (float)Amount_weighted[1];

                        }
                    }
                    if (TypeID == "C")
                    {
                        Abslute_GrandT = ((Present_GrandT - InvestAmount_GrandT) / InvestAmount_GrandT * 100);
                        //XIRR_GrandT = Convert.ToDouble(FormatFunctions.C_Format.M_FormatComma(Convert.ToString(Calculate_XIRR(ClientCode, TypeID, "", "", Present_GrandT, "Portfolio_Summary_Category_wise")), "2", "0").ToString());
                        XIRR_GrandT = Convert.ToDouble(FormatFunctions.C_Format.M_FormatComma(Convert.ToString(Calculate_XIRR(ClientCode.ToString(), TypeID, "", "", Present_GrandT)), "2", "0").ToString());
                        DataRow _RowsGT = dt.NewRow();
                        _RowsGT["Folio_No"] = "Grand Total :";
                        _RowsGT["Scheme Name"] = "";
                        _RowsGT["Total Investment"] = InvestAmount_GrandT.ToString("N2");
                        _RowsGT["Current Investment"] = CurrentInvestAmount_GrandT.ToString("N2");
                        _RowsGT["Redeemed Amount"] = Reedeemed_GrandT.ToString("N2");
                        _RowsGT["Realized Profit"] = RealizedGL_GrandT.ToString("N2");
                        _RowsGT["Unrealized Profit"] = UnRealizedGL_GrandT.ToString("N2");
                        _RowsGT["Present Units"] = "";
                        _RowsGT["Present NAV"] = "";
                        _RowsGT["NAV Date"] = "";
                        _RowsGT["Present Value"] = Present_GrandT.ToString("N2");
                        _RowsGT["Dividend_Reinvested"] = Dividened_GrandT.ToString("N2");
                        _RowsGT["Dividend_Paid_out"] = DividenedPaid_GrandT.ToString("N2");
                        _RowsGT["Notional_Gain/Loss"] = NotonalPL_GrandT.ToString("N2");
                        _RowsGT["Absolute_Returns"] = ((double)(ABSReturns_TotalG == 0 ? 0 : (ABSReturns_TotalG / Amount_weighted_TotalG[0]))).ToString("N2");
                        _RowsGT["XIRR_Ann_Returns"] = XIRR_GrandT.ToString("N2");
                        _RowsGT["Wght_Avg_Days"] = Convert.ToString(Math.Round((WghtdDays_GrandT / Amount_weighted_TotalG[1])));

                        _RowsGT["AMC Name"] = "";
                        _RowsGT["ASSET_TYPE"] = "";
                        _RowsGT["SCHEME CATEGORY"] = "";
                        _RowsGT["SUB_CATEGORY"] = "";
                        _RowsGT["AMC_CODE"] = "";
                        _RowsGT["Series"] = "";
                        _RowsGT["ISIN"] = "";
                        dt.Rows.Add(_RowsGT);
                    }
                    else
                    {
                        Abslute_GrandT = ((Present_GrandT - InvestAmount_GrandT) / InvestAmount_GrandT * 100);
                        //XIRR_GrandT = Convert.ToDouble(FormatFunctions.C_Format.M_FormatComma(Convert.ToString(Calculate_XIRR(ClientCode, TypeID, "", "", Present_GrandT, "Portfolio_Summary_Category_wise")), "2", "0").ToString());
                        XIRR_GrandT = Convert.ToDouble(FormatFunctions.C_Format.M_FormatComma(Convert.ToString(Calculate_XIRR(ClientCode.ToString(), TypeID, "", "", Present_GrandT)), "2", "0").ToString());
                        DataRow _RowsGT = dt.NewRow();
                        _RowsGT["Folio_No"] = "Grand Total :";
                        _RowsGT["Scheme Name"] = "";
                        _RowsGT["Total Investment"] = InvestAmount_GrandT.ToString("N2");
                        _RowsGT["Current Investment"] = CurrentInvestAmount_GrandT.ToString("N2");
                        _RowsGT["Redeemed Amount"] = Reedeemed_GrandT.ToString("N2");
                        _RowsGT["Realized Profit"] = RealizedGL_GrandT.ToString("N2");
                        _RowsGT["Unrealized Profit"] = UnRealizedGL_GrandT.ToString("N2");
                        _RowsGT["Present Units"] = "";
                        _RowsGT["Present NAV"] = "";
                        _RowsGT["NAV Date"] = "";
                        _RowsGT["Present Value"] = Present_GrandT.ToString("N2");
                        _RowsGT["Dividend_Reinvested"] = Dividened_GrandT.ToString("N2");
                        _RowsGT["Dividend_Paid_out"] = DividenedPaid_GrandT.ToString("N2");
                        _RowsGT["Notional_Gain/Loss"] = NotonalPL_GrandT.ToString("N2");
                        _RowsGT["Absolute_Returns"] = ((double)(ABSReturns_TotalG == 0 ? 0 : (ABSReturns_TotalG / Amount_weighted_TotalG[0]))).ToString("N2");
                        _RowsGT["XIRR_Ann_Returns"] = XIRR_GrandT.ToString("N2");
                        _RowsGT["Wght_Avg_Days"] = Convert.ToString(Math.Round((WghtdDays_GrandT / Amount_weighted_TotalG[1])));

                        _RowsGT["AMC Name"] = "";
                        _RowsGT["ASSET_TYPE"] = "";
                        _RowsGT["SCHEME CATEGORY"] = "";
                        _RowsGT["SUB_CATEGORY"] = "";
                        _RowsGT["AMC_CODE"] = "";
                        _RowsGT["Series"] = "";
                        _RowsGT["ISIN"] = "";
                        dt.Rows.Add(_RowsGT);
                    }

                    ds.Tables.Add(dt);
                    return ds;
                }
                else
                {
                    DataTable table = new DataTable("Table3");
                    table.Columns.Add("DataValues", typeof(string));
                    table.Rows.Add("You do not have any investments as yet.");
                    ds.Tables.Add(table);
                    return ds;
                }

            }
            catch (Exception ex)
            {
                DataTable table = new DataTable("Table3");
                table.Columns.Add("DataValues", typeof(string));
                table.Rows.Add("Error Occured.");

                ds.Tables.Add(table);

                HttpContext con = HttpContext.Current;
                cs.createfile(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.ToString() + " Method Name : " + System.Reflection.MethodBase.GetCurrentMethod().ToString(), con.Request.Url.ToString(), ex.Message.ToString(), ex.GetType().ToString(), "");

                return ds;
            }
        }

        public DataSet Portfolio_Summary_Live_Units(DataSet ds)
        {
            try
            {
                if (ds.Tables[0].Rows.Count > 0)
                {
                    dt.Columns.Add("Folio_No");
                    dt.Columns.Add("Scheme_Name");
                    dt.Columns.Add("Total_Amount");
                    dt.Columns.Add("Current_Invest_Amount");
                    dt.Columns.Add("Redeemed_Amount");
                    dt.Columns.Add("Realized_Profit_on_Red");
                    dt.Columns.Add("Present_Units");
                    dt.Columns.Add("Redeemable_Units");
                    dt.Columns.Add("Present_NAV");
                    dt.Columns.Add("Present_Value");
                    dt.Columns.Add("Dividend_Reinvested");
                    dt.Columns.Add("Dividend_Paid_out");
                    dt.Columns.Add("Notional_GL");
                    dt.Columns.Add("Abs_Returns");
                    dt.Columns.Add("XIRR_Ann_Returns");
                    dt.Columns.Add("Wght_Avg_Days");
                    dt.Columns.Add("Scheme_Code");
                    dt.Columns.Add("NAV_Date");
                    dt.Columns.Add("Series");
                    dt.Columns.Add("ISIN");
                    dt.Columns.Add("CATEGORY");
                    dt.Columns.Add("Fund_Type");

                    double InvestAmount_GrandT, CurrentInvestAmount_GrandT, Reedeemed_GrandT, Unit_GrandT, Present_GrandT, Dividened_GrandT, DividenedPaid_GrandT, NotonalPL_GrandT, Abslute_GrandT, XIRR_GrandT, RealizedGL_GrandT, WghtdDays_GrandT, ABSReturns_TotalG;
                    InvestAmount_GrandT = CurrentInvestAmount_GrandT = Reedeemed_GrandT = Unit_GrandT = Present_GrandT = Dividened_GrandT = DividenedPaid_GrandT = NotonalPL_GrandT = Abslute_GrandT = XIRR_GrandT = RealizedGL_GrandT = WghtdDays_GrandT = ABSReturns_TotalG = 0;
                    float[] Amount_weighted_TotalG = new float[2];


                    DataTable dt_ClientID = TrObj.SelectDistinct("Client_ID", ds.Tables[0], "Client_ID");
                    string hdnclient_id = "";

                    foreach (DataRow dr_ClientID in dt_ClientID.Rows)
                    {
                        double XIRR_Ind;

                        double InvestAmount_Value, CurrentInvestAmount_Value, Reedeemed_Value, Unit_Value, Present_TotalValue, Dividened_Value, DividenedPaid_Value, NotonalPL_Value, Abslute_Value, XIRR_Value, RealizedGL_Val, WghtdDays, InvestAmount_XValue, WeightedAmt, ABSReturns;
                        InvestAmount_Value = CurrentInvestAmount_Value = Reedeemed_Value = Unit_Value = Present_TotalValue = Dividened_Value = DividenedPaid_Value = NotonalPL_Value = Abslute_Value = XIRR_Value = RealizedGL_Val = WghtdDays = InvestAmount_XValue = WeightedAmt = ABSReturns = 0;
                        float[] Amount_weighted = new float[2];
                        hdnclient_id = dr_ClientID["Client_ID"].ToString();
                        DataRow[] dr_temp = ds.Tables[0].Select("Client_ID = '" + dr_ClientID["Client_ID"].ToString() + "'");

                        if (dr_temp.Length > 0)
                        {
                            string Prv_Folio = string.Empty;
                            foreach (DataRow dr in dr_temp)
                            {
                                XIRR_Ind = Convert.ToDouble(FormatFunctions.C_Format.M_FormatComma(Convert.ToString(Calculate_XIRR(dr["Client_ID"].ToString(), "C", dr["Folio_Number"].ToString(), dr["schemecode"].ToString(), Convert.ToDouble(dr["Present_Value"].ToString()))), "2", "0").ToString());

                                DataRow _Rows = dt.NewRow();
                                _Rows["Folio_No"] = dr["Folio_Number"].ToString();
                                _Rows["Scheme_Name"] = dr["S_Name"].ToString(); ;
                                _Rows["Total_Amount"] = FormatFunctions.C_Format.M_FormatComma(dr["INVST_COST"].ToString(), "2", "N.A").ToString();
                                _Rows["Current_Invest_Amount"] = FormatFunctions.C_Format.M_FormatComma(dr["Curr_INVST_COST"].ToString(), "2", "N.A").ToString();
                                _Rows["Redeemed_Amount"] = FormatFunctions.C_Format.M_FormatComma(dr["Redeem_Amt"].ToString(), "2", "N.A").ToString();
                                _Rows["Realized_Profit_on_Red"] = FormatFunctions.C_Format.M_FormatComma(dr["Realized Gain/Loss"].ToString(), "2", "N.A").ToString();
                                //_Rows["Present_Units"] = FormatFunctions.C_Format.M_FormatComma(dr["Present_Units"].ToString(), "2", "N.A").ToString();
                                _Rows["Present_Units"] = dr["Present_Units"].ToString();
                                _Rows["Redeemable_Units"] = dr["Redeemable_Units"].ToString();
                                _Rows["Present_NAV"] = dr["Latest_Nav"].ToString();
                                _Rows["Present_Value"] = dr["Present_Value"].ToString();
                                _Rows["Dividend_Reinvested"] = dr["Dividend_RInvst_AMT"].ToString();
                                _Rows["Dividend_Paid_out"] = dr["Dividend Payout"].ToString();
                                _Rows["Notional_GL"] = dr["Notional P/L"].ToString();
                                _Rows["Abs_Returns"] = dr["Absoute_Return"].ToString();
                                _Rows["XIRR_Ann_Returns"] = XIRR_Ind.ToString();
                                _Rows["Wght_Avg_Days"] = dr["Wtd_Days"].ToString();
                                _Rows["Scheme_Code"] = dr["SCHEMECODE"].ToString();
                                _Rows["NAV_Date"] = dr["Latest_Nav_Date"].ToString();
                                _Rows["Series"] = dr["Series"].ToString();
                                _Rows["ISIN"] = dr["ISIN"].ToString();
                                _Rows["CATEGORY"] = dr["CATEGORY"].ToString();
                                _Rows["Fund_Type"] = dr["Fund_Type"].ToString();

                                dt.Rows.Add(_Rows);

                                WeightedAmt = Convert.ToDouble(dr["Weighted_Abs_Amt"].ToString());
                                double _Age = Convert.ToDouble(dr["Wtd_Days"].ToString());

                                InvestAmount_XValue = Convert.ToDouble(dr["INVST_COST"].ToString());
                                InvestAmount_Value += Convert.ToDouble(dr["INVST_COST"].ToString());

                                CurrentInvestAmount_Value += Convert.ToDouble(dr["Curr_INVST_COST"].ToString());
                                Reedeemed_Value += Convert.ToDouble(dr["Redeem_Amt"].ToString());
                                Unit_Value += Convert.ToDouble(dr["Present_Units"].ToString());
                                Present_TotalValue += Convert.ToDouble(dr["Present_Value"].ToString());
                                Dividened_Value += Convert.ToDouble(dr["Dividend_RInvst_AMT"].ToString());
                                DividenedPaid_Value += Convert.ToDouble(dr["Dividend Payout"].ToString());
                                NotonalPL_Value += Convert.ToDouble(dr["Notional P/L"].ToString());
                                RealizedGL_Val += Convert.ToDouble(dr["Realized Gain/Loss"].ToString());

                                ABSReturns += Convert.ToDouble(dr["Absoute_Return"].ToString()) * WeightedAmt;
                                if (Convert.ToDouble(dr["Absoute_Return"].ToString()) != 0) Amount_weighted[0] += (float)WeightedAmt;
                                if (_Age != 0) Amount_weighted[1] += (float)WeightedAmt;

                                WghtdDays += _Age * WeightedAmt;
                                Prv_Folio = dr["Folio_Number"].ToString();
                            }

                            Abslute_Value = (((Present_TotalValue - InvestAmount_Value) / InvestAmount_Value) * 100);
                            XIRR_Value = Convert.ToDouble(FormatFunctions.C_Format.M_FormatComma(Convert.ToString(Calculate_XIRR(hdnclient_id.ToString(), "C", "", "", Present_TotalValue)), "2", "0").ToString());

                            DataRow _RowsTT = dt.NewRow();
                            _RowsTT["Folio_No"] = "Total :";
                            _RowsTT["Scheme_Name"] = "";
                            _RowsTT["Total_Amount"] = InvestAmount_Value.ToString("N2");
                            _RowsTT["Current_Invest_Amount"] = CurrentInvestAmount_Value.ToString("N2");
                            _RowsTT["Redeemed_Amount"] = Reedeemed_Value.ToString("N2");
                            _RowsTT["Realized_Profit_on_Red"] = RealizedGL_Val.ToString("N2");
                            _RowsTT["Present_Units"] = "";
                            _RowsTT["Redeemable_Units"] = "";
                            _RowsTT["Present_NAV"] = "";
                            _RowsTT["Present_Value"] = Present_TotalValue.ToString("N2");
                            _RowsTT["Dividend_Reinvested"] = Dividened_Value.ToString("N2");
                            _RowsTT["Dividend_Paid_out"] = DividenedPaid_Value.ToString("N2");
                            _RowsTT["Abs_Returns"] = ((double)(ABSReturns == 0 ? 0 : (ABSReturns / Amount_weighted[0]))).ToString("N2");
                            _RowsTT["XIRR_Ann_Returns"] = XIRR_Value.ToString("N2");
                            _RowsTT["Wght_Avg_Days"] = Convert.ToString(Math.Round((WghtdDays / Amount_weighted[1])));
                            _RowsTT["Scheme_Code"] = "";
                            _RowsTT["NAV_Date"] = "";
                            _RowsTT["Series"] = "";
                            _RowsTT["ISIN"] = "";
                            _RowsTT["CATEGORY"] = "";
                            _RowsTT["Fund_Type"] = "";
                            dt.Rows.Add(_RowsTT);

                            InvestAmount_GrandT += Convert.ToDouble(InvestAmount_Value.ToString());
                            CurrentInvestAmount_GrandT += Convert.ToDouble(CurrentInvestAmount_Value.ToString());
                            Reedeemed_GrandT += Convert.ToDouble(Reedeemed_Value.ToString());
                            Unit_GrandT += Convert.ToDouble(Unit_Value.ToString());
                            Present_GrandT += Convert.ToDouble(Present_TotalValue.ToString());
                            Dividened_GrandT += Convert.ToDouble(Dividened_Value.ToString());
                            DividenedPaid_GrandT += Convert.ToDouble(DividenedPaid_Value.ToString());
                            NotonalPL_GrandT += Convert.ToDouble(NotonalPL_Value.ToString());

                            RealizedGL_GrandT += Convert.ToDouble(RealizedGL_Val.ToString());
                            WghtdDays_GrandT += Convert.ToDouble(WghtdDays.ToString());

                            ABSReturns_TotalG += Convert.ToDouble(ABSReturns.ToString());
                            Amount_weighted_TotalG[0] += Amount_weighted[0];

                            if (Amount_weighted[1] != 0) Amount_weighted_TotalG[1] += (float)Amount_weighted[1];

                        }
                    }

                    Abslute_GrandT = ((Present_GrandT - InvestAmount_GrandT) / InvestAmount_GrandT * 100);
                    XIRR_GrandT = Convert.ToDouble(FormatFunctions.C_Format.M_FormatComma(Convert.ToString(Calculate_XIRR(hdnclient_id.ToString(), "C", "", "", Present_GrandT)), "2", "0").ToString());

                    DataRow _RowsGT = dt.NewRow();
                    _RowsGT["Folio_No"] = "Grand Total :";
                    _RowsGT["Scheme_Name"] = "";
                    _RowsGT["Total_Amount"] = InvestAmount_GrandT.ToString("N2");
                    _RowsGT["Current_Invest_Amount"] = CurrentInvestAmount_GrandT.ToString("N2");
                    _RowsGT["Redeemed_Amount"] = Reedeemed_GrandT.ToString("N2");
                    _RowsGT["Realized_Profit_on_Red"] = RealizedGL_GrandT.ToString("N2");
                    _RowsGT["Present_Units"] = "";//Unit_GrandT.ToString("N2");
                    _RowsGT["Redeemable_Units"] = "";
                    _RowsGT["Present_NAV"] = "";
                    _RowsGT["Present_Value"] = Present_GrandT.ToString("N2");
                    _RowsGT["Dividend_Reinvested"] = Dividened_GrandT.ToString("N2");
                    _RowsGT["Dividend_Paid_out"] = DividenedPaid_GrandT.ToString("N2");
                    _RowsGT["Notional_GL"] = NotonalPL_GrandT.ToString("N2");
                    _RowsGT["Abs_Returns"] = ((double)(ABSReturns_TotalG == 0 ? 0 : (ABSReturns_TotalG / Amount_weighted_TotalG[0]))).ToString("N2");
                    _RowsGT["XIRR_Ann_Returns"] = XIRR_GrandT.ToString("N2");
                    _RowsGT["Wght_Avg_Days"] = Convert.ToString(Math.Round((WghtdDays_GrandT / Amount_weighted_TotalG[1])));
                    _RowsGT["Scheme_Code"] = "";
                    _RowsGT["NAV_Date"] = "";
                    _RowsGT["Series"] = "";
                    _RowsGT["ISIN"] = "";
                    _RowsGT["CATEGORY"] = "";
                    _RowsGT["Fund_Type"] = "";
                    

                    dt.Rows.Add(_RowsGT);

                    ds.Tables.Add(dt);
                    return ds;
                }
                else
                {
                    DataTable table = new DataTable("DataTable");
                    table.Columns.Add("DataValues", typeof(string));
                    table.Rows.Add("Data Not Found!!!!");
                    ds.Tables.Add(table);
                    return ds;
                }
            }
            catch (Exception ex)
            {
                DataTable table = new DataTable("DataTable");
                table.Columns.Add("DataValues", typeof(string));
                table.Rows.Add("Data Not Found!!!!");
                ds.Tables.Add(table);

                HttpContext con = HttpContext.Current;
                cs.createfile(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.ToString() + " Method Name : " + System.Reflection.MethodBase.GetCurrentMethod().ToString(), con.Request.Url.ToString(), ex.Message.ToString(), ex.GetType().ToString(), "");

                return ds;
            }
            finally
            {
                ds = null;
            }
        }

        public DataSet Portfolio_Detail_Live_Units(DataSet ds)
        {
            try
            {
                if (!(ds == null || ds.Tables[0].Rows.Count == 0))
                {
                    dt.Columns.Add("Transaction_Type");
                    dt.Columns.Add("Folio_Number");
                    dt.Columns.Add("Scheme_Name");
                    dt.Columns.Add("Transaction_Date");
                    dt.Columns.Add("Transaction_Price");
                    dt.Columns.Add("No_of_Units");
                    dt.Columns.Add("Purchase_Value");
                    dt.Columns.Add("Current_Amount");
                    dt.Columns.Add("Dividend_Payout");
                    dt.Columns.Add("Dividend_Reinvest");
                    dt.Columns.Add("Profit_Loss");
                    dt.Columns.Add("No_of_Days");
                    dt.Columns.Add("Net_Gain");
                    dt.Columns.Add("Absolute_Return");
                    dt.Columns.Add("Annual_Return");
                    dt.Columns.Add("XIRR_CAGR");
                    dt.Columns.Add("AMC_Name");
                    dt.Columns.Add("Series");

                    DataTable dt_Funds = TrObj.SelectDistinct("Fund_ID", ds.Tables[0], "AMC_CODE");
                    DataTable dt_SCHEMES = TrObj.SelectDistinct("SCHEMECODE", ds.Tables[0], "SCHEMECODE");

                    DataTable dt_Clients = TrObj.SelectDistinct("Client_ID", ds.Tables[0], "Client_ID");

                    string Latest_NAV_Date = string.Empty, Latest_NAV = string.Empty;
                    double Age_TotalG, ABSReturns_TotalG, SimAnnReturns_TotalG, CAGR_TotalG, Units_TotalG, Amount_TotalG, Positive_Amount_TotalG, Dividend_Payout_TotalG, Present_Value_TotalG, Dividend_Amt_TotalG, Notional_PL_TotalG, NetGain_TotalG;
                    Age_TotalG = ABSReturns_TotalG = SimAnnReturns_TotalG = CAGR_TotalG = Units_TotalG = Amount_TotalG = Positive_Amount_TotalG = Dividend_Payout_TotalG = Present_Value_TotalG = Dividend_Amt_TotalG = Notional_PL_TotalG = NetGain_TotalG = 0;
                    float[] Amount_weighted_TotalG = new float[4];

                    foreach (DataRow dr_ClientID in dt_Clients.Rows)
                    {
                        double Age_Total, ABSReturns_Total, SimAnnReturns_Total, CAGR_Total, Units_Total, Amount_Total, Positive_Amount_Total, Dividend_Payout_Total, Present_Value_Total, Dividend_Amt_Total, Notional_PL_Total, NetGain_Total;
                        Age_Total = ABSReturns_Total = SimAnnReturns_Total = CAGR_Total = Units_Total = Amount_Total = Positive_Amount_Total = Dividend_Payout_Total = Present_Value_Total = Dividend_Amt_Total = Notional_PL_Total = NetGain_Total = 0;
                        float[] Amount_weighted_Total = new float[4];

                        DataRow[] dr_temp1 = ds.Tables[0].Select("Client_ID = '" + dr_ClientID["Client_ID"].ToString() + "'");
                        if (dr_temp1.Length > 0)
                        {
                            string Prv_ClientID = string.Empty;
                            string Prv_Fund = string.Empty;

                            foreach (DataRow dr_Funds in dt_Funds.Rows)
                            {
                                if (((DataRow[])ds.Tables[0].Select("AMC_CODE = '" + dr_Funds["AMC_CODE"].ToString() + "' and Client_ID = '" + dr_ClientID["Client_ID"].ToString() + "'")).Length > 0)
                                {
                                    string Prv_Folio = string.Empty;
                                    string Prv_Sch = string.Empty;
                                    string Prv_SchCode = string.Empty;

                                    double Age_Fund, ABSReturns_Fund, SimAnnReturns_Fund, CAGR_Fund, Units_Fund, Amount_Fund, Positive_Amount_Fund, Dividend_Payout_Fund, Present_Value_Fund, Dividend_Amt_Fund, Notional_PL_Fund, NetGain_Fund;
                                    Age_Fund = ABSReturns_Fund = SimAnnReturns_Fund = CAGR_Fund = Units_Fund = Amount_Fund = Positive_Amount_Fund = Dividend_Payout_Fund = Present_Value_Fund = Dividend_Amt_Fund = Notional_PL_Fund = NetGain_Fund = 0;
                                    float[] Amount_weighted_Fund = new float[4];

                                    foreach (DataRow dr_SCHEMES in dt_SCHEMES.Rows)
                                    {
                                        DataRow[] dr_temp = ds.Tables[0].Select("AMC_CODE = '" + dr_Funds["AMC_CODE"].ToString() + "' and SCHEMECODE = '" + dr_SCHEMES["SCHEMECODE"].ToString() + "' and Client_ID = '" + dr_ClientID["Client_ID"].ToString() + "'");
                                        double Age, ABSReturns, SimAnnReturns, CAGR, Units, Amount, Positive_Amount, Dividend_Payout, Present_Value, Dividend_Amt, Notional_PL, NetGain;
                                        Age = ABSReturns = SimAnnReturns = CAGR = Units = Amount = Positive_Amount = Dividend_Payout = Present_Value = Dividend_Amt = Notional_PL = NetGain = 0;
                                        float[] Amount_weighted = new float[4];
                                        string ASSET_TYPE = string.Empty;

                                        if (dr_temp.Length > 0)
                                        {
                                            foreach (DataRow dr in dr_temp)
                                            {
                                                if (!(Prv_Folio == dr["Folio_Number"].ToString() && Prv_Sch == dr["S_Name"].ToString()))
                                                {
                                                    Prv_ClientID = dr["Client_ID"].ToString();
                                                    if (!(Prv_Folio == string.Empty || Prv_Sch == string.Empty) && Prv_Sch == dr["S_Name"].ToString())
                                                    {
                                                        Latest_NAV_Date = (dr_temp.Length > 0 ? dr_temp[dr_temp.Length - 1]["Latest_Nav_Date"].ToString() : "--");
                                                        Latest_NAV = (dr_temp.Length > 0 ? dr_temp[dr_temp.Length - 1]["Latest_Nav"].ToString() : "--");
                                                        DataRow _RowsT = dt.NewRow();
                                                        _RowsT["Transaction_Type"] = "Balance in Folio :";
                                                        _RowsT["Folio_Number"] = dr["Folio_Number"].ToString();
                                                        _RowsT["Scheme_Name"] = "";
                                                        _RowsT["Transaction_Date"] = "";
                                                        _RowsT["Transaction_Price"] = "";
                                                        _RowsT["No_of_Units"] = Units.ToString("N3");
                                                        _RowsT["Purchase_Value"] = ((double)(Amount - Dividend_Payout)).ToString("N2");
                                                        _RowsT["Current_Amount"] = Present_Value.ToString("N2");
                                                        _RowsT["Dividend_Payout"] = Dividend_Payout.ToString("N2");
                                                        _RowsT["Dividend_Reinvest"] = Dividend_Amt.ToString("N2");
                                                        _RowsT["Profit_Loss"] = Notional_PL.ToString("N2");
                                                        _RowsT["No_of_Days"] = Math.Round((Age == 0 ? 0 : (Age / Amount_weighted[0])));
                                                        _RowsT["Net_Gain"] = NetGain.ToString("N2");
                                                        _RowsT["Absolute_Return"] = ((double)(ABSReturns == 0 ? 0 : (ABSReturns / Amount_weighted[1]))).ToString("N2");
                                                        _RowsT["Annual_Return"] = ((double)(SimAnnReturns == 0 ? 0 : (SimAnnReturns / Amount_weighted[2]))).ToString("N2");
                                                        _RowsT["XIRR_CAGR"] = FormatFunctions.C_Format.M_FormatComma(Convert.ToString(Calculate_XIRR(Prv_ClientID, "C", Prv_Folio, Prv_SchCode, Present_Value)), "2", "0").ToString();
                                                        _RowsT["AMC_Name"] = "";
                                                        _RowsT["Series"] = "";
                                                        dt.Rows.Add(_RowsT);

                                                        Age_Fund += Age; ABSReturns_Fund += ABSReturns; SimAnnReturns_Fund += SimAnnReturns; CAGR_Fund += CAGR; Amount_weighted_Fund[0] += Amount_weighted[0]; Amount_weighted_Fund[1] += Amount_weighted[1]; Amount_weighted_Fund[2] += Amount_weighted[2]; Amount_weighted_Fund[3] += Amount_weighted[3];
                                                        Units_Fund += Units; Amount_Fund += Amount; Positive_Amount_Fund += Positive_Amount; Dividend_Payout_Fund += Dividend_Payout; Present_Value_Fund += Present_Value; Dividend_Amt_Fund += Dividend_Amt; Notional_PL_Fund += Notional_PL; NetGain_Fund += NetGain;
                                                        Age = ABSReturns = SimAnnReturns = CAGR = Units = Amount = Positive_Amount = Dividend_Payout = Present_Value = Dividend_Amt = Notional_PL = NetGain = 0;
                                                        Amount_weighted = new float[4];
                                                        ASSET_TYPE = string.Empty;
                                                    }
                                                    Prv_Folio = dr["Folio_Number"].ToString();
                                                    Prv_Sch = dr["S_Name"].ToString();
                                                    Prv_SchCode = dr["schemecode"].ToString();
                                                }

                                                DataRow _Rows = dt.NewRow();
                                                _Rows["Transaction_Type"] = dr["trxn_type_Name"].ToString();
                                                _Rows["Folio_Number"] = dr["Folio_Number"].ToString();
                                                _Rows["Scheme_Name"] = dr["S_Name"].ToString();
                                                _Rows["Transaction_Date"] = dr["Trxn_Date"].ToString();
                                                _Rows["Transaction_Price"] = dr["Price"].ToString();
                                                _Rows["No_of_Units"] = dr["Units"].ToString();
                                                _Rows["Purchase_Value"] = dr["Amount"].ToString();
                                                _Rows["Current_Amount"] = dr["Present_Value"].ToString();
                                                _Rows["Dividend_Payout"] = dr["Dividend Payout"].ToString();
                                                _Rows["Dividend_Reinvest"] = dr["Dividend_Amount"].ToString();
                                                _Rows["Profit_Loss"] = dr["Notional P/L"].ToString();
                                                _Rows["No_of_Days"] = dr["Age"].ToString();
                                                _Rows["Net_Gain"] = dr["NetGain"].ToString();
                                                _Rows["Absolute_Return"] = (Convert.ToDouble(dr["Absolute_Returns"].ToString()) == 0 ? "--" : dr["Absolute_Returns"].ToString());
                                                _Rows["Annual_Return"] = (Convert.ToDouble(dr["Sim_Ann_Returns"].ToString()) == 0 ? "--" : dr["Sim_Ann_Returns"].ToString());
                                                _Rows["XIRR_CAGR"] = "--";
                                                _Rows["AMC_Name"] = dr["FUND"].ToString();
                                                _Rows["Series"] = dr["Series"].ToString();
                                                dt.Rows.Add(_Rows);

                                                if (Convert.ToDouble(dr["PortFolio_Unitbal"].ToString()) != 0)
                                                {
                                                    double weighted_Amount = Convert.ToDouble(dr["Amount"].ToString());
                                                    Age += Convert.ToDouble(dr["Age"].ToString()) * weighted_Amount;
                                                    ABSReturns += Convert.ToDouble(dr["Absolute_Returns"].ToString()) * weighted_Amount;
                                                    SimAnnReturns += Convert.ToDouble(dr["Sim_Ann_Returns"].ToString()) * weighted_Amount;
                                                    CAGR += Convert.ToDouble(dr["CAGR"].ToString()) * weighted_Amount;

                                                    if (Convert.ToDouble(dr["Age"].ToString()) != 0) Amount_weighted[0] += (float)weighted_Amount;
                                                    if (Convert.ToDouble(dr["Absolute_Returns"].ToString()) != 0) Amount_weighted[1] += (float)weighted_Amount;
                                                    if (Convert.ToDouble(dr["Sim_Ann_Returns"].ToString()) != 0) Amount_weighted[2] += (float)weighted_Amount;
                                                    if (Convert.ToDouble(dr["CAGR"].ToString()) != 0) Amount_weighted[3] += (float)weighted_Amount;
                                                    //Amount_weighted += Convert.ToDouble(dr["Amount"].ToString());
                                                }
                                                Units += Convert.ToDouble(dr["Units"].ToString());//
                                                Amount += Convert.ToDouble(dr["Amount"].ToString());//
                                                Positive_Amount += (Convert.ToString(dr["Trxn_Type_ID"].ToString()) == "9" || Convert.ToString(dr["Trxn_Type_ID"].ToString()) == "10") ? 0 : Convert.ToDouble(dr["Amount"].ToString());
                                                Dividend_Payout += Convert.ToDouble(dr["Dividend Payout"].ToString());
                                                Present_Value += Convert.ToDouble(dr["Present_Value"].ToString());
                                                //Present_Value += Convert.ToDouble(dr["COST_VALUE"].ToString());
                                                Dividend_Amt += Convert.ToDouble(dr["Dividend_Amount"].ToString());
                                                Notional_PL += Convert.ToDouble(dr["Notional P/L"].ToString());
                                                NetGain += Convert.ToDouble(dr["NetGain"].ToString());
                                                ASSET_TYPE = Convert.ToString(dr["ASSET_TYPE"].ToString());
                                            }

                                            Latest_NAV_Date = (dr_temp.Length > 0 ? dr_temp[dr_temp.Length - 1]["Latest_Nav_Date"].ToString() : "--");
                                            Latest_NAV = (dr_temp.Length > 0 ? dr_temp[dr_temp.Length - 1]["Latest_Nav"].ToString() : "--");
                                            DataRow _RowsTT = dt.NewRow();
                                            _RowsTT["Transaction_Type"] = "Balance in Folio :";
                                            _RowsTT["Folio_Number"] = Prv_Folio;
                                            _RowsTT["Scheme_Name"] = "";
                                            _RowsTT["Transaction_Date"] = "";
                                            _RowsTT["Transaction_Price"] = "";
                                            _RowsTT["No_of_Units"] = Units.ToString("N3");
                                            _RowsTT["Purchase_Value"] = ((double)(Amount - Dividend_Payout)).ToString("N2");
                                            _RowsTT["Current_Amount"] = Present_Value.ToString("N2");
                                            _RowsTT["Dividend_Payout"] = Dividend_Payout.ToString("N2");
                                            _RowsTT["Dividend_Reinvest"] = Dividend_Amt.ToString("N2");
                                            _RowsTT["Profit_Loss"] = Notional_PL.ToString("N2");
                                            _RowsTT["No_of_Days"] = Math.Round((Age == 0 ? 0 : (Age / Amount_weighted[0])));
                                            _RowsTT["Net_Gain"] = NetGain.ToString("N2");
                                            _RowsTT["Absolute_Return"] = ((double)(ABSReturns == 0 ? 0 : (ABSReturns / Amount_weighted[1]))).ToString("N2");
                                            _RowsTT["Annual_Return"] = ((double)(SimAnnReturns == 0 ? 0 : (SimAnnReturns / Amount_weighted[2]))).ToString("N2");
                                            _RowsTT["XIRR_CAGR"] = FormatFunctions.C_Format.M_FormatComma(Convert.ToString(Calculate_XIRR(Prv_ClientID, "C", Prv_Folio, Prv_SchCode, Present_Value)), "2", "0").ToString();
                                            _RowsTT["AMC_Name"] = "";
                                            _RowsTT["Series"] = "";
                                            dt.Rows.Add(_RowsTT);

                                        }



                                        Age_Fund += Age; ABSReturns_Fund += ABSReturns; SimAnnReturns_Fund += SimAnnReturns; CAGR_Fund += CAGR; Amount_weighted_Fund[0] += Amount_weighted[0]; Amount_weighted_Fund[1] += Amount_weighted[1]; Amount_weighted_Fund[2] += Amount_weighted[2]; Amount_weighted_Fund[3] += Amount_weighted[3];
                                        Units_Fund += Units; Amount_Fund += Amount; Positive_Amount_Fund += Positive_Amount; Dividend_Payout_Fund += Dividend_Payout; Present_Value_Fund += Present_Value; Dividend_Amt_Fund += Dividend_Amt; Notional_PL_Fund += Notional_PL; NetGain_Fund += NetGain;
                                    }
                                    /*Grid_HTML += "<tr><td style='width:10%; white-space:nowrap;' class='Label1' colspan='4'>Fund wise Balance in Folio :</td><td class='Label1' style='width:15%; white-space:nowrap; text-align:right; padding-right:5px; padding-left:10px;'>" + Math.Round(Amount_Fund, 2) + "</td><td class='Label1' style='width:15%; white-space:nowrap; text-align:center; padding-right:5px; padding-left:5px;'>" + Latest_NAV_Date + "</td><td class='Label1' style='width:15%; white-space:nowrap; text-align:right; padding-right:5px; padding-left:10px;'>" + Latest_NAV + "</td><td class='Label1' style='width:15%; white-space:nowrap; text-align:right; padding-right:5px; padding-left:10px;'>" + Math.Round(Present_Value_Fund, 2) + "</td>" +
                                                 "<td class='Label1' style='width:15%; white-space:nowrap; text-align:right; padding-right:5px; padding-left:10px;'>" + Math.Round(Dividend_Payout_Fund, 2) + "</td><td class='Label1' style='width:15%; white-space:nowrap; text-align:right; padding-right:5px; padding-left:10px;'>" + Math.Round(Dividend_Amt_Fund, 2) + "</td><td class='Label1' style='width:15%; white-space:nowrap; text-align:right; padding-right:5px; padding-left:10px;'>" + Math.Round(Notional_PL_Fund, 2) + "</td><td class='Label1' style='width:15%; white-space:nowrap; text-align:right; padding-right:5px; padding-left:10px;'>" + Math.Round((Age_Fund == 0 ? 0 : (Age_Fund / Amount_weighted_Fund[0]))) + "</td><td class='Label1' style='width:15%; white-space:nowrap; text-align:right; padding-right:5px; padding-left:10px;'>" + Math.Round((ABSReturns_Fund == 0 ? 0 : (ABSReturns_Fund / Amount_weighted_Fund[1])), 2) + "</td><td class='Label1' style='width:15%; white-space:nowrap; text-align:right; padding-right:5px; padding-left:10px;'>" + Math.Round((SimAnnReturns_Fund == 0 ? 0 : (SimAnnReturns_Fund / Amount_weighted_Fund[2])), 2) + "</td><td class='Label1' style='width:15%; white-space:nowrap; text-align:right; padding-right:5px; padding-left:10px;'>" + Math.Round((CAGR_Fund == 0 ? 0 : (CAGR_Fund / Amount_weighted_Fund[3])), 2) + "</td><td class='Label1' style='width:15%; white-space:nowrap; text-align:right; padding-right:5px; padding-left:10px;'>" + Math.Round(NetGain_Fund, 2) + "</td></tr>";
                                    */
                                    Age_Total += Age_Fund; ABSReturns_Total += ABSReturns_Fund; SimAnnReturns_Total += SimAnnReturns_Fund; CAGR_Total += CAGR_Fund; Amount_weighted_Total[0] += Amount_weighted_Fund[0]; Amount_weighted_Total[1] += Amount_weighted_Fund[1]; Amount_weighted_Total[2] += Amount_weighted_Fund[2]; Amount_weighted_Total[3] += Amount_weighted_Fund[3];
                                    Units_Total += Units_Fund; Amount_Total += Amount_Fund; Positive_Amount_Total += Positive_Amount_Fund; Dividend_Payout_Total += Dividend_Payout_Fund; Present_Value_Total += Present_Value_Fund; Dividend_Amt_Total += Dividend_Amt_Fund; Notional_PL_Total += Notional_PL_Fund; NetGain_Total += NetGain_Fund;
                                }
                            }
                            DataRow _RowsGT = dt.NewRow();
                            _RowsGT["Transaction_Type"] = "Grand Total/Weighted Average :";
                            _RowsGT["Folio_Number"] = "";
                            _RowsGT["Scheme_Name"] = "";
                            _RowsGT["Transaction_Date"] = "";
                            _RowsGT["Transaction_Price"] = "";
                            _RowsGT["No_of_Units"] = Units_Total.ToString("N3");
                            _RowsGT["Purchase_Value"] = ((double)(Amount_Total - Dividend_Payout_Total)).ToString("N2");
                            _RowsGT["Current_Amount"] = Present_Value_Total.ToString("N2");
                            _RowsGT["Dividend_Payout"] = Dividend_Payout_Total.ToString("N2");
                            _RowsGT["Dividend_Reinvest"] = Dividend_Amt_Total.ToString("N2");
                            _RowsGT["Profit_Loss"] = Notional_PL_Total.ToString("N2");
                            _RowsGT["No_of_Days"] = Math.Round((Age_Total == 0 ? 0 : (Age_Total / Amount_weighted_Total[0])));
                            _RowsGT["Net_Gain"] = NetGain_Total.ToString("N2");
                            _RowsGT["Absolute_Return"] = ((double)(ABSReturns_Total == 0 ? 0 : (ABSReturns_Total / Amount_weighted_Total[1]))).ToString("N2");
                            _RowsGT["Annual_Return"] = ((double)(SimAnnReturns_Total == 0 ? 0 : (SimAnnReturns_Total / Amount_weighted_Total[2]))).ToString("N2");
                            _RowsGT["XIRR_CAGR"] = FormatFunctions.C_Format.M_FormatComma(Convert.ToString(Calculate_XIRR(Prv_ClientID, "C", "", "", Present_Value_Total)), "2", "0").ToString();
                            _RowsGT["AMC_Name"] = "";
                            _RowsGT["Series"] = "";
                            dt.Rows.Add(_RowsGT);
                            Prv_ClientID = "";
                            Age_TotalG += Age_Total; ABSReturns_TotalG += ABSReturns_Total; SimAnnReturns_TotalG += SimAnnReturns_Total; CAGR_TotalG += CAGR_Total; Amount_weighted_TotalG[0] += Amount_weighted_Total[0]; Amount_weighted_TotalG[1] += Amount_weighted_Total[1]; Amount_weighted_TotalG[2] += Amount_weighted_Total[2]; Amount_weighted_TotalG[3] += Amount_weighted_Total[3];
                            Units_TotalG += Units_Total; Amount_TotalG += Amount_Total; Positive_Amount_TotalG += Positive_Amount_Total; Dividend_Payout_TotalG += Dividend_Payout_Total; Present_Value_TotalG += Present_Value_Total; Dividend_Amt_TotalG += Dividend_Amt_Total; Notional_PL_TotalG += Notional_PL_Total; NetGain_TotalG += NetGain_Total;
                        }
                    }
                    ds.Tables.Add(dt);
                    return ds;
                }
                else
                {
                    DataTable table = new DataTable("DataTable");
                    table.Columns.Add("DataValues", typeof(string));
                    table.Rows.Add("Data Not Found!!!!");
                    ds.Tables.Add(table);
                    return ds;
                }

            }
            catch (Exception ex)
            {
                DataTable table = new DataTable("DataTable");
                table.Columns.Add("DataValues", typeof(string));
                table.Rows.Add("Data Not Found!!!!");
                ds.Tables.Add(table);

                HttpContext con = HttpContext.Current;
                cs.createfile(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.ToString() + " Method Name : " + System.Reflection.MethodBase.GetCurrentMethod().ToString(), con.Request.Url.ToString(), ex.Message.ToString(), ex.GetType().ToString(), "");
                return ds;
            }
        }

        public DataSet Portfolio_Detail_With_Redemption(DataSet ds)
        {
            string currentfolio = string.Empty;
            string currentscheme = string.Empty;
            try
            {
                if (!(ds == null || ds.Tables[0].Rows.Count == 0))
                {
                    dt.Columns.Add("Transaction_Type");
                    dt.Columns.Add("Folio_Number");
                    dt.Columns.Add("Scheme_Name");
                    dt.Columns.Add("Transaction_Date");
                    dt.Columns.Add("Transaction_Price");
                    dt.Columns.Add("No_of_Units");
                    dt.Columns.Add("Purchase_Value");
                    dt.Columns.Add("Current Amount");
                    dt.Columns.Add("Dividend Payout");
                    dt.Columns.Add("Dividend Reinvest");
                    dt.Columns.Add("Profit_Loss");
                    dt.Columns.Add("No_of_Days");
                    dt.Columns.Add("Net_Gain");
                    dt.Columns.Add("Absolute_Return");
                    dt.Columns.Add("Annual Return");
                    dt.Columns.Add("XIRR_CAGR");
                    dt.Columns.Add("AMC_Name");
                    dt.Columns.Add("SCHEMECODE");
                    dt.Columns.Add("ISIN");



                    DataTable dt_Funds = TrObj.SelectDistinct("Fund_ID", ds.Tables[0], "AMC_CODE");
                    DataTable dt_SCHEMES = TrObj.SelectDistinct("SCHEMECODE", ds.Tables[0], "SCHEMECODE");

                    DataTable dt_Clients = TrObj.SelectDistinct("Client_ID", ds.Tables[0], "Client_ID");

                    string Latest_NAV_Date = string.Empty, Latest_NAV = string.Empty;
                    double Age_TotalG, ABSReturns_TotalG, SimAnnReturns_TotalG, CAGR_TotalG, Units_TotalG, Amount_TotalG, Positive_Amount_TotalG, Dividend_Payout_TotalG, Present_Value_TotalG, Dividend_Amt_TotalG, Notional_PL_TotalG, NetGain_TotalG;
                    Age_TotalG = ABSReturns_TotalG = SimAnnReturns_TotalG = CAGR_TotalG = Units_TotalG = Amount_TotalG = Positive_Amount_TotalG = Dividend_Payout_TotalG = Present_Value_TotalG = Dividend_Amt_TotalG = Notional_PL_TotalG = NetGain_TotalG = 0;
                    float[] Amount_weighted_TotalG = new float[4];

                    foreach (DataRow dr_ClientID in dt_Clients.Rows)
                    {
                        //string Latest_NAV_Date = string.Empty, Latest_NAV = string.Empty;
                        double Age_Total, ABSReturns_Total, SimAnnReturns_Total, CAGR_Total, Units_Total, Amount_Total, Positive_Amount_Total, Dividend_Payout_Total, Present_Value_Total, Dividend_Amt_Total, Notional_PL_Total, NetGain_Total;
                        Age_Total = ABSReturns_Total = SimAnnReturns_Total = CAGR_Total = Units_Total = Amount_Total = Positive_Amount_Total = Dividend_Payout_Total = Present_Value_Total = Dividend_Amt_Total = Notional_PL_Total = NetGain_Total = 0;
                        float[] Amount_weighted_Total = new float[4];

                        DataRow[] dr_temp1 = ds.Tables[0].Select("Client_ID = '" + dr_ClientID["Client_ID"].ToString() + "'");
                        if (dr_temp1.Length > 0)
                        {
                            string Prv_ClientID = string.Empty;
                            string Prv_Fund = string.Empty;
                            foreach (DataRow dr_Funds in dt_Funds.Rows)
                            {
                                if (((DataRow[])ds.Tables[0].Select("AMC_CODE = '" + dr_Funds["AMC_CODE"].ToString() + "' and Client_ID = '" + dr_ClientID["Client_ID"].ToString() + "'")).Length > 0)
                                {
                                    string Prv_Folio = string.Empty;
                                    string Prv_Sch = string.Empty;
                                    string Prv_SchCode = string.Empty;

                                    double Age_Fund, ABSReturns_Fund, SimAnnReturns_Fund, CAGR_Fund, Units_Fund, Amount_Fund, Positive_Amount_Fund, Dividend_Payout_Fund, Present_Value_Fund, Dividend_Amt_Fund, Notional_PL_Fund, NetGain_Fund;
                                    Age_Fund = ABSReturns_Fund = SimAnnReturns_Fund = CAGR_Fund = Units_Fund = Amount_Fund = Positive_Amount_Fund = Dividend_Payout_Fund = Present_Value_Fund = Dividend_Amt_Fund = Notional_PL_Fund = NetGain_Fund = 0;
                                    float[] Amount_weighted_Fund = new float[4];

                                    foreach (DataRow dr_SCHEMES in dt_SCHEMES.Rows)
                                    {
                                        DataRow[] dr_temp = ds.Tables[0].Select("AMC_CODE = '" + dr_Funds["AMC_CODE"].ToString() + "' and SCHEMECODE = '" + dr_SCHEMES["SCHEMECODE"].ToString() + "' and Client_ID = '" + dr_ClientID["Client_ID"].ToString() + "'");
                                        double Age, ABSReturns, SimAnnReturns, CAGR, Units, Amount, Positive_Amount, Dividend_Payout, Present_Value, Dividend_Amt, Notional_PL, NetGain;
                                        Age = ABSReturns = SimAnnReturns = CAGR = Units = Amount = Positive_Amount = Dividend_Payout = Present_Value = Dividend_Amt = Notional_PL = NetGain = 0;
                                        float[] Amount_weighted = new float[4];
                                        string ASSET_TYPE = string.Empty;

                                        if (dr_temp.Length > 0)
                                        {
                                            foreach (DataRow dr in dr_temp)
                                            {
                                                if (!(Prv_Folio == dr["Folio_Number"].ToString() && Prv_Sch == dr["S_Name"].ToString()))
                                                {
                                                    Prv_ClientID = dr["Client_ID"].ToString();
                                                    if (!(Prv_Folio == string.Empty || Prv_Sch == string.Empty) && Prv_Sch == dr["S_Name"].ToString())
                                                    {
                                                        Latest_NAV_Date = (dr_temp.Length > 0 ? dr_temp[dr_temp.Length - 1]["Latest_Nav_Date"].ToString() : "--");
                                                        Latest_NAV = (dr_temp.Length > 0 ? dr_temp[dr_temp.Length - 1]["Latest_Nav"].ToString() : "--");

                                                        DataRow _RowsTT = dt.NewRow();
                                                        _RowsTT["Transaction_Type"] = "Balance in Folio :";
                                                        _RowsTT["Folio_Number"] = currentfolio.ToString();
                                                        _RowsTT["Scheme_Name"] = "NAV(" + Latest_NAV + ")" + " " + Latest_NAV_Date;
                                                        _RowsTT["Transaction_Date"] = "";
                                                        _RowsTT["Transaction_Price"] = "";
                                                        _RowsTT["No_of_Units"] = Units.ToString("N3");
                                                        _RowsTT["Purchase_Value"] = ((double)(Amount - Dividend_Payout)).ToString("N2");
                                                        _RowsTT["Current Amount"] = Present_Value.ToString("N2");
                                                        _RowsTT["Dividend Payout"] = Dividend_Payout.ToString("N2");
                                                        _RowsTT["Dividend Reinvest"] = Dividend_Amt.ToString("N2");
                                                        _RowsTT["Profit_Loss"] = Notional_PL.ToString("N2");
                                                        _RowsTT["No_of_Days"] = Math.Round((Age == 0 ? 0 : (Age / Amount_weighted[0])));
                                                        _RowsTT["Net_Gain"] = NetGain.ToString("N2");
                                                        _RowsTT["Absolute_Return"] = ((double)(ABSReturns == 0 ? 0 : (ABSReturns / Amount_weighted[1]))).ToString("N2");
                                                        _RowsTT["Annual Return"] = ((double)(SimAnnReturns == 0 ? 0 : (SimAnnReturns / Amount_weighted[2]))).ToString("N2");
                                                        _RowsTT["XIRR_CAGR"] = FormatFunctions.C_Format.M_FormatComma(Convert.ToString(Calculate_XIRR(Prv_ClientID, "C", Prv_Folio, Prv_SchCode, Present_Value)), "2", "0").ToString(); ;
                                                        _RowsTT["AMC_Name"] = "";
                                                        _RowsTT["SCHEMECODE"] = currentscheme.ToString();
                                                        _RowsTT["ISIN"] = "";
                                                        dt.Rows.Add(_RowsTT);
                                                        Age_Fund += Age; ABSReturns_Fund += ABSReturns; SimAnnReturns_Fund += SimAnnReturns; CAGR_Fund += CAGR; Amount_weighted_Fund[0] += Amount_weighted[0]; Amount_weighted_Fund[1] += Amount_weighted[1]; Amount_weighted_Fund[2] += Amount_weighted[2]; Amount_weighted_Fund[3] += Amount_weighted[3];
                                                        Units_Fund += Units; Amount_Fund += Amount; Positive_Amount_Fund += Positive_Amount; Dividend_Payout_Fund += Dividend_Payout; Present_Value_Fund += Present_Value; Dividend_Amt_Fund += Dividend_Amt; Notional_PL_Fund += Notional_PL; NetGain_Fund += NetGain;
                                                        Age = ABSReturns = SimAnnReturns = CAGR = Units = Amount = Positive_Amount = Dividend_Payout = Present_Value = Dividend_Amt = Notional_PL = NetGain = 0;
                                                        Amount_weighted = new float[4];
                                                        ASSET_TYPE = string.Empty;
                                                    }
                                                    Prv_Folio = dr["Folio_Number"].ToString();
                                                    Prv_Sch = dr["S_Name"].ToString();
                                                    Prv_SchCode = dr["schemecode"].ToString();
                                                }
                                                DataRow _Rows = dt.NewRow();
                                                _Rows["Transaction_Type"] = dr["Trxn_Type_Name"].ToString();
                                                _Rows["Folio_Number"] = currentfolio = dr["Folio_Number"].ToString();
                                                _Rows["Scheme_Name"] = dr["S_Name"].ToString();
                                                _Rows["Transaction_Date"] = dr["Trxn_Date"].ToString();
                                                _Rows["Transaction_Price"] = dr["Price"].ToString();
                                                _Rows["No_of_Units"] = dr["Units"].ToString();
                                                _Rows["Purchase_Value"] = dr["Amount"].ToString();
                                                _Rows["Current Amount"] = dr["Present_Value"].ToString();
                                                _Rows["Dividend Payout"] = dr["DivPayout"].ToString();
                                                _Rows["Dividend Reinvest"] = dr["Dividend_Amount"].ToString();
                                                _Rows["Profit_Loss"] = dr["Notional P/L"].ToString();
                                                _Rows["No_of_Days"] = dr["Age"].ToString();
                                                _Rows["Net_Gain"] = dr["NetGain"].ToString();
                                                _Rows["Absolute_Return"] = (Convert.ToDouble(dr["Absolute_Returns"].ToString()) == 0 ? "--" : dr["Absolute_Returns"].ToString());
                                                _Rows["Annual Return"] = (Convert.ToDouble(dr["Sim_Ann_Returns"].ToString()) == 0 ? "--" : dr["Sim_Ann_Returns"].ToString());
                                                _Rows["XIRR_CAGR"] = "--";
                                                _Rows["AMC_Name"] = dr["FUND"].ToString();
                                                _Rows["SCHEMECODE"] = currentscheme = dr["schemecode"].ToString();
                                                _Rows["ISIN"] = "";
                                                dt.Rows.Add(_Rows);
                                                if (Convert.ToDouble(dr["PortFolio_Unitbal"].ToString()) != 0)
                                                {
                                                    double weighted_Amount = Convert.ToDouble(dr["Amount"].ToString());
                                                    Age += Convert.ToDouble(dr["Age"].ToString()) * weighted_Amount;
                                                    ABSReturns += Convert.ToDouble(dr["Absolute_Returns"].ToString()) * weighted_Amount;
                                                    SimAnnReturns += Convert.ToDouble(dr["Sim_Ann_Returns"].ToString()) * weighted_Amount;
                                                    CAGR += Convert.ToDouble(dr["CAGR"].ToString()) * weighted_Amount;

                                                    if (Convert.ToDouble(dr["Age"].ToString()) != 0) Amount_weighted[0] += (float)weighted_Amount;
                                                    if (Convert.ToDouble(dr["Absolute_Returns"].ToString()) != 0) Amount_weighted[1] += (float)weighted_Amount;
                                                    if (Convert.ToDouble(dr["Sim_Ann_Returns"].ToString()) != 0) Amount_weighted[2] += (float)weighted_Amount;
                                                    if (Convert.ToDouble(dr["CAGR"].ToString()) != 0) Amount_weighted[3] += (float)weighted_Amount;
                                                }
                                                Units += Convert.ToDouble(dr["Units"].ToString());//
                                                Amount += Convert.ToDouble(dr["Amount"].ToString());//
                                                Positive_Amount += (Convert.ToString(dr["Trxn_Type_ID"].ToString()) == "9" || Convert.ToString(dr["Trxn_Type_ID"].ToString()) == "10") ? 0 : Convert.ToDouble(dr["Amount"].ToString());
                                                Dividend_Payout += Convert.ToDouble(dr["DivPayout"].ToString());
                                                Present_Value += Convert.ToDouble(dr["Present_Value"].ToString());
                                                Dividend_Amt += Convert.ToDouble(dr["Dividend_Amount"].ToString());
                                                Notional_PL += Convert.ToDouble(dr["Notional P/L"].ToString());
                                                NetGain += Convert.ToDouble(dr["NetGain"].ToString());
                                            }

                                            Latest_NAV_Date = (dr_temp.Length > 0 ? dr_temp[dr_temp.Length - 1]["Latest_Nav_Date"].ToString() : "--");
                                            Latest_NAV = (dr_temp.Length > 0 ? dr_temp[dr_temp.Length - 1]["Latest_Nav"].ToString() : "--");
                                            DataRow _RowsTTT = dt.NewRow();
                                            _RowsTTT["Transaction_Type"] = "Balance in Folio :";
                                            _RowsTTT["Folio_Number"] = Prv_Folio;
                                            _RowsTTT["Scheme_Name"] = "NAV(" + Latest_NAV + ")" + " " + Latest_NAV_Date;
                                            _RowsTTT["Transaction_Date"] = "";
                                            _RowsTTT["Transaction_Price"] = "";
                                            _RowsTTT["No_of_Units"] = Units.ToString("N3");
                                            _RowsTTT["Purchase_Value"] = ((double)(Amount - Dividend_Payout)).ToString("N2");
                                            _RowsTTT["Current Amount"] = Present_Value.ToString("N2");
                                            _RowsTTT["Dividend Payout"] = Dividend_Payout.ToString("N2");
                                            _RowsTTT["Dividend Reinvest"] = Dividend_Amt.ToString("N2");
                                            _RowsTTT["Profit_Loss"] = Notional_PL.ToString("N2");
                                            _RowsTTT["No_of_Days"] = Math.Round((Age == 0 ? 0 : (Age / Amount_weighted[0])));
                                            _RowsTTT["Net_Gain"] = NetGain.ToString("N2");
                                            _RowsTTT["Absolute_Return"] = ((double)(ABSReturns == 0 ? 0 : (ABSReturns / Amount_weighted[1]))).ToString("N2");
                                            _RowsTTT["Annual Return"] = ((double)(SimAnnReturns == 0 ? 0 : (SimAnnReturns / Amount_weighted[2]))).ToString("N2");
                                            _RowsTTT["XIRR_CAGR"] = FormatFunctions.C_Format.M_FormatComma(Convert.ToString(Calculate_XIRR(Prv_ClientID, "C", Prv_Folio, Prv_SchCode, Present_Value)), "2", "0").ToString();
                                            _RowsTTT["AMC_Name"] = "";
                                            _RowsTTT["SCHEMECODE"] = Prv_SchCode;
                                            _RowsTTT["ISIN"] = "";
                                            dt.Rows.Add(_RowsTTT);
                                        }



                                        Age_Fund += Age; ABSReturns_Fund += ABSReturns; SimAnnReturns_Fund += SimAnnReturns; CAGR_Fund += CAGR; Amount_weighted_Fund[0] += Amount_weighted[0]; Amount_weighted_Fund[1] += Amount_weighted[1]; Amount_weighted_Fund[2] += Amount_weighted[2]; Amount_weighted_Fund[3] += Amount_weighted[3];
                                        Units_Fund += Units; Amount_Fund += Amount; Positive_Amount_Fund += Positive_Amount; Dividend_Payout_Fund += Dividend_Payout; Present_Value_Fund += Present_Value; Dividend_Amt_Fund += Dividend_Amt; Notional_PL_Fund += Notional_PL; NetGain_Fund += NetGain;
                                    }
                                    Age_Total += Age_Fund; ABSReturns_Total += ABSReturns_Fund; SimAnnReturns_Total += SimAnnReturns_Fund; CAGR_Total += CAGR_Fund; Amount_weighted_Total[0] += Amount_weighted_Fund[0]; Amount_weighted_Total[1] += Amount_weighted_Fund[1]; Amount_weighted_Total[2] += Amount_weighted_Fund[2]; Amount_weighted_Total[3] += Amount_weighted_Fund[3];
                                    Units_Total += Units_Fund; Amount_Total += Amount_Fund; Positive_Amount_Total += Positive_Amount_Fund; Dividend_Payout_Total += Dividend_Payout_Fund; Present_Value_Total += Present_Value_Fund; Dividend_Amt_Total += Dividend_Amt_Fund; Notional_PL_Total += Notional_PL_Fund; NetGain_Total += NetGain_Fund;
                                }
                            }
                            DataRow _RowsGT = dt.NewRow();
                            _RowsGT["Transaction_Type"] = "Grand Total/Weighted Average :";
                            _RowsGT["Folio_Number"] = "";
                            _RowsGT["Scheme_Name"] = "NAV(" + Latest_NAV + ")" + " " + Latest_NAV_Date;
                            _RowsGT["Transaction_Date"] = "";
                            _RowsGT["Transaction_Price"] = "";
                            _RowsGT["No_of_Units"] = Units_Total.ToString("N3");
                            _RowsGT["Purchase_Value"] = ((double)(Amount_Total - Dividend_Payout_Total)).ToString("N2");
                            _RowsGT["Current Amount"] = Present_Value_Total.ToString("N2");
                            _RowsGT["Dividend Payout"] = Dividend_Payout_Total.ToString("N2");
                            _RowsGT["Dividend Reinvest"] = Dividend_Amt_Total.ToString("N2");
                            _RowsGT["Profit_Loss"] = Notional_PL_Total.ToString("N2");
                            _RowsGT["No_of_Days"] = Math.Round((Age_Total == 0 ? 0 : (Age_Total / Amount_weighted_Total[0])));
                            _RowsGT["Net_Gain"] = NetGain_Total.ToString("N2");
                            _RowsGT["Absolute_Return"] = ((double)(ABSReturns_Total == 0 ? 0 : (ABSReturns_Total / Amount_weighted_Total[1]))).ToString("N2");
                            _RowsGT["Annual Return"] = ((double)(SimAnnReturns_Total == 0 ? 0 : (SimAnnReturns_Total / Amount_weighted_Total[2]))).ToString("N2");
                            _RowsGT["XIRR_CAGR"] = FormatFunctions.C_Format.M_FormatComma(Convert.ToString(Calculate_XIRR(Prv_ClientID, "C", "", "", Present_Value_Total)), "2", "0").ToString();
                            _RowsGT["AMC_Name"] = "";
                            _RowsGT["SCHEMECODE"] = "";
                            _RowsGT["ISIN"] = "";
                            dt.Rows.Add(_RowsGT);

                            Prv_ClientID = "";
                            Age_TotalG += Age_Total; ABSReturns_TotalG += ABSReturns_Total; SimAnnReturns_TotalG += SimAnnReturns_Total; CAGR_TotalG += CAGR_Total; Amount_weighted_TotalG[0] += Amount_weighted_Total[0]; Amount_weighted_TotalG[1] += Amount_weighted_Total[1]; Amount_weighted_TotalG[2] += Amount_weighted_Total[2]; Amount_weighted_TotalG[3] += Amount_weighted_Total[3];
                            Units_TotalG += Units_Total; Amount_TotalG += Amount_Total; Positive_Amount_TotalG += Positive_Amount_Total; Dividend_Payout_TotalG += Dividend_Payout_Total; Present_Value_TotalG += Present_Value_Total; Dividend_Amt_TotalG += Dividend_Amt_Total; Notional_PL_TotalG += Notional_PL_Total; NetGain_TotalG += NetGain_Total;
                        }
                    }
                    ds.Tables.Add(dt);
                    return ds;
                }
                else
                {
                    DataTable table = new DataTable("DataTable");
                    table.Columns.Add("DataValues", typeof(string));
                    table.Rows.Add("Data Not Found!!!!");
                    ds.Tables.Add(table);
                    return ds;
                }

            }
            catch (Exception ex)
            {
                DataTable table = new DataTable("DataTable");
                table.Columns.Add("DataValues", typeof(string));
                table.Rows.Add("Data Not Found!!!!");
                ds.Tables.Add(table);
                HttpContext con = HttpContext.Current;
                cs.createfile(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.ToString() + " Method Name : " + System.Reflection.MethodBase.GetCurrentMethod().ToString(), con.Request.Url.ToString(), ex.Message.ToString(), ex.GetType().ToString(), "");
                return ds;
            }
        }

        public DataSet Portfolio_Redemption_Report(DataSet ds)
        {
            try
            {
                if (!(ds == null || ds.Tables[0].Rows.Count == 0))
                {
                    dt.Columns.Add("Transaction_Type");
                    dt.Columns.Add("Folio_Number");
                    dt.Columns.Add("Scheme_Name");
                    dt.Columns.Add("Transaction_Date");
                    dt.Columns.Add("Purchase_Price");
                    dt.Columns.Add("Units");
                    dt.Columns.Add("Purchase_Amount");
                    dt.Columns.Add("Sell_Date");
                    dt.Columns.Add("Sell_Type");
                    dt.Columns.Add("Sell_Rate");
                    dt.Columns.Add("Sell_Amount");
                    dt.Columns.Add("Days");
                    dt.Columns.Add("Gain_Loss");
                    dt.Columns.Add("STT");
                    dt.Columns.Add("XIIR_CAGR");
                    dt.Columns.Add("ISIN");

                    double Units_Total, P_Amount_Total, S_Amount_Total, GainLoss_Total;
                    Units_Total = P_Amount_Total = S_Amount_Total = GainLoss_Total = 0;

                    double Units_Fund, P_Amount_Fund, S_Amount_Fund, GainLoss_Fund;
                    Units_Fund = P_Amount_Fund = S_Amount_Fund = GainLoss_Fund = 0;

                    double Units, P_Amount, S_Amount, GainLoss;
                    Units = P_Amount = S_Amount = GainLoss = 0;

                    double Units_Folio, P_Amount_Folio, S_Amount_Folio, GainLoss_Folio;
                    Units_Folio = P_Amount_Folio = S_Amount_Folio = GainLoss_Folio = 0;

                    double Units_M, P_Amount_M, S_Amount_M, GainLoss_M, Days_M;
                    Units_M = P_Amount_M = S_Amount_M = GainLoss_M = Days_M = 0;

                    string Prev_Fund, Prev_Scheme, Prv_Folio, Grid_HTML_temp, Prev_trxn_type_NameP, Prev_trxn_type_NameS, Prev_Trxn_Date, Prev_Sell_Date;
                    Prev_Fund = Prev_Scheme = Prv_Folio = Grid_HTML_temp = Prev_trxn_type_NameP = Prev_trxn_type_NameS = Prev_Trxn_Date = Prev_Sell_Date = string.Empty;

                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        string Fund = dr["AMC_CODE"].ToString();//;
                        string Scheme = dr["SCHEMECODE"].ToString();//;
                        string Folio = dr["Folio_Number"].ToString();
                        string trxn_type_NameP = dr["trxn_type_NameP"].ToString();
                        string trxn_type_NameS = dr["trxn_type_NameS"].ToString();
                        string Trxn_Date = dr["Trxn_Date"].ToString();
                        string Sell_Date = dr["Sell Date"].ToString();

                        if (!(Prev_Scheme == string.Empty || Prev_Scheme == Scheme) || !(Prv_Folio == string.Empty || Prv_Folio == Folio))
                        {
                            if ((Prev_Scheme == string.Empty || Prev_Scheme != Scheme) || (Prv_Folio == string.Empty || Prv_Folio != Folio))
                            {
                                Units += Units_Folio; P_Amount += P_Amount_Folio; S_Amount += S_Amount_Folio; GainLoss += GainLoss_Folio;
                                Units_Folio = P_Amount_Folio = S_Amount_Folio = GainLoss_Folio = 0;
                            }
                            if (!(Prev_Scheme == string.Empty || Prev_Scheme == Scheme))
                            {
                                DataTable dt1 = XIRRtable(ds, Prev_Scheme, Prv_Folio);
                                Prev_trxn_type_NameP = string.Empty;
                                Prev_trxn_type_NameS = string.Empty;
                                Prev_Trxn_Date = string.Empty;
                                Prev_Sell_Date = string.Empty;
                                Units_M = P_Amount_M = S_Amount_M = GainLoss_M = Days_M = 0;

                                DataRow _RowsT = dt.NewRow();
                                _RowsT["Transaction_Type"] = "Total : ";
                                _RowsT["Folio_Number"] = "";
                                _RowsT["Scheme_Name"] = "";
                                _RowsT["Transaction_Date"] = "";
                                _RowsT["Purchase_Price"] = "";
                                _RowsT["Units"] = FormatFunctions.C_Format.M_FormatComma(Units.ToString(), "3", "N.A.");
                                _RowsT["Purchase_Amount"] = P_Amount.ToString("N2");
                                _RowsT["Sell_Date"] = "";
                                _RowsT["Sell_Type"] = "";
                                _RowsT["Sell_Rate"] = "";
                                _RowsT["Sell_Amount"] = S_Amount.ToString("N2");
                                _RowsT["Days"] = "";
                                _RowsT["Gain_Loss"] = GainLoss.ToString("N2");
                                _RowsT["STT"] = "";
                                _RowsT["XIIR_CAGR"] = FormatFunctions.C_Format.M_FormatComma(Convert.ToString(Calculate_XIRR(dt1)), "2", "0").ToString();
                                _RowsT["ISIN"] = "";
                                dt.Rows.Add(_RowsT);

                                Units_Fund += Units; P_Amount_Fund += P_Amount; S_Amount_Fund += S_Amount; GainLoss_Fund += GainLoss;
                                Units = P_Amount = S_Amount = GainLoss = 0;
                            }
                        }
                        if (!(Prev_Fund == string.Empty || Prev_Fund == Fund))
                        {
                            Units_Total += Units_Fund; P_Amount_Total += P_Amount_Fund; S_Amount_Total += S_Amount_Fund; GainLoss_Total += GainLoss_Fund;
                            Units_Fund = P_Amount_Fund = S_Amount_Fund = GainLoss_Fund = 0;
                        }
                        if (Prev_Fund == string.Empty || Prev_Fund != Fund)
                        {
                            Prev_Fund = Fund;
                        }

                        if ((Prev_Scheme == string.Empty || Prev_Scheme != Scheme) || (Prv_Folio == string.Empty || Prv_Folio != Folio))
                        {
                            Prev_Scheme = Scheme;
                            Prv_Folio = Folio;
                        }

                        DataTable dt_Funds = TrObj.SelectDistinct("Fund_ID", ds.Tables[2], "AMC_CODE");
                        DataTable dt_SCHEMES = TrObj.SelectDistinct("SCHEMECODE", ds.Tables[2], "SCHEMECODE");

                        DataTable dt_Clients = TrObj.SelectDistinct("CName", ds.Tables[2], "Name");

                        if (trxn_type_NameP == "DIVIDEND REINVESTMENT" && ((trxn_type_NameP == Prev_trxn_type_NameP || Prev_trxn_type_NameP == string.Empty) && (Trxn_Date == Prev_Trxn_Date || Prev_Trxn_Date == string.Empty)) && ((trxn_type_NameS == Prev_trxn_type_NameS || Prev_trxn_type_NameS == string.Empty) && (Sell_Date == Prev_Sell_Date || Prev_Sell_Date == string.Empty)))
                        {
                            Units_M += Convert.ToDouble(dr["Units"].ToString());
                            P_Amount_M += Convert.ToDouble(dr["Purchase Amount"].ToString());
                            S_Amount_M += Convert.ToDouble(dr["Sell Amount"].ToString());
                            GainLoss_M += dr["Gain/Loss"].ToString() == "" ? 0 : Convert.ToDouble(dr["Gain/Loss"].ToString());
                            Days_M += dr["Days"].ToString() == "" ? 0 : Convert.ToDouble(dr["Days"].ToString());

                            DataRow _Rows = dt.NewRow();
                            _Rows["Transaction_Type"] = dr["trxn_type_NameP"].ToString();
                            _Rows["Folio_Number"] = dr["Folio_Number"].ToString();
                            _Rows["Scheme_Name"] = dr["Scheme Name"].ToString();
                            _Rows["Transaction_Date"] = dr["Trxn_Date"].ToString();
                            _Rows["Purchase_Price"] = dr["Purchase Price"].ToString();
                            _Rows["Units"] = ((double)Math.Round(Units_M, 3, MidpointRounding.AwayFromZero)).ToString();
                            _Rows["Purchase_Amount"] = ((double)Math.Round(P_Amount_M, 2, MidpointRounding.AwayFromZero)).ToString();
                            _Rows["Sell_Date"] = dr["Sell Date"].ToString();
                            _Rows["Sell_Type"] = dr["Trxn_Type_NameS"].ToString();
                            _Rows["Sell_Rate"] = dr["Sell Rate"].ToString();
                            _Rows["Sell_Amount"] = ((double)Math.Round(S_Amount_M, 2, MidpointRounding.AwayFromZero)).ToString();
                            _Rows["Days"] = dr["Days"].ToString();
                            _Rows["Gain_Loss"] = ((double)Math.Round(GainLoss_M, 2, MidpointRounding.AwayFromZero)).ToString();
                            _Rows["STT"] = dr["STT"].ToString();
                            _Rows["XIIR_CAGR"] = "--";
                            _Rows["ISIN"] = dr["ISIN"].ToString();
                            dt.Rows.Add(_Rows);

                            Prev_trxn_type_NameP = dr["trxn_type_NameP"].ToString();
                            Prev_trxn_type_NameS = dr["trxn_type_NameS"].ToString();
                            Prev_Trxn_Date = dr["Trxn_Date"].ToString();
                            Prev_Sell_Date = dr["Sell Date"].ToString();
                        }
                        else
                        {

                            Prev_trxn_type_NameP = string.Empty;
                            Prev_trxn_type_NameS = string.Empty;
                            Prev_Trxn_Date = string.Empty;
                            Prev_Sell_Date = string.Empty;
                            Units_M = P_Amount_M = S_Amount_M = GainLoss_M = Days_M = 0;


                            if (trxn_type_NameP != "DIVIDEND REINVESTMENT")
                            {
                                DataRow _Rows = dt.NewRow();
                                _Rows["Transaction_Type"] = dr["trxn_type_NameP"].ToString();
                                _Rows["Folio_Number"] = dr["Folio_Number"].ToString();
                                _Rows["Scheme_Name"] = dr["Scheme Name"].ToString();
                                _Rows["Transaction_Date"] = dr["Trxn_Date"].ToString();
                                _Rows["Purchase_Price"] = dr["Purchase Price"].ToString();
                                _Rows["Units"] = dr["Units"].ToString();
                                _Rows["Purchase_Amount"] = dr["Purchase Amount"].ToString();
                                _Rows["Sell_Date"] = dr["Sell Date"].ToString();
                                _Rows["Sell_Type"] = dr["Trxn_Type_NameS"].ToString();
                                _Rows["Sell_Rate"] = dr["Sell Rate"].ToString();
                                _Rows["Sell_Amount"] = dr["Sell Amount"].ToString();
                                _Rows["Days"] = dr["Days"].ToString();
                                _Rows["Gain_Loss"] = dr["Gain/Loss"].ToString();
                                _Rows["STT"] = dr["STT"].ToString();
                                _Rows["XIIR_CAGR"] = "--";
                                _Rows["ISIN"] = dr["ISIN"].ToString();
                                dt.Rows.Add(_Rows);
                            }
                            else
                            {
                                Units_M += Convert.ToDouble(dr["Units"].ToString());
                                P_Amount_M += Convert.ToDouble(dr["Purchase Amount"].ToString());
                                S_Amount_M += Convert.ToDouble(dr["Sell Amount"].ToString());
                                GainLoss_M += dr["Gain/Loss"].ToString() == "" ? 0 : Convert.ToDouble(dr["Gain/Loss"].ToString());
                                Days_M += dr["Days"].ToString() == "" ? 0 : Convert.ToDouble(dr["Days"].ToString());

                                DataRow _Rows = dt.NewRow();
                                _Rows["Transaction_Type"] = dr["trxn_type_NameP"].ToString();
                                _Rows["Folio_Number"] = dr["Folio_Number"].ToString();
                                _Rows["Scheme_Name"] = dr["Scheme Name"].ToString();
                                _Rows["Transaction_Date"] = dr["Trxn_Date"].ToString();
                                _Rows["Purchase_Price"] = dr["Purchase Price"].ToString();
                                _Rows["Units"] = ((double)Math.Round(Units_M, 3, MidpointRounding.AwayFromZero)).ToString();
                                _Rows["Purchase_Amount"] = ((double)Math.Round(P_Amount_M, 2, MidpointRounding.AwayFromZero)).ToString();
                                _Rows["Sell_Date"] = dr["Sell Date"].ToString();
                                _Rows["Sell_Type"] = dr["Trxn_Type_NameS"].ToString();
                                _Rows["Sell_Rate"] = dr["Sell Rate"].ToString();
                                _Rows["Sell_Amount"] = ((double)Math.Round(S_Amount_M, 2, MidpointRounding.AwayFromZero)).ToString();
                                _Rows["Days"] = dr["Days"].ToString();
                                _Rows["Gain_Loss"] = ((double)Math.Round(GainLoss_M, 2, MidpointRounding.AwayFromZero)).ToString();
                                _Rows["STT"] = dr["STT"].ToString();
                                _Rows["XIIR_CAGR"] = dr["ISIN"].ToString();
                                dt.Rows.Add(_Rows);

                                Prev_trxn_type_NameP = dr["trxn_type_NameP"].ToString();
                                Prev_trxn_type_NameS = dr["trxn_type_NameS"].ToString();
                                Prev_Trxn_Date = dr["Trxn_Date"].ToString();
                                Prev_Sell_Date = dr["Sell Date"].ToString();
                            }
                        }
                        Units_Folio += Convert.ToDouble(dr["Units"].ToString());
                        P_Amount_Folio += Convert.ToDouble(dr["Purchase Amount"].ToString());
                        S_Amount_Folio += Convert.ToDouble(dr["Sell Amount"].ToString());
                        GainLoss_Folio += dr["Gain/Loss"].ToString() == "" ? 0 : Convert.ToDouble(dr["Gain/Loss"].ToString());
                    }
                    Units += Units_Folio; P_Amount += P_Amount_Folio; S_Amount += S_Amount_Folio; GainLoss += GainLoss_Folio;
                    Units_Fund += Units; P_Amount_Fund += P_Amount; S_Amount_Fund += S_Amount; GainLoss_Fund += GainLoss;
                    Units_Total += Units_Fund; P_Amount_Total += P_Amount_Fund; S_Amount_Total += S_Amount_Fund; GainLoss_Total += GainLoss_Fund;

                    DataTable dt2 = XIRRtable(ds, Prev_Scheme, Prv_Folio);

                    DataRow _RowsTT = dt.NewRow();
                    _RowsTT["Transaction_Type"] = "Total : ";
                    _RowsTT["Folio_Number"] = "";
                    _RowsTT["Scheme_Name"] = "";
                    _RowsTT["Transaction_Date"] = "";
                    _RowsTT["Purchase_Price"] = "";
                    _RowsTT["Units"] = FormatFunctions.C_Format.M_FormatComma(Units.ToString(), "3", "N.A.");
                    _RowsTT["Purchase_Amount"] = P_Amount.ToString("N2");
                    _RowsTT["Sell_Date"] = "";
                    _RowsTT["Sell_Type"] = "";
                    _RowsTT["Sell_Rate"] = "";
                    _RowsTT["Sell_Amount"] = S_Amount.ToString("N2");
                    _RowsTT["Days"] = "";
                    _RowsTT["Gain_Loss"] = Math.Round(GainLoss, 2);
                    _RowsTT["STT"] = "";
                    _RowsTT["XIIR_CAGR"] = FormatFunctions.C_Format.M_FormatComma(Convert.ToString(Calculate_XIRR(dt2)), "2", "0").ToString();
                    _RowsTT["ISIN"] = "";
                    dt.Rows.Add(_RowsTT);

                    dt2 = XIRRtable(ds, "", "");

                    DataRow _RowsGT = dt.NewRow();
                    _RowsGT["Transaction_Type"] = "Grand Total : ";
                    _RowsGT["Folio_Number"] = "";
                    _RowsGT["Scheme_Name"] = "";
                    _RowsGT["Transaction_Date"] = "";
                    _RowsGT["Purchase_Price"] = "";
                    _RowsGT["Units"] = FormatFunctions.C_Format.M_FormatComma(Units_Total.ToString(), "3", "N.A.");
                    _RowsGT["Purchase_Amount"] = P_Amount_Total.ToString("N2");
                    _RowsGT["Sell_Date"] = "";
                    _RowsGT["Sell_Type"] = "";
                    _RowsGT["Sell_Rate"] = "";
                    _RowsGT["Sell_Amount"] = S_Amount_Total.ToString("N2");
                    _RowsGT["Days"] = "";
                    _RowsGT["Gain_Loss"] = GainLoss_Total.ToString("N2");
                    _RowsGT["STT"] = "";
                    _RowsGT["XIIR_CAGR"] = FormatFunctions.C_Format.M_FormatComma(Convert.ToString(Calculate_XIRR(dt2)), "2", "0").ToString();
                    _RowsGT["ISIN"] = "";
                    dt.Rows.Add(_RowsGT);

                    ds.Tables.Add(dt);
                    return ds;
                }
                else
                {
                    DataTable table = new DataTable("DataTable");
                    table.Columns.Add("DataValues", typeof(string));
                    table.Rows.Add("Data Not Found!!!!");
                    ds.Tables.Add(table);
                    return ds;
                }

            }
            catch (Exception ex)
            {
                DataTable table = new DataTable("DataTable");
                table.Columns.Add("DataValues", typeof(string));
                table.Rows.Add("Data Not Found!!!!");
                ds.Tables.Add(table);
                HttpContext con = HttpContext.Current;
                cs.createfile(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.ToString() + " Method Name : " + System.Reflection.MethodBase.GetCurrentMethod().ToString(), con.Request.Url.ToString(), ex.Message.ToString(), ex.GetType().ToString(), "");
                return ds;
            }
        }

        public DataSet Dividend_Detail_Report(DataSet ds)
        {
            try
            {
                if (!(ds == null || ds.Tables[2].Rows.Count == 0))
                {

                    dt.Columns.Add("Scheme_name");
                    dt.Columns.Add("Folio_Number");
                    dt.Columns.Add("Transaction_Date");
                    dt.Columns.Add("Dividend_Nature");
                    dt.Columns.Add("Amount");
                    dt.Columns.Add("ISIN");
                    DataTable dt_Name = TrObj.SelectDistinct("Investor_Name", ds.Tables[0], "Client_ID");
                    DataTable dt_Funds = TrObj.SelectDistinct("Fund_ID", ds.Tables[0], "AMC_CODE");
                    DataTable dt_SCHEMES = TrObj.SelectDistinct("SCHEMECODE", ds.Tables[0], "SCHEMECODE");
                    DataTable dt_Folio = TrObj.SelectDistinct("FolioNumber", ds.Tables[0], "Folio_Number");

                    double InvAmt_R, InvAmt_P, InvAmt_TR, InvAmt_TP, Amt_GTR, Amt_GTP;
                    InvAmt_R = InvAmt_P = InvAmt_TR = InvAmt_TP = Amt_GTR = Amt_GTP = 0;
                    string Prv_Folio = string.Empty;
                    foreach (DataRow dr_Name in dt_Name.Rows)
                    {
                        InvAmt_TR = 0;
                        InvAmt_TP = 0;
                        foreach (DataRow dr_Folio in dt_Folio.Rows)
                        {
                            foreach (DataRow dr_Funds in dt_Funds.Rows)
                            {
                                foreach (DataRow dr_SCHEMES in dt_SCHEMES.Rows)
                                {
                                    InvAmt_P = 0;
                                    InvAmt_R = 0;

                                    DataRow[] dr_temp = ds.Tables[0].Select("Client_ID = '" + dr_Name["Client_ID"].ToString() + "' and Folio_Number = '" + dr_Folio["Folio_Number"].ToString() + "' and AMC_CODE = '" + dr_Funds["AMC_CODE"].ToString() + "' and SCHEMECODE = '" + dr_SCHEMES["SCHEMECODE"].ToString() + "'");
                                    //((DataRow[])ds.Tables[0].Select("AMC_CODE = '" + dr_Funds["AMC_CODE"].ToString() + "' and SCHEMECODE = '" + dr_SCHEMES["SCHEMECODE"].ToString() + "'"))[0]["Scheme Name"].ToString()
                                    if (dr_temp.Length > 0)
                                    {
                                        foreach (DataRow dr in dr_temp)
                                        {
                                            if (dr["Trxn_ID"].ToString() == "9")
                                            {
                                                DataRow _Rows = dt.NewRow();
                                                _Rows["Scheme_name"] = dr["Scheme Name"];
                                                _Rows["Folio_Number"] = "Folio Number: " + dr["Folio_Number"];
                                                _Rows["Transaction_Date"] = dr["Trxn_Date"];
                                                _Rows["Dividend_Nature"] = dr["Trxn_Type_NameP"];
                                                _Rows["Amount"] = Math.Round(Convert.ToDouble(dr["Purchase Amount"]), 2);
                                                _Rows["ISIN"] = dr["ISIN"];
                                                dt.Rows.Add(_Rows);

                                                InvAmt_R += Convert.ToDouble(dr["Purchase Amount"].ToString());
                                                Prv_Folio = Convert.ToString(dr["Folio_Number"]);
                                            }
                                        }
                                        if (InvAmt_R != 0)
                                        {
                                            DataRow _RowsT = dt.NewRow();
                                            _RowsT["Scheme_name"] = "Scheme Total:";
                                            _RowsT["Folio_Number"] = "";
                                            _RowsT["Transaction_Date"] = "";
                                            _RowsT["Dividend_Nature"] = "";
                                            _RowsT["Amount"] = (Math.Round(InvAmt_R, 2)).ToString();
                                            _RowsT["ISIN"] = "";
                                            dt.Rows.Add(_RowsT);
                                        }


                                        foreach (DataRow dr in dr_temp)
                                        {
                                            if (dr["Trxn_ID"].ToString() == "10")
                                            {
                                                DataRow _Rows = dt.NewRow();
                                                _Rows["Scheme_name"] = dr["Scheme Name"];
                                                _Rows["Folio_Number"] = "Folio Number: " + dr["Folio_Number"];
                                                _Rows["Transaction_Date"] = dr["Trxn_Date"];
                                                _Rows["Dividend_Nature"] = dr["Trxn_Type_NameP"];
                                                _Rows["Amount"] = Math.Round(Convert.ToDouble(dr["Purchase Amount"]), 2);
                                                _Rows["ISIN"] = dr["ISIN"];
                                                dt.Rows.Add(_Rows);

                                                InvAmt_P += Convert.ToDouble(dr["Purchase Amount"].ToString());
                                                Prv_Folio = Convert.ToString(dr["Folio_Number"]);
                                            }
                                        }
                                        if (InvAmt_P != 0)
                                        {
                                            DataRow _RowsT = dt.NewRow();
                                            _RowsT["Scheme_name"] = "Scheme Total:";
                                            _RowsT["Folio_Number"] = "";
                                            _RowsT["Transaction_Date"] = "";
                                            _RowsT["Dividend_Nature"] = "";
                                            _RowsT["Amount"] = (Math.Round(InvAmt_R, 2)).ToString();
                                            _RowsT["ISIN"] = "";
                                            dt.Rows.Add(_RowsT);
                                        }
                                    }

                                    InvAmt_TR += InvAmt_R;
                                    InvAmt_TP += InvAmt_P;
                                }
                            }
                        }

                        DataRow _RowsGT = dt.NewRow();
                        _RowsGT["Scheme_name"] = "Grand Total:";
                        _RowsGT["Folio_Number"] = "Re-investment :";
                        _RowsGT["Transaction_Date"] = "";
                        _RowsGT["Dividend_Nature"] = "";
                        _RowsGT["Amount"] = (Math.Round(InvAmt_TR, 2)).ToString();
                        dt.Rows.Add(_RowsGT);

                        DataRow _RowsPT = dt.NewRow();
                        _RowsPT["Scheme_name"] = "";
                        _RowsPT["Folio_Number"] = "Pay Out:";
                        _RowsPT["Transaction_Date"] = "";
                        _RowsPT["Dividend_Nature"] = "";
                        _RowsPT["Amount"] = (Math.Round(InvAmt_TP, 2)).ToString();
                        dt.Rows.Add(_RowsPT);

                        Amt_GTR += InvAmt_TR;
                        Amt_GTP += InvAmt_TP;
                    }
                    ds.Tables.Add(dt);
                    return ds;
                }
                else
                {
                    DataTable table = new DataTable("DataTable");
                    table.Columns.Add("DataValues", typeof(string));
                    table.Rows.Add("Data Not Found!!!!");
                    ds.Tables.Add(table);
                    return ds;
                }

            }
            catch (Exception ex)
            {
                DataTable table = new DataTable("DataTable");
                table.Columns.Add("DataValues", typeof(string));
                table.Rows.Add("Data Not Found!!!!");
                ds.Tables.Add(table);
                HttpContext con = HttpContext.Current;
                cs.createfile(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.ToString() + " Method Name : " + System.Reflection.MethodBase.GetCurrentMethod().ToString(), con.Request.Url.ToString(), ex.Message.ToString(), ex.GetType().ToString(), "");
                return ds;
            }
        }

        public DataSet Dividend_Summary_Report(DataSet ds)
        {
            try
            {
                if (!(ds == null || ds.Tables[0].Rows.Count == 0))
                {
                    dt.Columns.Add("Scheme_name");
                    dt.Columns.Add("Folio_Number");
                    dt.Columns.Add("Transaction_Date");
                    dt.Columns.Add("Dividend_Nature");
                    dt.Columns.Add("Amount");
                    dt.Columns.Add("ISIN");
                    DataTable dt_Name = TrObj.SelectDistinct("Investor_Name", ds.Tables[0], "Client_ID");
                    DataTable dt_Funds = TrObj.SelectDistinct("Fund_ID", ds.Tables[0], "AMC_CODE");
                    DataTable dt_SCHEMES = TrObj.SelectDistinct("SCHEMECODE", ds.Tables[0], "SCHEMECODE");
                    DataTable dt_Folio = TrObj.SelectDistinct("FolioNumber", ds.Tables[0], "Folio_Number");

                    double InvAmt_R, InvAmt_P, InvAmt_TR, InvAmt_TP, Amt_GTR, Amt_GTP;
                    InvAmt_R = InvAmt_P = InvAmt_TR = InvAmt_TP = Amt_GTR = Amt_GTP = 0;
                    string Prv_Folio = string.Empty;
                    string Prv_Scheme = string.Empty;
                    foreach (DataRow dr_Name in dt_Name.Rows)
                    {
                        InvAmt_TR = 0;
                        InvAmt_TP = 0;

                        foreach (DataRow dr_Folio in dt_Folio.Rows)
                        {
                            foreach (DataRow dr_Funds in dt_Funds.Rows)
                            {

                                foreach (DataRow dr_SCHEMES in dt_SCHEMES.Rows)
                                {
                                    InvAmt_R = 0;
                                    InvAmt_P = 0;

                                    DataRow[] dr_temp = ds.Tables[0].Select("Client_ID = '" + dr_Name["Client_ID"].ToString() + "' and Folio_Number = '" + dr_Folio["Folio_Number"].ToString() + "' and AMC_CODE = '" + dr_Funds["AMC_CODE"].ToString() + "' and SCHEMECODE = '" + dr_SCHEMES["SCHEMECODE"].ToString() + "'");
                                    if (dr_temp.Length > 0)
                                    {
                                        foreach (DataRow dr in dr_temp)
                                        {
                                            if (dr["Trxn_ID"].ToString() == "9")
                                            {

                                                InvAmt_R += Convert.ToDouble(dr["Purchase Amount"].ToString());
                                                Prv_Folio = Convert.ToString(dr["Folio_Number"]);
                                                Prv_Scheme = Convert.ToString(dr["Scheme Name"]);
                                            }
                                        }
                                        if (InvAmt_R != 0)
                                        {
                                            DataRow _Rows = dt.NewRow();
                                            _Rows["Scheme_name"] = Prv_Scheme;
                                            _Rows["Folio_Number"] = Prv_Folio;
                                            _Rows["Transaction_Date"] = "";
                                            _Rows["Dividend_Nature"] = "DIVIDEND REINVESTMENT";
                                            _Rows["Amount"] = String.Format("{0:0.00}", InvAmt_R);
                                            _Rows["ISIN"] = "";
                                            dt.Rows.Add(_Rows);

                                            DataRow _RowsT = dt.NewRow();
                                            _RowsT["Scheme_name"] = "Scheme Total:";
                                            _RowsT["Folio_Number"] = "";
                                            _RowsT["Transaction_Date"] = "";
                                            _RowsT["Dividend_Nature"] = "";
                                            _RowsT["Amount"] = String.Format("{0:0.00}", InvAmt_R);
                                            _RowsT["ISIN"] = "";
                                            dt.Rows.Add(_RowsT);
                                        }


                                        foreach (DataRow dr in dr_temp)
                                        {
                                            if (dr["Trxn_ID"].ToString() == "10")
                                            {
                                                InvAmt_P += Convert.ToDouble(dr["Purchase Amount"].ToString());
                                            }
                                        }
                                        if (InvAmt_P != 0)
                                        {
                                            DataRow _Rows = dt.NewRow();
                                            _Rows["Scheme_name"] = "";
                                            _Rows["Folio_Number"] = "";
                                            _Rows["Transaction_Date"] = "";
                                            _Rows["Dividend_Nature"] = "DIVIDEND PAYOUT";
                                            _Rows["Amount"] = String.Format("{0:0.00}", InvAmt_P);
                                            _Rows["ISIN"] = "";
                                            dt.Rows.Add(_Rows);

                                            DataRow _RowsT = dt.NewRow();
                                            _RowsT["Scheme_name"] = "Scheme Total:";
                                            _RowsT["Folio_Number"] = "";
                                            _RowsT["Transaction_Date"] = "";
                                            _RowsT["Dividend_Nature"] = "";
                                            _RowsT["Amount"] = String.Format("{0:0.00}", InvAmt_P);
                                            _RowsT["ISIN"] = "";
                                            dt.Rows.Add(_RowsT);
                                        }
                                    }

                                    InvAmt_TR += InvAmt_R;
                                    InvAmt_TP += InvAmt_P;
                                }
                            }
                        }
                        DataRow _RowsGT = dt.NewRow();
                        _RowsGT["Scheme_name"] = "";
                        _RowsGT["Folio_Number"] = "";
                        _RowsGT["Transaction_Date"] = "Grand Total:";
                        _RowsGT["Dividend_Nature"] = "Re-investment :";
                        _RowsGT["Amount"] = String.Format("{0:0.00}", InvAmt_TR);
                        _RowsGT["ISIN"] = "";
                        dt.Rows.Add(_RowsGT);

                        DataRow _RowsPT = dt.NewRow();
                        _RowsPT["Scheme_name"] = "";
                        _RowsPT["Folio_Number"] = "";
                        _RowsPT["Transaction_Date"] = "";
                        _RowsPT["Dividend_Nature"] = "Pay Out:";
                        _RowsPT["Amount"] = String.Format("{0:0.00}", InvAmt_TP, 2);
                        _RowsPT["ISIN"] = "";
                        dt.Rows.Add(_RowsPT);
                        Amt_GTR += InvAmt_TR;
                        Amt_GTP += InvAmt_TP;
                    }

                    ds.Tables.Add(dt);
                    return ds;
                }
                else
                {
                    DataTable table = new DataTable("DataTable");
                    table.Columns.Add("DataValues", typeof(string));
                    table.Rows.Add("Data Not Found!!!!");
                    ds.Tables.Add(table);
                    return ds;
                }

            }
            catch (Exception ex)
            {
                DataTable table = new DataTable("DataTable");
                table.Columns.Add("DataValues", typeof(string));
                table.Rows.Add("Data Not Found!!!!");
                ds.Tables.Add(table);
                HttpContext con = HttpContext.Current;
                cs.createfile(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.ToString() + " Method Name : " + System.Reflection.MethodBase.GetCurrentMethod().ToString(), con.Request.Url.ToString(), ex.Message.ToString(), ex.GetType().ToString(), "");
                return ds;
            }
        }

        public DataSet GainLossReport(DataSet ds)
        {
            try
            {
                if (!(ds == null || ds.Tables[0].Rows.Count == 0))
                {
                    dt.Columns.Add("Fund_Name");
                    dt.Columns.Add("Scheme_Name");
                    dt.Columns.Add("Folio_Number");
                    dt.Columns.Add("Transaction_Type");
                    dt.Columns.Add("Transaction_Date");
                    dt.Columns.Add("Purchase_Price");
                    dt.Columns.Add("Units");
                    dt.Columns.Add("Purchase_Amount");
                    dt.Columns.Add("Sell_Date");
                    dt.Columns.Add("Sell_Type");
                    dt.Columns.Add("Sell_Rate");
                    dt.Columns.Add("Sell_Amount");
                    dt.Columns.Add("Days");
                    dt.Columns.Add("GL_ST_Debt");
                    dt.Columns.Add("GL_ST_Equity");
                    dt.Columns.Add("GL_LT_Debt");
                    dt.Columns.Add("GL_LT_Equity");
                    dt.Columns.Add("STT");
                    dt.Columns.Add("ISIN");

                    double Units_Total, P_Amount_Total, S_Amount_Total, NonEGL_ST_Total, EGNL_ST_Total, NonEGL_LT_Total, EGNL_LT_Total;
                    Units_Total = P_Amount_Total = S_Amount_Total = NonEGL_ST_Total = EGNL_ST_Total = NonEGL_LT_Total = EGNL_LT_Total = 0;

                    double Units_Fund, P_Amount_Fund, S_Amount_Fund, NonEGL_ST_Fund, EGNL_ST_Fund, NonEGL_LT_Fund, EGNL_LT_Fund;
                    Units_Fund = P_Amount_Fund = S_Amount_Fund = NonEGL_ST_Fund = EGNL_ST_Fund = NonEGL_LT_Fund = EGNL_LT_Fund = 0;

                    double Units, P_Amount, S_Amount, NonEGL_ST, EGNL_ST, NonEGL_LT, EGNL_LT;
                    Units = P_Amount = S_Amount = NonEGL_ST = EGNL_ST = NonEGL_LT = EGNL_LT = 0;

                    double Units_Folio, P_Amount_Folio, S_Amount_Folio, NonEGL_ST_Folio, EGNL_ST_Folio, NonEGL_LT_Folio, EGNL_LT_Folio;
                    Units_Folio = P_Amount_Folio = S_Amount_Folio = NonEGL_ST_Folio = EGNL_ST_Folio = NonEGL_LT_Folio = EGNL_LT_Folio = 0;

                    double Units_M, P_Amount_M, S_Amount_M, NonEGL_ST_M, EGNL_ST_M, NonEGL_LT_M, EGNL_LT_M, Days_M;
                    Units_M = P_Amount_M = S_Amount_M = NonEGL_ST_M = EGNL_ST_M = NonEGL_LT_M = EGNL_LT_M = Days_M = 0;

                    string Prev_Fund, Prev_Scheme, Prv_Folio, Grid_HTML_temp, Prev_trxn_type_NameP, Prev_trxn_type_NameS, Prev_Trxn_Date, Prev_Sell_Date;
                    Prev_Fund = Prev_Scheme = Prv_Folio = Grid_HTML_temp = Prev_trxn_type_NameP = Prev_trxn_type_NameS = Prev_Trxn_Date = Prev_Sell_Date = string.Empty;

                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        string Fund = dr["AMC_CODE"].ToString();//;
                        string Scheme = dr["SCHEMECODE"].ToString();//;
                        string Folio = dr["Folio_Number"].ToString();
                        string trxn_type_NameP = dr["trxn_type_NameP"].ToString();
                        string trxn_type_NameS = dr["trxn_type_NameS"].ToString();
                        string Trxn_Date = dr["Trxn_Date"].ToString();
                        string Sell_Date = dr["Sell Date"].ToString();

                        if (!(Prev_Scheme == string.Empty || Prev_Scheme == Scheme) || !(Prv_Folio == string.Empty || Prv_Folio == Folio))
                        {
                            if ((Prev_Scheme == string.Empty || Prev_Scheme != Scheme) || (Prv_Folio == string.Empty || Prv_Folio != Folio))
                            {
                                Units += Units_Folio; P_Amount += P_Amount_Folio; S_Amount += S_Amount_Folio; NonEGL_ST += NonEGL_ST_Folio; EGNL_ST += EGNL_ST_Folio; NonEGL_LT += NonEGL_LT_Folio; EGNL_LT += EGNL_LT_Folio;
                                Units_Folio = P_Amount_Folio = S_Amount_Folio = NonEGL_ST_Folio = EGNL_ST_Folio = NonEGL_LT_Folio = EGNL_LT_Folio = 0;
                            }
                            if (!(Prev_Scheme == string.Empty || Prev_Scheme == Scheme))
                            {
                                Prev_trxn_type_NameP = string.Empty;
                                Prev_trxn_type_NameS = string.Empty;
                                Prev_Trxn_Date = string.Empty;
                                Prev_Sell_Date = string.Empty;
                                Units_M = P_Amount_M = S_Amount_M = NonEGL_ST_M = EGNL_ST_M = NonEGL_LT_M = EGNL_LT_M = Days_M = 0;

                                DataRow _TRows = dt.NewRow();
                                _TRows["Fund_Name"] = "FundTotal :";
                                _TRows["Scheme_Name"] = "";
                                _TRows["Folio_Number"] = "";
                                _TRows["Transaction_Type"] = "";
                                _TRows["Transaction_Date"] = "";
                                _TRows["Purchase_Price"] = "";
                                _TRows["Units"] = FormatFunctions.C_Format.M_FormatComma(Units.ToString(), "3", "N.A.");
                                _TRows["Purchase_Amount"] = P_Amount.ToString("N2");
                                _TRows["Sell_Date"] = "";
                                _TRows["Sell_Type"] = "";
                                _TRows["Sell_Rate"] = "";
                                _TRows["Sell_Amount"] = S_Amount.ToString("N2");
                                _TRows["Days"] = "";
                                _TRows["GL_ST_Debt"] = NonEGL_ST.ToString("N2");
                                _TRows["GL_ST_Equity"] = EGNL_ST.ToString("N2");
                                _TRows["GL_LT_Debt"] = NonEGL_LT.ToString("N2");
                                _TRows["GL_LT_Equity"] = EGNL_LT.ToString("N2");
                                _TRows["STT"] = "";
                                _TRows["ISIN"] = "";
                                dt.Rows.Add(_TRows);

                                Units_Fund += Units; P_Amount_Fund += P_Amount; S_Amount_Fund += S_Amount; NonEGL_ST_Fund += NonEGL_ST; EGNL_ST_Fund += EGNL_ST; NonEGL_LT_Fund += NonEGL_LT; EGNL_LT_Fund += EGNL_LT;
                                Units = P_Amount = S_Amount = NonEGL_ST = EGNL_ST = NonEGL_LT = EGNL_LT = 0;
                            }
                        }
                        if (!(Prev_Fund == string.Empty || Prev_Fund == Fund))
                        {
                            Units_Total += Units_Fund; P_Amount_Total += P_Amount_Fund; S_Amount_Total += S_Amount_Fund; NonEGL_ST_Total += NonEGL_ST_Fund; EGNL_ST_Total += EGNL_ST_Fund; NonEGL_LT_Total += NonEGL_LT_Fund; EGNL_LT_Total += EGNL_LT_Fund;
                            Units_Fund = P_Amount_Fund = S_Amount_Fund = NonEGL_ST_Fund = EGNL_ST_Fund = NonEGL_LT_Fund = EGNL_LT_Fund = 0;
                        }
                        if (Prev_Fund == string.Empty || Prev_Fund != Fund)
                        {
                            Prev_Fund = Fund;
                        }
                        if ((Prev_Scheme == string.Empty || Prev_Scheme != Scheme) || (Prv_Folio == string.Empty || Prv_Folio != Folio))
                        {
                            Prev_Scheme = Scheme;
                            Prv_Folio = Folio;
                        }
                        if (trxn_type_NameP == "DIVIDEND REINVESTMENT" && ((trxn_type_NameP == Prev_trxn_type_NameP || Prev_trxn_type_NameP == string.Empty) && (Trxn_Date == Prev_Trxn_Date || Prev_Trxn_Date == string.Empty)) && ((trxn_type_NameS == Prev_trxn_type_NameS || Prev_trxn_type_NameS == string.Empty) && (Sell_Date == Prev_Sell_Date || Prev_Sell_Date == string.Empty)))
                        {
                            Units_M += Convert.ToDouble(dr["Units"].ToString());
                            P_Amount_M += Convert.ToDouble(dr["Purchase Amount"].ToString());
                            S_Amount_M += Convert.ToDouble(dr["Sell Amount"].ToString());
                            NonEGL_ST_M += dr["G/L ST(Non Equity)"].ToString() == "" ? 0 : Convert.ToDouble(dr["G/L ST(Non Equity)"].ToString());
                            EGNL_ST_M += dr["G/L ST(Equity)"].ToString() == "" ? 0 : Convert.ToDouble(dr["G/L ST(Equity)"].ToString());
                            NonEGL_LT_M += dr["G/L LT(Non Equity)"].ToString() == "" ? 0 : Convert.ToDouble(dr["G/L LT(Non Equity)"].ToString());
                            EGNL_LT_M += dr["G/L LT(Equity)"].ToString() == "" ? 0 : Convert.ToDouble(dr["G/L LT(Equity)"].ToString());
                            Days_M += dr["Days"].ToString() == "" ? 0 : Convert.ToDouble(dr["Days"].ToString());
                            DataRow _Rows = dt.NewRow();
                            _Rows["Fund_Name"] = dr["Scheme Name"].ToString();
                            _Rows["Scheme_Name"] = dr["Fund"].ToString();
                            _Rows["Folio_Number"] = dr["Folio_Number"].ToString();
                            _Rows["Transaction_Type"] = dr["trxn_type_NameP"].ToString();
                            _Rows["Transaction_Date"] = dr["Trxn_Date"].ToString();
                            _Rows["Purchase_Price"] = dr["Purchase Price"].ToString();
                            _Rows["Units"] = ((double)Math.Round(Units_M, 3, MidpointRounding.AwayFromZero)).ToString();
                            _Rows["Purchase_Amount"] = ((double)Math.Round(P_Amount_M, 2, MidpointRounding.AwayFromZero)).ToString();
                            _Rows["Sell_Date"] = dr["Sell Date"].ToString();
                            _Rows["Sell_Type"] = dr["Trxn_Type_NameS"].ToString();
                            _Rows["Sell_Rate"] = dr["Sell Rate"].ToString();
                            _Rows["Sell_Amount"] = ((double)Math.Round(S_Amount_M, 2, MidpointRounding.AwayFromZero)).ToString();
                            _Rows["Days"] = dr["Days"].ToString();
                            _Rows["GL_ST_Debt"] = ((double)Math.Round(NonEGL_ST_M, 2, MidpointRounding.AwayFromZero)).ToString();
                            _Rows["GL_ST_Equity"] = ((double)Math.Round(EGNL_ST_M, 2, MidpointRounding.AwayFromZero)).ToString();
                            _Rows["GL_LT_Debt"] = ((double)Math.Round(NonEGL_LT_M, 2, MidpointRounding.AwayFromZero)).ToString();
                            _Rows["GL_LT_Equity"] = ((double)Math.Round(EGNL_LT_M, 2, MidpointRounding.AwayFromZero)).ToString();
                            _Rows["STT"] = dr["STT"].ToString();
                            _Rows["ISIN"] = dr["ISIN"].ToString();
                            dt.Rows.Add(_Rows);

                            Prev_trxn_type_NameP = dr["trxn_type_NameP"].ToString();
                            Prev_trxn_type_NameS = dr["trxn_type_NameS"].ToString();
                            Prev_Trxn_Date = dr["Trxn_Date"].ToString();
                            Prev_Sell_Date = dr["Sell Date"].ToString();
                        }
                        else
                        {
                            Prev_trxn_type_NameP = string.Empty;
                            Prev_trxn_type_NameS = string.Empty;
                            Prev_Trxn_Date = string.Empty;
                            Prev_Sell_Date = string.Empty;
                            Units_M = P_Amount_M = S_Amount_M = NonEGL_ST_M = EGNL_ST_M = NonEGL_LT_M = EGNL_LT_M = Days_M = 0;

                            if (trxn_type_NameP != "DIVIDEND REINVESTMENT")
                            {
                                DataRow _Rows = dt.NewRow();
                                _Rows["Fund_Name"] = dr["Scheme Name"].ToString();
                                _Rows["Scheme_Name"] = dr["Fund"].ToString();
                                _Rows["Folio_Number"] = dr["Folio_Number"].ToString();
                                _Rows["Transaction_Type"] = dr["trxn_type_NameP"].ToString();
                                _Rows["Transaction_Date"] = dr["Trxn_Date"].ToString();
                                _Rows["Purchase_Price"] = dr["Purchase Price"].ToString();
                                _Rows["Units"] = dr["Units"].ToString();
                                _Rows["Purchase_Amount"] = dr["Purchase Amount"].ToString();
                                _Rows["Sell_Date"] = dr["Sell Date"].ToString();
                                _Rows["Sell_Type"] = dr["Trxn_Type_NameS"].ToString();
                                _Rows["Sell_Rate"] = dr["Sell Rate"].ToString();
                                _Rows["Sell_Amount"] = dr["Sell Amount"].ToString();
                                _Rows["Days"] = dr["Days"].ToString();
                                _Rows["GL_ST_Debt"] = dr["G/L ST(Non Equity)"].ToString();
                                _Rows["GL_ST_Equity"] = dr["G/L ST(Equity)"].ToString();
                                _Rows["GL_LT_Debt"] = dr["G/L LT(Non Equity)"].ToString();
                                _Rows["GL_LT_Equity"] = dr["G/L LT(Equity)"].ToString();
                                _Rows["STT"] = dr["STT"].ToString();
                                _Rows["ISIN"] = dr["ISIN"].ToString();
                                dt.Rows.Add(_Rows);
                            }
                            else
                            {
                                Units_M += Convert.ToDouble(dr["Units"].ToString());
                                P_Amount_M += Convert.ToDouble(dr["Purchase Amount"].ToString());
                                S_Amount_M += Convert.ToDouble(dr["Sell Amount"].ToString());
                                NonEGL_ST_M += dr["G/L ST(Non Equity)"].ToString() == "" ? 0 : Convert.ToDouble(dr["G/L ST(Non Equity)"].ToString());
                                EGNL_ST_M += dr["G/L ST(Equity)"].ToString() == "" ? 0 : Convert.ToDouble(dr["G/L ST(Equity)"].ToString());
                                NonEGL_LT_M += dr["G/L LT(Non Equity)"].ToString() == "" ? 0 : Convert.ToDouble(dr["G/L LT(Non Equity)"].ToString());
                                EGNL_LT_M += dr["G/L LT(Equity)"].ToString() == "" ? 0 : Convert.ToDouble(dr["G/L LT(Equity)"].ToString());
                                Days_M += dr["Days"].ToString() == "" ? 0 : Convert.ToDouble(dr["Days"].ToString());

                                DataRow _Rows = dt.NewRow();
                                _Rows["Fund_Name"] = dr["Scheme Name"].ToString();
                                _Rows["Scheme_Name"] = dr["Fund"].ToString();
                                _Rows["Folio_Number"] = Prv_Folio;
                                _Rows["Transaction_Type"] = dr["trxn_type_NameP"].ToString();
                                _Rows["Transaction_Date"] = dr["Trxn_Date"].ToString();
                                _Rows["Purchase_Price"] = dr["Purchase Price"].ToString();
                                _Rows["Units"] = ((double)Math.Round(Units_M, 3, MidpointRounding.AwayFromZero)).ToString();
                                _Rows["Purchase_Amount"] = ((double)Math.Round(P_Amount_M, 2, MidpointRounding.AwayFromZero)).ToString();
                                _Rows["Sell_Date"] = dr["Sell Date"].ToString();
                                _Rows["Sell_Type"] = dr["Trxn_Type_NameS"].ToString();
                                _Rows["Sell_Rate"] = dr["Sell Rate"].ToString();
                                _Rows["Sell_Amount"] = ((double)Math.Round(S_Amount_M, 2, MidpointRounding.AwayFromZero)).ToString();
                                _Rows["Days"] = dr["Days"].ToString();
                                _Rows["GL_ST_Debt"] = ((double)Math.Round(NonEGL_ST_M, 2, MidpointRounding.AwayFromZero)).ToString();
                                _Rows["GL_ST_Equity"] = ((double)Math.Round(EGNL_ST_M, 2, MidpointRounding.AwayFromZero)).ToString();
                                _Rows["GL_LT_Debt"] = ((double)Math.Round(NonEGL_LT_M, 2, MidpointRounding.AwayFromZero)).ToString();
                                _Rows["GL_LT_Equity"] = ((double)Math.Round(EGNL_LT_M, 2, MidpointRounding.AwayFromZero)).ToString();
                                _Rows["STT"] = dr["STT"].ToString();
                                _Rows["ISIN"] = dr["ISIN"].ToString();
                                dt.Rows.Add(_Rows);

                                Prev_trxn_type_NameP = dr["trxn_type_NameP"].ToString();
                                Prev_trxn_type_NameS = dr["trxn_type_NameS"].ToString();
                                Prev_Trxn_Date = dr["Trxn_Date"].ToString();
                                Prev_Sell_Date = dr["Sell Date"].ToString();
                            }
                        }
                        Units_Folio += Convert.ToDouble(dr["Units"].ToString());
                        P_Amount_Folio += Convert.ToDouble(dr["Purchase Amount"].ToString());
                        S_Amount_Folio += Convert.ToDouble(dr["Sell Amount"].ToString());
                        NonEGL_ST_Folio += dr["G/L ST(Non Equity)"].ToString() == "" ? 0 : Convert.ToDouble(dr["G/L ST(Non Equity)"].ToString());
                        EGNL_ST_Folio += dr["G/L ST(Equity)"].ToString() == "" ? 0 : Convert.ToDouble(dr["G/L ST(Equity)"].ToString());
                        NonEGL_LT_Folio += dr["G/L LT(Non Equity)"].ToString() == "" ? 0 : Convert.ToDouble(dr["G/L LT(Non Equity)"].ToString());
                        EGNL_LT_Folio += dr["G/L LT(Equity)"].ToString() == "" ? 0 : Convert.ToDouble(dr["G/L LT(Equity)"].ToString());

                    }
                    Units += Units_Folio; P_Amount += P_Amount_Folio; S_Amount += S_Amount_Folio; NonEGL_ST += NonEGL_ST_Folio; EGNL_ST += EGNL_ST_Folio; NonEGL_LT += NonEGL_LT_Folio; EGNL_LT = EGNL_LT_Folio;
                    Units_Fund += Units; P_Amount_Fund += P_Amount; S_Amount_Fund += S_Amount; NonEGL_ST_Fund += NonEGL_ST; EGNL_ST_Fund += EGNL_ST; NonEGL_LT_Fund += NonEGL_LT; EGNL_LT_Fund += EGNL_LT;
                    Units_Total += Units_Fund; P_Amount_Total += P_Amount_Fund; S_Amount_Total += S_Amount_Fund; NonEGL_ST_Total += NonEGL_ST_Fund; EGNL_ST_Total += EGNL_ST_Fund; NonEGL_LT_Total += NonEGL_LT_Fund; EGNL_LT_Total += EGNL_LT_Fund;

                    DataRow _RowsT = dt.NewRow();
                    _RowsT["Fund_Name"] = "FundTotal :";
                    _RowsT["Scheme_Name"] = "";
                    _RowsT["Folio_Number"] = "";
                    _RowsT["Transaction_Type"] = "";
                    _RowsT["Transaction_Date"] = "";
                    _RowsT["Purchase_Price"] = "";
                    _RowsT["Units"] = FormatFunctions.C_Format.M_FormatComma(Units.ToString(), "3", "N.A.");
                    _RowsT["Purchase_Amount"] = P_Amount.ToString("N2");
                    _RowsT["Sell_Date"] = "";
                    _RowsT["Sell_Type"] = "";
                    _RowsT["Sell_Rate"] = "";
                    _RowsT["Sell_Amount"] = S_Amount.ToString("N2");
                    _RowsT["Days"] = "";
                    _RowsT["GL_ST_Debt"] = Math.Round(NonEGL_ST, 2);
                    _RowsT["GL_ST_Equity"] = EGNL_ST.ToString("N2");
                    _RowsT["GL_LT_Debt"] = NonEGL_LT.ToString("N2");
                    _RowsT["GL_LT_Equity"] = EGNL_LT.ToString("N2");
                    _RowsT["STT"] = "";
                    _RowsT["ISIN"] = "";
                    dt.Rows.Add(_RowsT);

                    DataRow _RowsGT = dt.NewRow();
                    _RowsGT["Fund_Name"] = "Grand Total :";
                    _RowsGT["Scheme_Name"] = "";
                    _RowsGT["Folio_Number"] = "";
                    _RowsGT["Transaction_Type"] = "";
                    _RowsGT["Transaction_Date"] = "";
                    _RowsGT["Purchase_Price"] = "";
                    _RowsGT["Units"] = FormatFunctions.C_Format.M_FormatComma(Units_Total.ToString(), "3", "N.A.");
                    _RowsGT["Purchase_Amount"] = P_Amount_Total.ToString("N2");
                    _RowsGT["Sell_Date"] = "";
                    _RowsGT["Sell_Type"] = "";
                    _RowsGT["Sell_Rate"] = "";
                    _RowsGT["Sell_Amount"] = S_Amount_Total.ToString("N2");
                    _RowsGT["Days"] = "";
                    _RowsGT["GL_ST_Debt"] = NonEGL_ST_Total.ToString("N2");
                    _RowsGT["GL_ST_Equity"] = EGNL_ST_Total.ToString("N2");
                    _RowsGT["GL_LT_Debt"] = NonEGL_LT_Total.ToString("N2");
                    _RowsGT["GL_LT_Equity"] = EGNL_LT_Total.ToString("N2");
                    _RowsGT["STT"] = "";
                    _RowsGT["ISIN"] = "";
                    dt.Rows.Add(_RowsGT);

                    ds.Tables.Add(dt);
                    return ds;
                }
                else
                {
                    DataTable table = new DataTable("DataTable");
                    table.Columns.Add("DataValues", typeof(string));
                    table.Rows.Add("Data Not Found!!!!");
                    ds.Tables.Add(table);
                    return ds;
                }

            }
            catch (Exception ex)
            {
                DataTable table = new DataTable("DataTable");
                table.Columns.Add("DataValues", typeof(string));
                table.Rows.Add("Data Not Found!!!!");
                ds.Tables.Add(table);
                HttpContext con = HttpContext.Current;
                cs.createfile(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.ToString() + " Method Name : " + System.Reflection.MethodBase.GetCurrentMethod().ToString(), con.Request.Url.ToString(), ex.Message.ToString(), ex.GetType().ToString(), "");
                return ds;
            }
        }

        protected double units, purchase_amount, sell_amount, GL_ST_NonEquity, GL_ST_Equity, GL_LT_NonEquity, GL_LT_Equity, STT, AbsReturn, SimAnnReturn, xirr_, Days_Wiegted, Installment, Amt_Invested, Dividend_Amt, Market_Value, Net_Gain;
        protected double Tot_MktVal, WeightedAmt, WghtdDays = 0, _Age, Holding;
        float[] Amount_weighted = new float[2];
        string client_id = "";
        string amc_code = "";
        double days = 0.00;

        public DataSet Taxation_Summary_Report(DataSet ds)
        {
            try
            {
                if (!(ds == null || ds.Tables[0].Rows.Count == 0))
                {
                    dt.Columns.Add("Scheme_Name");
                    dt.Columns.Add("Units");
                    dt.Columns.Add("Purchase_Amount");
                    dt.Columns.Add("Sell_Amount");
                    dt.Columns.Add("GL_ST_NonEquity");
                    dt.Columns.Add("GL_ST_Equity");
                    dt.Columns.Add("GL_LT_NonEquity");
                    dt.Columns.Add("GL_LT_Equity");
                    dt.Columns.Add("STT");
                    dt.Columns.Add("AbsReturn");
                    dt.Columns.Add("SimAnnReturn");
                    dt.Columns.Add("XIIR");
                    dt.Columns.Add("ISIN");

                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        units += Convert.ToString(ds.Tables[0].Rows[i]["Units"]) == "" ? 0 : Convert.ToDouble(ds.Tables[0].Rows[i]["Units"]);
                        days = Convert.ToString(ds.Tables[0].Rows[i]["days"]) != "" ? Convert.ToDouble(ds.Tables[0].Rows[i]["days"]) : 0.00;
                        double amount = Convert.ToString(ds.Tables[0].Rows[i]["Purchase_Amount"]) == "" ? 0 : Convert.ToDouble(ds.Tables[0].Rows[i]["Purchase_Amount"]);
                        purchase_amount += amount;
                        sell_amount += Convert.ToString(ds.Tables[0].Rows[i]["Sell_Amount"]) == "" ? 0 : Convert.ToDouble(ds.Tables[0].Rows[i]["Sell_Amount"]);
                        GL_ST_NonEquity += Convert.ToString(ds.Tables[0].Rows[i]["G/L_ST_NonEquity"]) == "" ? 0 : Convert.ToDouble(ds.Tables[0].Rows[i]["G/L_ST_NonEquity"]);
                        GL_LT_NonEquity += Convert.ToString(ds.Tables[0].Rows[i]["G/L_ST_Equity"]) == "" ? 0 : Convert.ToDouble(ds.Tables[0].Rows[i]["G/L_ST_Equity"]);
                        GL_ST_Equity += Convert.ToString(ds.Tables[0].Rows[i]["G/L_LT_NonEquity"]) == "" ? 0 : Convert.ToDouble(ds.Tables[0].Rows[i]["G/L_LT_NonEquity"]);
                        GL_LT_Equity += Convert.ToString(ds.Tables[0].Rows[i]["G/L_LT_Equity"]) == "" ? 0 : Convert.ToDouble(ds.Tables[0].Rows[i]["G/L_LT_Equity"]);
                        STT += Convert.ToString(ds.Tables[0].Rows[i]["STT"]) == "" ? 0 : Convert.ToDouble(ds.Tables[0].Rows[i]["STT"]);
                        AbsReturn += Convert.ToString(ds.Tables[0].Rows[i]["AbsReturn"]) == "" ? 0 : Convert.ToDouble(ds.Tables[0].Rows[i]["AbsReturn"]);
                        SimAnnReturn += Convert.ToString(ds.Tables[0].Rows[i]["SimAnnReturn"]) == "" ? 0 : Convert.ToDouble(ds.Tables[0].Rows[i]["SimAnnReturn"]);

                        Days_Wiegted += days * amount;

                        //xirr_=Convert.ToDouble(Calculate_XIRR(Convert.ToString(ds.Tables[0].Rows[i]["Client_ID"]), Convert.ToString(ds.Tables[0].Rows[i]["FromDate"]), Convert.ToString(ds.Tables[0].Rows[i]["ToDate"]), Convert.ToString(ds.Tables[0].Rows[i]["Folio_Number"]), Convert.ToString(ds.Tables[0].Rows[i]["SCHEMECODE"]), "5")).ToString("N2");

                        DataRow _Rows = dt.NewRow();
                        _Rows["Scheme_Name"] = Convert.ToString(ds.Tables[0].Rows[i]["Scheme_Name"]);
                        _Rows["Units"] = Convert.ToString(ds.Tables[0].Rows[i]["Units"]);
                        _Rows["Purchase_Amount"] = Convert.ToString(ds.Tables[0].Rows[i]["Purchase_Amount"]);
                        _Rows["Sell_Amount"] = Convert.ToString(ds.Tables[0].Rows[i]["Sell_Amount"]);
                        _Rows["GL_ST_NonEquity"] = Convert.ToString(ds.Tables[0].Rows[i]["G/L_ST_NonEquity"]);
                        _Rows["GL_ST_Equity"] = Convert.ToString(ds.Tables[0].Rows[i]["G/L_ST_Equity"]);
                        _Rows["GL_LT_NonEquity"] = Convert.ToString(ds.Tables[0].Rows[i]["G/L_LT_NonEquity"]);
                        _Rows["GL_LT_Equity"] = Convert.ToString(ds.Tables[0].Rows[i]["G/L_LT_Equity"]);
                        _Rows["STT"] = Convert.ToString(ds.Tables[0].Rows[i]["STT"]);
                        _Rows["AbsReturn"] = Convert.ToString(ds.Tables[0].Rows[i]["AbsReturn"]);
                        _Rows["SimAnnReturn"] = Convert.ToString(ds.Tables[0].Rows[i]["SimAnnReturn"]);
                        _Rows["XIIR"] = Convert.ToDouble(Calculate_XIRR(Convert.ToString(ds.Tables[0].Rows[i]["Client_ID"]), Convert.ToString(ds.Tables[0].Rows[i]["FromDate"]), Convert.ToString(ds.Tables[0].Rows[i]["ToDate"]), Convert.ToString(ds.Tables[0].Rows[i]["Folio_Number"]), Convert.ToString(ds.Tables[0].Rows[i]["SCHEMECODE"]), "5")).ToString("N2");
                        _Rows["ISIN"] = Convert.ToString(ds.Tables[0].Rows[i]["ISIN"]);
                        dt.Rows.Add(_Rows);
                    }

                    DataRow _RowsGT = dt.NewRow();
                    _RowsGT["Scheme_Name"] = "Grand Total";
                    _RowsGT["Units"] = units;
                    _RowsGT["Purchase_Amount"] = purchase_amount;
                    _RowsGT["Sell_Amount"] = sell_amount;
                    _RowsGT["GL_ST_NonEquity"] = GL_ST_NonEquity;
                    _RowsGT["GL_ST_Equity"] = GL_LT_NonEquity;
                    _RowsGT["GL_LT_NonEquity"] = GL_ST_Equity;
                    _RowsGT["GL_LT_Equity"] = GL_LT_Equity;
                    _RowsGT["STT"] = STT;
                    _RowsGT["AbsReturn"] = AbsReturn;
                    _RowsGT["SimAnnReturn"] = SimAnnReturn;
                    _RowsGT["XIIR"] = Convert.ToDouble(Calculate_XIRR(Convert.ToString(ds.Tables[0].Rows[0]["Client_ID"]), Convert.ToString(ds.Tables[0].Rows[0]["FromDate"]), Convert.ToString(ds.Tables[0].Rows[0]["ToDate"]), null, null, "5")).ToString("N2");
                    _RowsGT["ISIN"] = SimAnnReturn;
                    dt.Rows.Add(_RowsGT);

                    ds.Tables.Add(dt);
                    return ds;
                }
                else
                {
                    DataTable table = new DataTable("DataTable");
                    table.Columns.Add("DataValues", typeof(string));
                    table.Rows.Add("Data Not Found!!!!");
                    ds.Tables.Add(table);
                    return ds;
                }

            }
            catch (Exception ex)
            {
                DataTable table = new DataTable("DataTable");
                table.Columns.Add("DataValues", typeof(string));
                table.Rows.Add("Data Not Found!!!!");
                ds.Tables.Add(table);
                HttpContext con = HttpContext.Current;
                cs.createfile(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.ToString() + " Method Name : " + System.Reflection.MethodBase.GetCurrentMethod().ToString(), con.Request.Url.ToString(), ex.Message.ToString(), ex.GetType().ToString(), "");
                return ds;
            }
        }

        public DataSet SIP_Summary(DataSet ds)
        {
            try
            {
                if (!(ds == null || ds.Tables[0].Rows.Count == 0))
                {
                    dt.Columns.Add("Sr_No");
                    dt.Columns.Add("Client_Name");
                    dt.Columns.Add("Scheme_Name");
                    dt.Columns.Add("Folio_Number");
                    dt.Columns.Add("SIP_Amount");
                    dt.Columns.Add("Freq");
                    dt.Columns.Add("Start_Date");
                    dt.Columns.Add("End_Date");
                    dt.Columns.Add("Amount_Invested");
                    dt.Columns.Add("Total_Units");
                    dt.Columns.Add("Avg_Purchase_Price");
                    dt.Columns.Add("Dividend_Amount");
                    dt.Columns.Add("Current_NAV");
                    dt.Columns.Add("Market_Value");
                    dt.Columns.Add("Net_Gain");
                    dt.Columns.Add("XIRR");


                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        Installment += Convert.ToString(ds.Tables[0].Rows[i]["Installment"]) == "" ? 0 : Convert.ToDouble(ds.Tables[0].Rows[i]["Installment"]);
                        Amt_Invested += Convert.ToString(ds.Tables[0].Rows[i]["Amount Invested"]) == "" ? 0 : Convert.ToDouble(ds.Tables[0].Rows[i]["Amount Invested"]);
                        Dividend_Amt += Convert.ToString(ds.Tables[0].Rows[i]["Dividund Amount"]) == "" ? 0 : Convert.ToDouble(ds.Tables[0].Rows[i]["Dividund Amount"]);
                        Market_Value += Convert.ToString(ds.Tables[0].Rows[i]["Market Value"]) == "" ? 0 : Convert.ToDouble(ds.Tables[0].Rows[i]["Market Value"]);
                        Net_Gain += Convert.ToString(ds.Tables[0].Rows[i]["Net Gain"]) == "" ? 0 : Convert.ToDouble(ds.Tables[0].Rows[i]["Net Gain"]);

                        DataRow _Rows = dt.NewRow();
                        _Rows["Sr_No"] = ds.Tables[0].Rows[i]["SrNo"];
                        _Rows["Client_Name"] = ds.Tables[0].Rows[i]["First_Name"];
                        _Rows["Scheme_Name"] = ds.Tables[0].Rows[i]["Scheme Name"];
                        _Rows["Folio_Number"] = ds.Tables[0].Rows[i]["Folio_Number"];
                        _Rows["SIP_Amount"] = ds.Tables[0].Rows[i]["Installment"];
                        _Rows["Freq"] = ds.Tables[0].Rows[i]["Counter"];
                        _Rows["Start_Date"] = ds.Tables[0].Rows[i]["DATEFROM"];
                        _Rows["End_Date"] = ds.Tables[0].Rows[i]["DATETO"];
                        _Rows["Amount_Invested"] = ds.Tables[0].Rows[i]["Amount Invested"];
                        _Rows["Total_Units"] = ds.Tables[0].Rows[i]["Total Units"];
                        _Rows["Avg_Purchase_Price"] = ds.Tables[0].Rows[i]["Avg. Purchase Price"];
                        _Rows["Dividend_Amount"] = ds.Tables[0].Rows[i]["Dividund Amount"];
                        _Rows["Current_NAV"] = ds.Tables[0].Rows[i]["Current NAV"];
                        _Rows["Market_Value"] = ds.Tables[0].Rows[i]["Market Value"];
                        _Rows["Net_Gain"] = ds.Tables[0].Rows[i]["Net Gain"];
                        _Rows["XIRR"] = "";
                        dt.Rows.Add(_Rows);
                    }

                    DataRow _RowsGT = dt.NewRow();
                    _RowsGT["Sr_No"] = "";
                    _RowsGT["Client_Name"] = "";
                    _RowsGT["Scheme_Name"] = "";
                    _RowsGT["Folio_Number"] = "";
                    _RowsGT["SIP_Amount"] = Installment.ToString("N2");
                    _RowsGT["Freq"] = "";
                    _RowsGT["Start_Date"] = "";
                    _RowsGT["End_Date"] = "";
                    _RowsGT["Amount_Invested"] = Amt_Invested.ToString("N2");
                    _RowsGT["Total_Units"] = "";
                    _RowsGT["Avg_Purchase_Price"] = "";
                    _RowsGT["Dividend_Amount"] = Dividend_Amt.ToString("N2");
                    _RowsGT["Current_NAV"] = "";
                    _RowsGT["Market_Value"] = Market_Value.ToString("N2");
                    _RowsGT["Net_Gain"] = Net_Gain.ToString("N2");
                    _RowsGT["XIRR"] = FormatFunctions.C_Format.M_FormatComma(Calculate_XIRR("1", "", "", "", "", Convert.ToString(Market_Value)), "2", "").ToString();
                    dt.Rows.Add(_RowsGT);

                    ds.Tables.Add(dt);
                    return ds;
                }
                else
                {
                    DataTable table = new DataTable("DataTable");
                    table.Columns.Add("DataValues", typeof(string));
                    table.Rows.Add("Data Not Found!!!!");
                    ds.Tables.Add(table);
                    return ds;
                }

            }
            catch (Exception ex)
            {
                DataTable table = new DataTable("DataTable");
                table.Columns.Add("DataValues", typeof(string));
                table.Rows.Add("Data Not Found!!!!");
                ds.Tables.Add(table);
                HttpContext con = HttpContext.Current;
                cs.createfile(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.ToString() + " Method Name : " + System.Reflection.MethodBase.GetCurrentMethod().ToString(), con.Request.Url.ToString(), ex.Message.ToString(), ex.GetType().ToString(), "");
                return ds;
            }
        }

        public DataSet Portfolio_Insight(DataSet ds)
        {
            try
            {
                if (!(ds == null || ds.Tables[0].Rows.Count == 0))
                {
                    Market_Value = 0;
                    DataTable dtsip = new DataTable();
                    dtsip.Columns.Add("Sr_No");
                    dtsip.Columns.Add("Client_Name");
                    dtsip.Columns.Add("Scheme_Name");
                    dtsip.Columns.Add("Folio_Number");
                    dtsip.Columns.Add("Installment");
                    dtsip.Columns.Add("Amount_Invested");
                    dtsip.Columns.Add("Total_Units");
                    dtsip.Columns.Add("Avg_Purchase_Price");
                    dtsip.Columns.Add("Current_NAV");
                    dtsip.Columns.Add("Market_Value");
                    dtsip.Columns.Add("XIRR");
                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {

                        client_id = Convert.ToString(ds.Tables[0].Rows[i]["client_id"]);
                        Installment += Convert.ToString(ds.Tables[0].Rows[i]["Installment"]) == "" ? 0 : Convert.ToDouble(ds.Tables[0].Rows[i]["Installment"]);
                        Amt_Invested += Convert.ToString(ds.Tables[0].Rows[i]["Amount Invested"]) == "" ? 0 : Convert.ToDouble(ds.Tables[0].Rows[i]["Amount Invested"]);
                        //Dividend_Amt += Convert.ToString(ds.Tables[0].Rows[i]["Market Value"]) == "" ? 0 : Convert.ToDouble(ds.Tables[0].Rows[i]["Market Value"]);
                        Market_Value += Convert.ToString(ds.Tables[0].Rows[i]["Market Value"]) == "" ? 0 : Convert.ToDouble(ds.Tables[0].Rows[i]["Market Value"]);
                        Net_Gain += Convert.ToString(ds.Tables[0].Rows[i]["Net Gain"]) == "" ? 0 : Convert.ToDouble(ds.Tables[0].Rows[i]["Net Gain"]);

                        DataRow _Rows = dtsip.NewRow();
                        _Rows["Sr_No"] = ds.Tables[0].Rows[i]["SrNo"];
                        _Rows["Client_Name"] = ds.Tables[0].Rows[i]["First_Name"];
                        _Rows["Scheme_Name"] = ds.Tables[0].Rows[i]["Scheme Name"];
                        _Rows["Folio_Number"] = ds.Tables[0].Rows[i]["Folio_Number"];
                        _Rows["Installment"] = ds.Tables[0].Rows[i]["Installment"];
                        _Rows["Amount_Invested"] = ds.Tables[0].Rows[i]["Amount Invested"];
                        _Rows["Total_Units"] = ds.Tables[0].Rows[i]["Total Units"];
                        _Rows["Avg_Purchase_Price"] = ds.Tables[0].Rows[i]["Avg. Purchase Price"];
                        _Rows["Current_NAV"] = ds.Tables[0].Rows[i]["Current NAV"];
                        _Rows["Market_Value"] = ds.Tables[0].Rows[i]["Market Value"];
                        _Rows["XIRR"] = FormatFunctions.C_Format.M_FormatComma(Calculate_XIRR_SIP(Convert.ToString(ds.Tables[0].Rows[i]["srno"]), client_id, "C", Convert.ToString(ds.Tables[0].Rows[i]["Folio_Number"]), Convert.ToString(ds.Tables[0].Rows[i]["schemecode"]), Convert.ToString(ds.Tables[0].Rows[i]["Market Value"]), Convert.ToString(ds.Tables[0].Rows[i]["Installment"])), "2", "").ToString();
                        dtsip.Rows.Add(_Rows);
                    }

                    DataRow _RowsGT = dtsip.NewRow();
                    _RowsGT["Sr_No"] = "";
                    _RowsGT["Client_Name"] = "";
                    _RowsGT["Scheme_Name"] = "";
                    _RowsGT["Folio_Number"] = "";
                    _RowsGT["Installment"] = Installment.ToString("N2");
                    _RowsGT["Amount_Invested"] = Amt_Invested.ToString("N2");
                    _RowsGT["Total_Units"] = "";
                    _RowsGT["Avg_Purchase_Price"] = "";
                    _RowsGT["Current_NAV"] = "";
                    _RowsGT["Market_Value"] = Market_Value.ToString("N2");
                    _RowsGT["XIRR"] = FormatFunctions.C_Format.M_FormatComma(Calculate_XIRR_SIP("1", "1", "", "", "", Convert.ToString(Market_Value), null), "2", "").ToString();
                    dtsip.Rows.Add(_RowsGT);

                    ds.Tables.Add(dtsip);
                    return ds;
                }
                else
                {
                    DataTable table = new DataTable("DataTable");
                    table.Columns.Add("DataValues", typeof(string));
                    table.Rows.Add("Data Not Found!!!!");
                    ds.Tables.Add(table);
                    return ds;
                }

            }
            catch (Exception ex)
            {
                DataTable table = new DataTable("DataTable");
                table.Columns.Add("DataValues", typeof(string));
                table.Rows.Add("Data Not Found!!!!");
                ds.Tables.Add(table);
                HttpContext con = HttpContext.Current;
                cs.createfile(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.ToString() + " Method Name : " + System.Reflection.MethodBase.GetCurrentMethod().ToString(), con.Request.Url.ToString(), ex.Message.ToString(), ex.GetType().ToString(), "");
                return ds;
            }
        }

        public DataSet Client_ELSS_Maturity_Report(DataSet ds)
        {
            try
            {
                if (!(ds == null || ds.Tables[0].Rows.Count == 0))
                {
                    dt.Columns.Add("Client_Name");
                    dt.Columns.Add("Mutual_Fund_Name");
                    dt.Columns.Add("Scheme_Name");
                    dt.Columns.Add("Folio_No");
                    dt.Columns.Add("Investment_Date");
                    dt.Columns.Add("Maturity_Date");
                    dt.Columns.Add("Investment_Amount");
                    dt.Columns.Add("Present_Value");
                    dt.Columns.Add("Present_NAV");
                    

                    double InvestAmount_GrandT, Present_GrandT;
                    InvestAmount_GrandT = Present_GrandT = 0;

                    DataTable dt_ClientID = TrObj.SelectDistinct("Client_ID", ds.Tables[0], "Client_ID");

                    foreach (DataRow dr_ClientID in dt_ClientID.Rows)
                    {
                        double InvestAmount_Value, Present_TotalValue;
                        InvestAmount_Value = Present_TotalValue = 0;
                        DataRow[] dr_temp = ds.Tables[0].Select("Client_ID = '" + dr_ClientID["Client_ID"].ToString() + "'");

                        if (dr_temp.Length > 0)
                        {
                            foreach (DataRow dr in dr_temp)
                            {
                                DataRow _Rows = dt.NewRow();
                                _Rows["Client_Name"] = dr_temp[0]["First_Name"].ToString();
                                _Rows["Mutual_Fund_Name"] = dr["FUND"].ToString();
                                _Rows["Scheme_Name"] = dr["S_Name"].ToString();
                                _Rows["Folio_No"] = dr["Folio_Number"].ToString();
                                _Rows["Investment_Date"] = dr["Date of Investment"].ToString();
                                _Rows["Maturity_Date"] = dr["Maturity Date"].ToString();
                                _Rows["Investment_Amount"] = dr["Investment Amount"].ToString();
                                _Rows["Present_Value"] = dr["Current Amount"].ToString();
                                _Rows["Present_NAV"] = dr["NAV"].ToString();
                                dt.Rows.Add(_Rows);

                                InvestAmount_Value += Convert.ToDouble(dr["Investment Amount"].ToString());
                                Present_TotalValue += Convert.ToDouble(dr["Current Amount"].ToString());
                            }

                            DataRow _RowsT = dt.NewRow();
                            _RowsT["Client_Name"] = "Total :";
                            _RowsT["Mutual_Fund_Name"] = "";
                            _RowsT["Scheme_Name"] = "";
                            _RowsT["Folio_No"] = "";
                            _RowsT["Investment_Date"] = "";
                            _RowsT["Maturity_Date"] = "";
                            _RowsT["Investment_Amount"] = Convert.ToDouble(FormatFunctions.C_Format.M_FormatComma(InvestAmount_Value.ToString(), "2", "N.A"));
                            _RowsT["Present_Value"] = Convert.ToDouble(FormatFunctions.C_Format.M_FormatComma(Present_TotalValue.ToString(), "2", "N.A"));
                            _RowsT["Present_NAV"] = "";
                            dt.Rows.Add(_RowsT);

                            InvestAmount_GrandT += Convert.ToDouble(InvestAmount_Value.ToString());
                            Present_GrandT += Convert.ToDouble(Present_TotalValue.ToString());
                        }
                    }
                    DataRow _RowsGT = dt.NewRow();
                    _RowsGT["Client_Name"] = "Grand Total :";
                    _RowsGT["Mutual_Fund_Name"] = "";
                    _RowsGT["Scheme_Name"] = "";
                    _RowsGT["Folio_No"] = "";
                    _RowsGT["Investment_Date"] = "";
                    _RowsGT["Maturity_Date"] = "";
                    _RowsGT["Investment_Amount"] = Convert.ToDouble(FormatFunctions.C_Format.M_FormatComma(InvestAmount_GrandT.ToString(), "2", "N.A"));
                    _RowsGT["Present_Value"] = Convert.ToDouble(FormatFunctions.C_Format.M_FormatComma(Present_GrandT.ToString(), "2", "N.A"));
                    _RowsGT["Present_NAV"] = "";
                    dt.Rows.Add(_RowsGT);

                    ds.Tables.Add(dt);
                    return ds;
                }
                else
                {
                    DataTable table = new DataTable("DataTable");
                    table.Columns.Add("DataValues", typeof(string));
                    table.Rows.Add("Data Not Found!!!!");
                    ds.Tables.Add(table);
                    return ds;
                }
            }
            catch (Exception ex)
            {
                DataTable table = new DataTable("DataTable");
                table.Columns.Add("DataValues", typeof(string));
                table.Rows.Add("Data Not Found!!!!");
                ds.Tables.Add(table);
                HttpContext con = HttpContext.Current;
                cs.createfile(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.ToString() + " Method Name : " + System.Reflection.MethodBase.GetCurrentMethod().ToString(), con.Request.Url.ToString(), ex.Message.ToString(), ex.GetType().ToString(), "");
                return ds;
            }
        }

        public DataSet Transaction_Details(DataSet ds)
        {
            try
            {
                if (!(ds == null || ds.Tables[0].Rows.Count == 0))
                {
                    dt.Columns.Add("MutualFund");
                    dt.Columns.Add("SchemeName");
                    dt.Columns.Add("Trxn_Type_Name");
                    dt.Columns.Add("Sub_TrxnType_Name");
                    dt.Columns.Add("Folio_Number");
                    dt.Columns.Add("Trxn_Date");
                    dt.Columns.Add("sipstartdate");
                    dt.Columns.Add("Process_Date");
                    dt.Columns.Add("Trxn_Number");
                    dt.Columns.Add("Trxn_ID");
                    dt.Columns.Add("Price");
                    dt.Columns.Add("units");
                    dt.Columns.Add("amount");
                    dt.Columns.Add("nav");
                    dt.Columns.Add("Application_No");
                    dt.Columns.Add("Cheque_No");
                    dt.Columns.Add("ReinvestmentFlag");
                    dt.Columns.Add("STT");
                    dt.Columns.Add("EntryLoad");
                    dt.Columns.Add("PAN");
                    dt.Columns.Add("Location");
                    dt.Columns.Add("ARNNO");
                    dt.Columns.Add("BrokerPer");
                    dt.Columns.Add("BrokerCommission");
                    dt.Columns.Add("SIPFlag");
                    dt.Columns.Add("ClientName");
                    dt.Columns.Add("AgentName");
                    dt.Columns.Add("AgentCode");
                    dt.Columns.Add("EmployeeName");
                    dt.Columns.Add("BranchName");
                    dt.Columns.Add("BranchCode");
                    dt.Columns.Add("BrokerName");
                    dt.Columns.Add("sys_trxn_Id");
                    dt.Columns.Add("DOE");
                    dt.Columns.Add("line");
                    dt.Columns.Add("ISIN");

                    DataTable folio = TrObj.SelectDistinct("Folio_Number", ds.Tables[0], "Folio_Number");

                    foreach (DataRow folio_no in folio.Rows)
                    {
                        DataRow[] dr_temp = ds.Tables[0].Select("Folio_Number = '" + folio_no["Folio_Number"].ToString() + "'");

                        if (dr_temp.Length > 0)
                        {
                            foreach (DataRow dr in dr_temp)
                            {
                                DataRow _Rows = dt.NewRow();
                                _Rows["MutualFund"] = dr_temp[0]["MutualFund"].ToString();
                                _Rows["SchemeName"] = dr["SchemeName"].ToString();
                                _Rows["Trxn_Type_Name"] = dr["Trxn_Type_Name"].ToString();
                                _Rows["Sub_TrxnType_Name"] = dr["Sub_TrxnType_Name"].ToString();
                                _Rows["Folio_Number"] = dr["Folio_Number"].ToString();
                                _Rows["Trxn_Date"] = dr["Trxn_Date"].ToString();
                                _Rows["sipstartdate"] = dr["sipstartdate"].ToString();
                                _Rows["Process_Date"] = dr["Process_Date"].ToString();
                                _Rows["Trxn_Number"] = dr["Trxn_Number"].ToString();
                                _Rows["Trxn_ID"] = dr["Trxn_ID"].ToString();
                                _Rows["Price"] = dr["Price"].ToString();
                                _Rows["units"] = dr["units"].ToString();
                                _Rows["amount"] = dr["amount"].ToString();
                                _Rows["nav"] = dr["nav"].ToString();
                                _Rows["Application_No"] = dr["Application_No"].ToString();
                                _Rows["Cheque_No"] = dr["Cheque_No"].ToString();
                                _Rows["ReinvestmentFlag"] = dr["ReinvestmentFlag"].ToString();
                                _Rows["STT"] = dr["STT"].ToString();
                                _Rows["EntryLoad"] = dr["EntryLoad"].ToString();
                                _Rows["PAN"] = dr["PAN"].ToString();
                                _Rows["Location"] = dr["Location"].ToString();
                                _Rows["ARNNO"] = dr["ARNNO"].ToString();
                                _Rows["BrokerPer"] = dr["BrokerPer"].ToString();
                                _Rows["BrokerCommission"] = dr["BrokerCommission"].ToString();
                                _Rows["SIPFlag"] = dr["SIPFlag"].ToString();
                                _Rows["ClientName"] = dr["ClientName"].ToString();
                                _Rows["AgentName"] = dr["AgentName"].ToString();
                                _Rows["AgentCode"] = dr["AgentCode"].ToString();
                                _Rows["EmployeeName"] = dr["EmployeeName"].ToString();
                                _Rows["BranchName"] = dr["BranchName"].ToString();
                                _Rows["BranchCode"] = dr["BranchCode"].ToString();
                                _Rows["BrokerName"] = dr["BrokerName"].ToString();
                                _Rows["sys_trxn_Id"] = dr["sys_trxn_Id"].ToString();
                                //_Rows["DOE"] = dr["DOE"].ToString();
                                _Rows["line"] = dr["line"].ToString();
                                _Rows["ISIN"] = dr["ISIN"].ToString();
                                dt.Rows.Add(_Rows);                            
                            }
                        }
                    }
                   
                    return ds;
                }
                else
                {
                    DataTable table = new DataTable("DataTable");
                    table.Columns.Add("DataValues", typeof(string));
                    table.Rows.Add("Data Not Found!!!!");
                    ds.Tables.Add(table);
                    return ds;
                }
            }
            catch (Exception ex)
            {
                DataTable table = new DataTable("DataTable");
                table.Columns.Add("DataValues", typeof(string));
                table.Rows.Add("Data Not Found!!!!");
                ds.Tables.Add(table);
                HttpContext con = HttpContext.Current;
                cs.createfile(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.ToString() + " Method Name : " + System.Reflection.MethodBase.GetCurrentMethod().ToString(), con.Request.Url.ToString(), ex.Message.ToString(), ex.GetType().ToString(), "");
                return ds;
            }
        }


        public DataSet Fixed_Maturity_Plan_Report(DataSet ds)
        {
            try
            {
                if (!(ds == null || ds.Tables[0].Rows.Count == 0))
                {
                    dt.Columns.Add("Transaction_Type");
                    dt.Columns.Add("Folio_Number");
                    dt.Columns.Add("Scheme_Name");
                    dt.Columns.Add("Transaction_Date");
                    dt.Columns.Add("Transaction_Price");
                    dt.Columns.Add("No_of_Units");
                    dt.Columns.Add("Purchase_Value");
                    dt.Columns.Add("Maturity_Date");
                    dt.Columns.Add("Current_Amount");
                    dt.Columns.Add("Dividend_Payout");
                    dt.Columns.Add("Profit_Loss");
                    dt.Columns.Add("No_of_Days");
                    dt.Columns.Add("Annual_Return");
                    dt.Columns.Add("CAGR");
                    dt.Columns.Add("Net_Gain");
                    dt.Columns.Add("XIRR");


                    DataTable dt_Funds = TrObj.SelectDistinct("Fund_ID", ds.Tables[0], "AMC_CODE");
                    DataTable dt_SCHEMES = TrObj.SelectDistinct("SCHEMECODE", ds.Tables[0], "SCHEMECODE");
                    DataTable dt_Clients = TrObj.SelectDistinct("CName", ds.Tables[0], "Name");

                    string Latest_NAV_Date = string.Empty, Latest_NAV = string.Empty;
                    double Age_TotalG, ABSReturns_TotalG, SimAnnReturns_TotalG, CAGR_TotalG, Amount_TotalG, Dividend_Payout_TotalG, Present_Value_TotalG, Dividend_Amt_TotalG, Notional_PL_TotalG, NetGain_TotalG;
                    Age_TotalG = ABSReturns_TotalG = SimAnnReturns_TotalG = CAGR_TotalG = Amount_TotalG = Dividend_Payout_TotalG = Present_Value_TotalG = Dividend_Amt_TotalG = Notional_PL_TotalG = NetGain_TotalG = 0;
                    float[] Amount_weighted_TotalG = new float[4];

                    foreach (DataRow dr_Names in dt_Clients.Rows)
                    {
                        double Age_Total, ABSReturns_Total, SimAnnReturns_Total, CAGR_Total, Amount_Total, Dividend_Payout_Total, Present_Value_Total, Dividend_Amt_Total, Notional_PL_Total, NetGain_Total;
                        Age_Total = ABSReturns_Total = SimAnnReturns_Total = CAGR_Total = Amount_Total = Dividend_Payout_Total = Present_Value_Total = Dividend_Amt_Total = Notional_PL_Total = NetGain_Total = 0;
                        float[] Amount_weighted_Total = new float[4];
                        string Prv_ClientID = string.Empty;
                        string Prv_Fund = string.Empty;
                        foreach (DataRow dr_Funds in dt_Funds.Rows)
                        {
                            if (((DataRow[])ds.Tables[0].Select("AMC_CODE = '" + dr_Funds["AMC_CODE"].ToString() + "' and Name = '" + dr_Names["Name"].ToString() + "'")).Length > 0)
                            {
                                string Prv_Folio = string.Empty;
                                string Prv_Sch = string.Empty;
                                string Prv_SchCode = string.Empty;

                                double Age_Fund, ABSReturns_Fund, SimAnnReturns_Fund, CAGR_Fund, Amount_Fund, Dividend_Payout_Fund, Present_Value_Fund, Dividend_Amt_Fund, Notional_PL_Fund, NetGain_Fund;
                                Age_Fund = ABSReturns_Fund = SimAnnReturns_Fund = CAGR_Fund = Amount_Fund = Dividend_Payout_Fund = Present_Value_Fund = Dividend_Amt_Fund = Notional_PL_Fund = NetGain_Fund = 0;
                                float[] Amount_weighted_Fund = new float[4];
                                foreach (DataRow dr_SCHEMES in dt_SCHEMES.Rows)
                                {
                                    DataRow[] dr_temp = ds.Tables[0].Select("AMC_CODE = '" + dr_Funds["AMC_CODE"].ToString() + "' and SCHEMECODE = '" + dr_SCHEMES["SCHEMECODE"].ToString() + "' and Name = '" + dr_Names["Name"].ToString() + "'");
                                    double Age, ABSReturns, SimAnnReturns, CAGR, Amount, Positive_Amount, Dividend_Payout, Present_Value, Dividend_Amt, Notional_PL, NetGain;
                                    Age = ABSReturns = SimAnnReturns = CAGR = Amount = Positive_Amount = Dividend_Payout = Present_Value = Dividend_Amt = Notional_PL = NetGain = 0;
                                    float[] Amount_weighted = new float[4];
                                    string ASSET_TYPE = string.Empty;


                                    if (dr_temp.Length > 0)
                                    {
                                        foreach (DataRow dr in dr_temp)
                                        {
                                            if (!(Prv_Folio == dr["Folio_Number"].ToString() && Prv_Sch == dr["S_Name"].ToString()))
                                            {
                                                Prv_ClientID = dr["Client_ID"].ToString();
                                                if (!(Prv_Folio == string.Empty || Prv_Sch == string.Empty) && Prv_Sch == dr["S_Name"].ToString())
                                                {
                                                    Latest_NAV_Date = (dr_temp.Length > 0 ? dr_temp[dr_temp.Length - 1]["Latest_Nav_Date"].ToString() : "--");
                                                    Latest_NAV = (dr_temp.Length > 0 ? dr_temp[dr_temp.Length - 1]["Latest_Nav"].ToString() : "--");
                                                    DataRow _RowsT = dt.NewRow();
                                                    _RowsT["Transaction_Type"] = "Balance in Folio :";
                                                    _RowsT["Folio_Number"] = "";
                                                    _RowsT["Scheme_Name"] = "";
                                                    _RowsT["Transaction_Date"] = "";
                                                    _RowsT["Transaction_Price"] = "";
                                                    _RowsT["No_of_Units"] = "";
                                                    _RowsT["Purchase_Value"] = ((double)(Amount - Dividend_Payout)).ToString("N2");
                                                    _RowsT["Maturity_Date"] = "";
                                                    _RowsT["Current_Amount"] = Present_Value.ToString("N2");
                                                    _RowsT["Dividend_Payout"] = Dividend_Payout.ToString("N2");
                                                    _RowsT["Profit_Loss"] = Notional_PL.ToString("N2");
                                                    _RowsT["No_of_Days"] = (Positive_Amount == 0 ? "N.A." : ((ASSET_TYPE == "Equity" && Math.Round((Age == 0 ? 0 : (Age / Amount_weighted[0]))) <= 365) ? (((Present_Value + Dividend_Payout - Positive_Amount) / Positive_Amount) * 100).ToString("N2") : "--"));
                                                    _RowsT["Annual_Return"] = (Positive_Amount == 0 ? "N.A." : ((ASSET_TYPE == "Debt" && Math.Round((Age == 0 ? 0 : (Age / Amount_weighted[0]))) <= 365) ? (((Present_Value + Dividend_Payout - Positive_Amount) / Positive_Amount) * 100 * (365 / (Age / Amount_weighted[0]))).ToString("N2") : "--"));
                                                    _RowsT["CAGR"] = (Positive_Amount == 0 ? "N.A." : ((((ASSET_TYPE == "Equity" || ASSET_TYPE == "Debt") && Math.Round((Age == 0 ? 0 : (Age / Amount_weighted[0]))) >= 365) ? ((Math.Pow(((Present_Value + Dividend_Payout) / Positive_Amount), ((double)(365) / (Age / Amount_weighted[0]))) - 1) * 100).ToString("N2") : "--")));
                                                    _RowsT["Net_Gain"] = NetGain.ToString("N2");
                                                    _RowsT["XIRR"] = FormatFunctions.C_Format.M_FormatComma(Convert.ToString(Calculate_XIRR(Prv_ClientID, "C", Prv_Folio, Prv_SchCode, Present_Value)), "2", "0").ToString();
                                                    dt.Rows.Add(_RowsT);

                                                    Age_Fund += Age; ABSReturns_Fund += ABSReturns; SimAnnReturns_Fund += SimAnnReturns; CAGR_Fund += CAGR; Amount_weighted_Fund[0] += Amount_weighted[0]; Amount_weighted_Fund[1] += Amount_weighted[1]; Amount_weighted_Fund[2] += Amount_weighted[2]; Amount_weighted_Fund[3] += Amount_weighted[3];
                                                    Amount_Fund += Amount; Dividend_Payout_Fund += Dividend_Payout; Present_Value_Fund += Present_Value; Dividend_Amt_Fund += Dividend_Amt; Notional_PL_Fund += Notional_PL; NetGain_Fund += NetGain;
                                                    Age = ABSReturns = SimAnnReturns = CAGR = Amount = Positive_Amount = Dividend_Payout = Present_Value = Dividend_Amt = Notional_PL = NetGain = 0;
                                                    Amount_weighted = new float[4];
                                                    ASSET_TYPE = string.Empty;
                                                }
                                                Prv_Folio = dr["Folio_Number"].ToString();
                                                Prv_Sch = dr["S_Name"].ToString();
                                                Prv_SchCode = dr["schemecode"].ToString();
                                            }
                                            DataRow _Rows = dt.NewRow();
                                            _Rows["Transaction_Type"] = dr["trxn_type_Name"].ToString();
                                            _Rows["Folio_Number"] = dr["Folio_Number"].ToString();
                                            _Rows["Scheme_Name"] = dr["S_Name"].ToString();
                                            _Rows["Transaction_Date"] = dr["Trxn_Date"].ToString();
                                            _Rows["Transaction_Price"] = dr["Price"].ToString();
                                            _Rows["No_of_Units"] = dr["Units"].ToString();
                                            _Rows["Purchase_Value"] = dr["Amount"].ToString();
                                            _Rows["Maturity_Date"] = dr["MaturityDate"].ToString();
                                            _Rows["Current_Amount"] = dr["Present_Value"].ToString();
                                            _Rows["Dividend_Payout"] = dr["Dividend Payout"].ToString();
                                            _Rows["Profit_Loss"] = dr["Notional P/L"].ToString();
                                            _Rows["No_of_Days"] = dr["Age"].ToString();
                                            _Rows["Annual_Return"] = (Convert.ToDouble(dr["Sim_Ann_Returns"].ToString()) == 0 ? "--" : dr["Sim_Ann_Returns"].ToString());
                                            _Rows["CAGR"] = (Convert.ToDouble(dr["CAGR"].ToString()) == 0 ? "--" : dr["CAGR"].ToString());
                                            _Rows["Net_Gain"] = dr["NetGain"].ToString();
                                            _Rows["XIRR"] = "--";
                                            dt.Rows.Add(_Rows);

                                            if (Convert.ToDouble(dr["PortFolio_Unitbal"].ToString()) != 0)
                                            {
                                                double weighted_Amount = Convert.ToDouble(dr["Amount"].ToString());
                                                Age += Convert.ToDouble(dr["Age"].ToString()) * weighted_Amount;
                                                ABSReturns += Convert.ToDouble(dr["Absolute_Returns"].ToString()) * weighted_Amount;
                                                SimAnnReturns += Convert.ToDouble(dr["Sim_Ann_Returns"].ToString()) * weighted_Amount;
                                                CAGR += Convert.ToDouble(dr["CAGR"].ToString()) * weighted_Amount;
                                                if (Convert.ToDouble(dr["Age"].ToString()) != 0) Amount_weighted[0] += (float)weighted_Amount;
                                                if (Convert.ToDouble(dr["Absolute_Returns"].ToString()) != 0) Amount_weighted[1] += (float)weighted_Amount;
                                                if (Convert.ToDouble(dr["Sim_Ann_Returns"].ToString()) != 0) Amount_weighted[2] += (float)weighted_Amount;
                                                if (Convert.ToDouble(dr["CAGR"].ToString()) != 0) Amount_weighted[3] += (float)weighted_Amount;
                                            }
                                            Amount += Convert.ToDouble(dr["Amount"].ToString());//
                                            Positive_Amount += (Convert.ToString(dr["Trxn_Type_ID"].ToString()) == "9" || Convert.ToString(dr["Trxn_Type_ID"].ToString()) == "10") ? 0 : Convert.ToDouble(dr["Amount"].ToString());
                                            Dividend_Payout += Convert.ToDouble(dr["Dividend Payout"].ToString());
                                            Present_Value += Convert.ToDouble(dr["Present_Value"].ToString());
                                            Dividend_Amt += Convert.ToDouble(dr["Dividend_Amount"].ToString());
                                            Notional_PL += Convert.ToDouble(dr["Notional P/L"].ToString());
                                            NetGain += Convert.ToDouble(dr["NetGain"].ToString());
                                            ASSET_TYPE = Convert.ToString(dr["ASSET_TYPE"].ToString());
                                        }
                                        Latest_NAV_Date = (dr_temp.Length > 0 ? dr_temp[dr_temp.Length - 1]["Latest_Nav_Date"].ToString() : "--");
                                        Latest_NAV = (dr_temp.Length > 0 ? dr_temp[dr_temp.Length - 1]["Latest_Nav"].ToString() : "--");
                                        DataRow _RowsTT = dt.NewRow();
                                        _RowsTT["Transaction_Type"] = "Balance in Folio :";
                                        _RowsTT["Folio_Number"] = "";
                                        _RowsTT["Scheme_Name"] = "";
                                        _RowsTT["Transaction_Date"] = "";
                                        _RowsTT["Transaction_Price"] = "";
                                        _RowsTT["No_of_Units"] = "";
                                        _RowsTT["Purchase_Value"] = ((double)(Amount - Dividend_Payout)).ToString("N2");
                                        _RowsTT["Maturity_Date"] = "";
                                        _RowsTT["Current_Amount"] = Present_Value.ToString("N2");
                                        _RowsTT["Dividend_Payout"] = Dividend_Payout.ToString("N2");
                                        _RowsTT["Profit_Loss"] = Notional_PL.ToString("N2");
                                        _RowsTT["No_of_Days"] = (Positive_Amount == 0 ? "N.A." : ((ASSET_TYPE == "Equity" && Math.Round((Age == 0 ? 0 : (Age / Amount_weighted[0]))) <= 365) ? (((Present_Value + Dividend_Payout - Positive_Amount) / Positive_Amount) * 100).ToString("N2") : "--"));
                                        _RowsTT["Annual_Return"] = (Positive_Amount == 0 ? "N.A." : ((ASSET_TYPE == "Debt" && Math.Round((Age == 0 ? 0 : (Age / Amount_weighted[0]))) <= 365) ? (((Present_Value + Dividend_Payout - Positive_Amount) / Positive_Amount) * 100 * (365 / (Age / Amount_weighted[0]))).ToString("N2") : "--"));
                                        _RowsTT["CAGR"] = (Positive_Amount == 0 ? "N.A." : ((((ASSET_TYPE == "Equity" || ASSET_TYPE == "Debt") && Math.Round((Age == 0 ? 0 : (Age / Amount_weighted[0]))) >= 365) ? ((Math.Pow(((Present_Value + Dividend_Payout) / Positive_Amount), ((double)(365) / (Age / Amount_weighted[0]))) - 1) * 100).ToString("N2") : "--")));
                                        _RowsTT["Net_Gain"] = NetGain.ToString("N2");
                                        _RowsTT["XIRR"] = FormatFunctions.C_Format.M_FormatComma(Convert.ToString(Calculate_XIRR(Prv_ClientID, "C", Prv_Folio, Prv_SchCode, Present_Value)), "2", "0").ToString();
                                        dt.Rows.Add(_RowsTT);
                                    }
                                    Age_Fund += Age; ABSReturns_Fund += ABSReturns; SimAnnReturns_Fund += SimAnnReturns; CAGR_Fund += CAGR; Amount_weighted_Fund[0] += Amount_weighted[0]; Amount_weighted_Fund[1] += Amount_weighted[1]; Amount_weighted_Fund[2] += Amount_weighted[2]; Amount_weighted_Fund[3] += Amount_weighted[3];
                                    Amount_Fund += Amount; Dividend_Payout_Fund += Dividend_Payout; Present_Value_Fund += Present_Value; Dividend_Amt_Fund += Dividend_Amt; Notional_PL_Fund += Notional_PL; NetGain_Fund += NetGain;
                                }
                                Age_Total += Age_Fund; ABSReturns_Total += ABSReturns_Fund; SimAnnReturns_Total += SimAnnReturns_Fund; CAGR_Total += CAGR_Fund; Amount_weighted_Total[0] += Amount_weighted_Fund[0]; Amount_weighted_Total[1] += Amount_weighted_Fund[1]; Amount_weighted_Total[2] += Amount_weighted_Fund[2]; Amount_weighted_Total[3] += Amount_weighted_Fund[3];
                                Amount_Total += Amount_Fund; Dividend_Payout_Total += Dividend_Payout_Fund; Present_Value_Total += Present_Value_Fund; Dividend_Amt_Total += Dividend_Amt_Fund; Notional_PL_Total += Notional_PL_Fund; NetGain_Total += NetGain_Fund;
                            }
                        }
                        DataRow _RowsGT = dt.NewRow();
                        _RowsGT["Transaction_Type"] = "Grand Total/Weighted Average :";
                        _RowsGT["Folio_Number"] = "";
                        _RowsGT["Scheme_Name"] = "";
                        _RowsGT["Transaction_Date"] = "";
                        _RowsGT["Transaction_Price"] = "";
                        _RowsGT["No_of_Units"] = "";
                        _RowsGT["Purchase_Value"] = ((double)(Amount_Total - Dividend_Payout_Total)).ToString("N2");
                        _RowsGT["Maturity_Date"] = "";
                        _RowsGT["Current_Amount"] = Present_Value_Total.ToString("N2");
                        _RowsGT["Dividend_Payout"] = Dividend_Payout_Total.ToString("N2");
                        _RowsGT["Profit_Loss"] = Notional_PL_Total.ToString("N2");
                        _RowsGT["No_of_Days"] = Math.Round((Age_Total == 0 ? 0 : (Age_Total / Amount_weighted_Total[0])));
                        _RowsGT["Annual_Return"] = ((double)(SimAnnReturns_Total == 0 ? 0 : (SimAnnReturns_Total / Amount_weighted_Total[2]))).ToString("N2");
                        _RowsGT["CAGR"] = ((double)(CAGR_Total == 0 ? 0 : (CAGR_Total / Amount_weighted_Total[3]))).ToString("N2");
                        _RowsGT["Net_Gain"] = NetGain_Total.ToString("N2");
                        _RowsGT["XIRR"] = FormatFunctions.C_Format.M_FormatComma(Convert.ToString(Calculate_XIRR(Prv_ClientID, "C", "", "", Present_Value_Total)), "2", "0").ToString();
                        dt.Rows.Add(_RowsGT);

                        Prv_ClientID = "";
                        Age_TotalG += Age_Total; ABSReturns_TotalG += ABSReturns_Total; SimAnnReturns_TotalG += SimAnnReturns_Total; CAGR_TotalG += CAGR_Total; Amount_weighted_TotalG[0] += Amount_weighted_Total[0]; Amount_weighted_TotalG[1] += Amount_weighted_Total[1]; Amount_weighted_TotalG[2] += Amount_weighted_Total[2]; Amount_weighted_TotalG[3] += Amount_weighted_Total[3];
                        Amount_TotalG += Amount_Total; Dividend_Payout_TotalG += Dividend_Payout_Total; Present_Value_TotalG += Present_Value_Total; Dividend_Amt_TotalG += Dividend_Amt_Total; Notional_PL_TotalG += Notional_PL_Total; NetGain_TotalG += NetGain_Total;
                    }
                    ds.Tables.Add(dt);
                    return ds;
                }
                else
                {
                    DataTable table = new DataTable("DataTable");
                    table.Columns.Add("DataValues", typeof(string));
                    table.Rows.Add("Data Not Found!!!!");
                    ds.Tables.Add(table);
                    return ds;
                }

            }
            catch (Exception ex)
            {
                DataTable table = new DataTable("DataTable");
                table.Columns.Add("DataValues", typeof(string));
                table.Rows.Add("Data Not Found!!!!");
                ds.Tables.Add(table);
                HttpContext con = HttpContext.Current;
                cs.createfile(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.ToString() + " Method Name : " + System.Reflection.MethodBase.GetCurrentMethod().ToString(), con.Request.Url.ToString(), ex.Message.ToString(), ex.GetType().ToString(), "");
                return ds;
            }
        }

        public DataSet STP_Report(DataSet ds)
        {
            try
            {
                if (!(ds == null || ds.Tables[0].Rows.Count == 0))
                {
                    dt.Columns.Add("Transaction_Type");
                    dt.Columns.Add("Folio_Number");
                    dt.Columns.Add("Scheme_Name");
                    dt.Columns.Add("Transaction_Date");
                    dt.Columns.Add("Transaction_Price");
                    dt.Columns.Add("No_of_Units");
                    dt.Columns.Add("STP_Amount");
                    dt.Columns.Add("STP_Start_Date");
                    dt.Columns.Add("STP_End_Date");
                    dt.Columns.Add("Current_Amount");
                    dt.Columns.Add("Dividend_Payout");
                    dt.Columns.Add("Dividend_Reinvest");
                    dt.Columns.Add("Profit_Loss");
                    dt.Columns.Add("No_of_Days");
                    dt.Columns.Add("Absolute_Return");
                    dt.Columns.Add("Annual_Return");
                    dt.Columns.Add("CAGR");
                    dt.Columns.Add("Net_Gain");
                    dt.Columns.Add("XIRR");


                    DataTable dt_Funds = TrObj.SelectDistinct("Fund_ID", ds.Tables[0], "AMC_CODE");
                    DataTable dt_SCHEMES = TrObj.SelectDistinct("SCHEMECODE", ds.Tables[0], "SCHEMECODE");

                    //DataTable dt_Clients = TrObj.SelectDistinct("CName", ds.Tables[0], "Name");
                    DataTable dt_Clients = TrObj.SelectDistinct("Client_ID", ds.Tables[0], "Client_ID");

                    string Latest_NAV_Date = string.Empty, Latest_NAV = string.Empty;
                    double Age_TotalG, ABSReturns_TotalG, SimAnnReturns_TotalG, CAGR_TotalG, Amount_TotalG, Unit_TotalG, Dividend_Payout_TotalG, Present_Value_TotalG, Dividend_Amt_TotalG, Notional_PL_TotalG, NetGain_TotalG;
                    Age_TotalG = ABSReturns_TotalG = SimAnnReturns_TotalG = CAGR_TotalG = Amount_TotalG = Unit_TotalG = Dividend_Payout_TotalG = Present_Value_TotalG = Dividend_Amt_TotalG = Notional_PL_TotalG = NetGain_TotalG = 0;
                    float[] Amount_weighted_TotalG = new float[4];
                    string Prv_Folio = string.Empty;
                    foreach (DataRow dr_ClientID in dt_Clients.Rows)
                    {
                        double Age_Total, ABSReturns_Total, SimAnnReturns_Total, CAGR_Total, Amount_Total, Unit_Total, Dividend_Payout_Total, Present_Value_Total, Dividend_Amt_Total, Notional_PL_Total, NetGain_Total;
                        Age_Total = ABSReturns_Total = SimAnnReturns_Total = CAGR_Total = Amount_Total = Unit_Total = Dividend_Payout_Total = Present_Value_Total = Dividend_Amt_Total = Notional_PL_Total = NetGain_Total = 0;
                        float[] Amount_weighted_Total = new float[4];

                        DataRow[] dr_temp1 = ds.Tables[0].Select("Client_ID = '" + dr_ClientID["Client_ID"].ToString() + "'");
                        if (dr_temp1.Length > 0)
                        {
                            string Prv_ClientID = string.Empty;
                            string Prv_Fund = string.Empty;
                            foreach (DataRow dr_Funds in dt_Funds.Rows)
                            {
                                if (((DataRow[])ds.Tables[0].Select("AMC_CODE = '" + dr_Funds["AMC_CODE"].ToString() + "' and Client_ID = '" + dr_ClientID["Client_ID"].ToString() + "'")).Length > 0)
                                {
                                    string Prv_Sch = string.Empty;
                                    string Prv_SchCode = string.Empty;

                                    double Age_Fund, ABSReturns_Fund, SimAnnReturns_Fund, CAGR_Fund, Amount_Fund, Unit_Fund, Dividend_Payout_Fund, Present_Value_Fund, Dividend_Amt_Fund, Notional_PL_Fund, NetGain_Fund;
                                    Age_Fund = ABSReturns_Fund = SimAnnReturns_Fund = CAGR_Fund = Amount_Fund = Unit_Fund = Dividend_Payout_Fund = Present_Value_Fund = Dividend_Amt_Fund = Notional_PL_Fund = NetGain_Fund = 0;
                                    float[] Amount_weighted_Fund = new float[4];

                                    foreach (DataRow dr_SCHEMES in dt_SCHEMES.Rows)
                                    {
                                        DataRow[] dr_temp = ds.Tables[0].Select("AMC_CODE = '" + dr_Funds["AMC_CODE"].ToString() + "' and SCHEMECODE = '" + dr_SCHEMES["SCHEMECODE"].ToString() + "' and Client_ID = '" + dr_ClientID["Client_ID"].ToString() + "'");
                                        //DataRow[] dr_temp = ds.Tables[0].Select("AMC_CODE = '" + dr_Funds["AMC_CODE"].ToString() + "' and SCHEMECODE = '" + dr_SCHEMES["SCHEMECODE"].ToString() + "' and Name = '" + dr_Names["Name"].ToString() + "'");
                                        double Age, ABSReturns, SimAnnReturns, CAGR, Amount, Unit, Positive_Amount, Dividend_Payout, Present_Value, Dividend_Amt, Notional_PL, NetGain;
                                        Age = ABSReturns = SimAnnReturns = CAGR = Amount = Unit = Positive_Amount = Dividend_Payout = Present_Value = Dividend_Amt = Notional_PL = NetGain = 0;
                                        float[] Amount_weighted = new float[4];
                                        string ASSET_TYPE = string.Empty;

                                        if (dr_temp.Length > 0)
                                        {
                                            foreach (DataRow dr in dr_temp)
                                            {
                                                if (!(Prv_Folio == dr["Folio_Number"].ToString() && Prv_Sch == dr["S_Name"].ToString()))
                                                {
                                                    Prv_ClientID = dr["Client_ID"].ToString();
                                                    if (!(Prv_Folio == string.Empty || Prv_Sch == string.Empty) && Prv_Sch == dr["S_Name"].ToString())
                                                    {
                                                        Latest_NAV_Date = (dr_temp.Length > 0 ? dr_temp[dr_temp.Length - 1]["Latest_Nav_Date"].ToString() : "--");
                                                        Latest_NAV = (dr_temp.Length > 0 ? dr_temp[dr_temp.Length - 1]["Latest_Nav"].ToString() : "--");
                                                        DataRow _RowsT = dt.NewRow();
                                                        _RowsT["Transaction_Type"] = "Balance in Folio :";
                                                        _RowsT["Folio_Number"] = Prv_Folio;
                                                        _RowsT["Scheme_Name"] = "";
                                                        _RowsT["Transaction_Date"] = "";
                                                        _RowsT["Transaction_Price"] = "";
                                                        _RowsT["No_of_Units"] = ((double)(Unit)).ToString("N3");
                                                        _RowsT["STP_Amount"] = ((double)(Amount - Dividend_Payout)).ToString("N2");
                                                        _RowsT["STP_Start_Date"] = "";
                                                        _RowsT["STP_End_Date"] = "";
                                                        _RowsT["Current_Amount"] = Present_Value.ToString("N2");
                                                        _RowsT["Dividend_Payout"] = Dividend_Payout.ToString("N2");
                                                        _RowsT["Dividend_Reinvest"] = Dividend_Amt.ToString("N2");
                                                        _RowsT["Profit_Loss"] = Notional_PL.ToString("N2");
                                                        _RowsT["No_of_Days"] = "";
                                                        _RowsT["Absolute_Return"] = (Positive_Amount == 0 ? "N.A." : ((ASSET_TYPE == "Equity" && Math.Round((Age == 0 ? 0 : (Age / Amount_weighted[0]))) <= 365) ? (((Present_Value + Dividend_Payout - Positive_Amount) / Positive_Amount) * 100).ToString("N2") : "--"));
                                                        _RowsT["Annual_Return"] = (Positive_Amount == 0 ? "N.A." : ((ASSET_TYPE == "Debt" && Math.Round((Age == 0 ? 0 : (Age / Amount_weighted[0]))) <= 365) ? (((Present_Value + Dividend_Payout - Positive_Amount) / Positive_Amount) * 100 * (365 / (Age / Amount_weighted[0]))).ToString("N2") : "--"));
                                                        _RowsT["CAGR"] = (Positive_Amount == 0 ? "N.A." : ((((ASSET_TYPE == "Equity" || ASSET_TYPE == "Debt") && Math.Round((Age == 0 ? 0 : (Age / Amount_weighted[0]))) >= 365) ? ((Math.Pow(((Present_Value + Dividend_Payout) / Positive_Amount), ((double)(365) / (Age / Amount_weighted[0]))) - 1) * 100).ToString("N2") : "--")));
                                                        _RowsT["Net_Gain"] = NetGain.ToString("N2");
                                                        _RowsT["XIRR"] = FormatFunctions.C_Format.M_FormatComma(Convert.ToString(Calculate_XIRR(Prv_ClientID, "C", Prv_Folio, Prv_SchCode, Present_Value)), "2", "0").ToString();
                                                        dt.Rows.Add(_RowsT);

                                                        Age_Fund += Age; ABSReturns_Fund += ABSReturns; SimAnnReturns_Fund += SimAnnReturns; CAGR_Fund += CAGR; Amount_weighted_Fund[0] += Amount_weighted[0]; Amount_weighted_Fund[1] += Amount_weighted[1]; Amount_weighted_Fund[2] += Amount_weighted[2]; Amount_weighted_Fund[3] += Amount_weighted[3];
                                                        Amount_Fund += Amount; Unit_Fund += Unit; Dividend_Payout_Fund += Dividend_Payout; Present_Value_Fund += Present_Value; Dividend_Amt_Fund += Dividend_Amt; Notional_PL_Fund += Notional_PL; NetGain_Fund += NetGain;
                                                        Age = ABSReturns = SimAnnReturns = CAGR = Amount = Positive_Amount = Dividend_Payout = Present_Value = Dividend_Amt = Notional_PL = NetGain = 0;
                                                        Amount_weighted = new float[4];
                                                        ASSET_TYPE = string.Empty;
                                                    }
                                                    Prv_Folio = dr["Folio_Number"].ToString();
                                                    Prv_Sch = dr["S_Name"].ToString();
                                                    Prv_SchCode = dr["schemecode"].ToString();
                                                }

                                                DataRow _Rows = dt.NewRow();
                                                _Rows["Transaction_Type"] = dr["trxn_type_Name"].ToString();
                                                _Rows["Folio_Number"] = dr["Folio_Number"].ToString();
                                                _Rows["Scheme_Name"] = dr["S_Name"].ToString();
                                                _Rows["Transaction_Date"] = dr["Trxn_Date"].ToString();
                                                _Rows["Transaction_Price"] = dr["Price"].ToString();
                                                _Rows["No_of_Units"] = dr["Units"].ToString();
                                                _Rows["STP_Amount"] = dr["Amount"].ToString();
                                                _Rows["STP_Start_Date"] = dr["STPStartDate"].ToString();
                                                _Rows["STP_End_Date"] = dr["STPEndDate"].ToString();
                                                _Rows["Current_Amount"] = dr["Present_Value"].ToString();
                                                _Rows["Dividend_Payout"] = dr["Dividend Payout"].ToString();
                                                _Rows["Dividend_Reinvest"] = dr["Dividend_Amount"].ToString();
                                                _Rows["Profit_Loss"] = dr["Notional P/L"].ToString();
                                                _Rows["No_of_Days"] = dr["Age"].ToString();
                                                _Rows["Absolute_Return"] = (Convert.ToDouble(dr["Absolute_Returns"].ToString()) == 0 ? "--" : dr["Absolute_Returns"].ToString());
                                                _Rows["Annual_Return"] = (Convert.ToDouble(dr["Sim_Ann_Returns"].ToString()) == 0 ? "--" : dr["Sim_Ann_Returns"].ToString());
                                                _Rows["CAGR"] = (Convert.ToDouble(dr["CAGR"].ToString()) == 0 ? "--" : dr["CAGR"].ToString());
                                                _Rows["Net_Gain"] = dr["NetGain"].ToString();
                                                _Rows["XIRR"] = "--";
                                                dt.Rows.Add(_Rows);

                                                if (Convert.ToDouble(dr["PortFolio_Unitbal"].ToString()) != 0)
                                                {
                                                    double weighted_Amount = Convert.ToDouble(dr["Amount"].ToString());
                                                    Age += Convert.ToDouble(dr["Age"].ToString()) * weighted_Amount;
                                                    ABSReturns += Convert.ToDouble(dr["Absolute_Returns"].ToString()) * weighted_Amount;
                                                    SimAnnReturns += Convert.ToDouble(dr["Sim_Ann_Returns"].ToString()) * weighted_Amount;
                                                    CAGR += Convert.ToDouble(dr["CAGR"].ToString()) * weighted_Amount;

                                                    if (Convert.ToDouble(dr["Age"].ToString()) != 0) Amount_weighted[0] += (float)weighted_Amount;
                                                    if (Convert.ToDouble(dr["Absolute_Returns"].ToString()) != 0) Amount_weighted[1] += (float)weighted_Amount;
                                                    if (Convert.ToDouble(dr["Sim_Ann_Returns"].ToString()) != 0) Amount_weighted[2] += (float)weighted_Amount;
                                                    if (Convert.ToDouble(dr["CAGR"].ToString()) != 0) Amount_weighted[3] += (float)weighted_Amount;
                                                    //Amount_weighted += Convert.ToDouble(dr["Amount"].ToString());
                                                }
                                                Amount += Convert.ToDouble(dr["Amount"].ToString());//
                                                Unit += Convert.ToDouble(dr["Units"].ToString());//
                                                Positive_Amount += (Convert.ToString(dr["Trxn_Type_ID"].ToString()) == "9" || Convert.ToString(dr["Trxn_Type_ID"].ToString()) == "10") ? 0 : Convert.ToDouble(dr["Amount"].ToString());
                                                Dividend_Payout += Convert.ToDouble(dr["Dividend Payout"].ToString());
                                                Present_Value += Convert.ToDouble(dr["Present_Value"].ToString());
                                                Dividend_Amt += Convert.ToDouble(dr["Dividend_Amount"].ToString());
                                                Notional_PL += Convert.ToDouble(dr["Notional P/L"].ToString());
                                                NetGain += Convert.ToDouble(dr["NetGain"].ToString());
                                                ASSET_TYPE = Convert.ToString(dr["ASSET_TYPE"].ToString());
                                            }

                                            Latest_NAV_Date = (dr_temp.Length > 0 ? dr_temp[dr_temp.Length - 1]["Latest_Nav_Date"].ToString() : "--");
                                            Latest_NAV = (dr_temp.Length > 0 ? dr_temp[dr_temp.Length - 1]["Latest_Nav"].ToString() : "--");
                                            DataRow _RowsTT = dt.NewRow();
                                            _RowsTT["Transaction_Type"] = "Balance in Folio :";
                                            _RowsTT["Folio_Number"] = Prv_Folio;
                                            _RowsTT["Scheme_Name"] = "";
                                            _RowsTT["Transaction_Date"] = "";
                                            _RowsTT["Transaction_Price"] = "";
                                            _RowsTT["No_of_Units"] = ((double)(Unit)).ToString("N3");
                                            _RowsTT["STP_Amount"] = ((double)(Amount - Dividend_Payout)).ToString("N2");
                                            _RowsTT["STP_Start_Date"] = "";
                                            _RowsTT["STP_End_Date"] = "";
                                            _RowsTT["Current_Amount"] = Present_Value.ToString("N2");
                                            _RowsTT["Dividend_Payout"] = Dividend_Payout.ToString("N2");
                                            _RowsTT["Dividend_Reinvest"] = Dividend_Amt.ToString("N2");
                                            _RowsTT["Profit_Loss"] = Notional_PL.ToString("N2");
                                            _RowsTT["No_of_Days"] = Math.Round((Age == 0 ? 0 : (Age / Amount_weighted[0])));
                                            _RowsTT["Absolute_Return"] = (Positive_Amount == 0 ? "N.A." : ((ASSET_TYPE == "Equity" && Math.Round((Age == 0 ? 0 : (Age / Amount_weighted[0]))) <= 365) ? (((Present_Value + Dividend_Payout - Positive_Amount) / Positive_Amount) * 100).ToString("N2") : "--"));
                                            _RowsTT["Annual_Return"] = (Positive_Amount == 0 ? "N.A." : ((ASSET_TYPE == "Debt" && Math.Round((Age == 0 ? 0 : (Age / Amount_weighted[0]))) <= 365) ? (((Present_Value + Dividend_Payout - Positive_Amount) / Positive_Amount) * 100 * (365 / (Age / Amount_weighted[0]))).ToString("N2") : "--"));
                                            _RowsTT["CAGR"] = (Positive_Amount == 0 ? "N.A." : ((((ASSET_TYPE == "Equity" || ASSET_TYPE == "Debt") && Math.Round((Age == 0 ? 0 : (Age / Amount_weighted[0]))) >= 365) ? ((Math.Pow(((Present_Value + Dividend_Payout) / Positive_Amount), ((double)(365) / (Age / Amount_weighted[0]))) - 1) * 100).ToString("N2") : "--")));
                                            _RowsTT["Net_Gain"] = NetGain.ToString("N2");
                                            _RowsTT["XIRR"] = FormatFunctions.C_Format.M_FormatComma(Convert.ToString(Calculate_XIRR(Prv_ClientID, "C", Prv_Folio, Prv_SchCode, Present_Value)), "2", "0").ToString();
                                            dt.Rows.Add(_RowsTT);

                                        }

                                        Age_Fund += Age; ABSReturns_Fund += ABSReturns; SimAnnReturns_Fund += SimAnnReturns; CAGR_Fund += CAGR; Amount_weighted_Fund[0] += Amount_weighted[0]; Amount_weighted_Fund[1] += Amount_weighted[1]; Amount_weighted_Fund[2] += Amount_weighted[2]; Amount_weighted_Fund[3] += Amount_weighted[3];
                                        Amount_Fund += Amount; Unit_Fund += Unit; Dividend_Payout_Fund += Dividend_Payout; Present_Value_Fund += Present_Value; Dividend_Amt_Fund += Dividend_Amt; Notional_PL_Fund += Notional_PL; NetGain_Fund += NetGain;
                                    }
                                    /*Grid_HTML += "<tr><td style='width:10%; white-space:nowrap;' class='Label1' colspan='4'>Fund wise Balance in Folio :</td><td class='Label1' style='width:15%; white-space:nowrap; text-align:right; padding-right:5px; padding-left:10px;'>" + Math.Round(Amount_Fund, 2) + "</td><td class='Label1' style='width:15%; white-space:nowrap; text-align:center; padding-right:5px; padding-left:5px;'>" + Latest_NAV_Date + "</td><td class='Label1' style='width:15%; white-space:nowrap; text-align:right; padding-right:5px; padding-left:10px;'>" + Latest_NAV + "</td><td class='Label1' style='width:15%; white-space:nowrap; text-align:right; padding-right:5px; padding-left:10px;'>" + Math.Round(Present_Value_Fund, 2) + "</td>" +
                                                 "<td class='Label1' style='width:15%; white-space:nowrap; text-align:right; padding-right:5px; padding-left:10px;'>" + Math.Round(Dividend_Payout_Fund, 2) + "</td><td class='Label1' style='width:15%; white-space:nowrap; text-align:right; padding-right:5px; padding-left:10px;'>" + Math.Round(Dividend_Amt_Fund, 2) + "</td><td class='Label1' style='width:15%; white-space:nowrap; text-align:right; padding-right:5px; padding-left:10px;'>" + Math.Round(Notional_PL_Fund, 2) + "</td><td class='Label1' style='width:15%; white-space:nowrap; text-align:right; padding-right:5px; padding-left:10px;'>" + Math.Round((Age_Fund == 0 ? 0 : (Age_Fund / Amount_weighted_Fund[0]))) + "</td><td class='Label1' style='width:15%; white-space:nowrap; text-align:right; padding-right:5px; padding-left:10px;'>" + Math.Round((ABSReturns_Fund == 0 ? 0 : (ABSReturns_Fund / Amount_weighted_Fund[1])), 2) + "</td><td class='Label1' style='width:15%; white-space:nowrap; text-align:right; padding-right:5px; padding-left:10px;'>" + Math.Round((SimAnnReturns_Fund == 0 ? 0 : (SimAnnReturns_Fund / Amount_weighted_Fund[2])), 2) + "</td><td class='Label1' style='width:15%; white-space:nowrap; text-align:right; padding-right:5px; padding-left:10px;'>" + Math.Round((CAGR_Fund == 0 ? 0 : (CAGR_Fund / Amount_weighted_Fund[3])), 2) + "</td><td class='Label1' style='width:15%; white-space:nowrap; text-align:right; padding-right:5px; padding-left:10px;'>" + Math.Round(NetGain_Fund, 2) + "</td></tr>";
                                    */
                                    Age_Total += Age_Fund; ABSReturns_Total += ABSReturns_Fund; SimAnnReturns_Total += SimAnnReturns_Fund; CAGR_Total += CAGR_Fund; Amount_weighted_Total[0] += Amount_weighted_Fund[0]; Amount_weighted_Total[1] += Amount_weighted_Fund[1]; Amount_weighted_Total[2] += Amount_weighted_Fund[2]; Amount_weighted_Total[3] += Amount_weighted_Fund[3];
                                    Amount_Total += Amount_Fund; Unit_Total += Unit_Fund; Dividend_Payout_Total += Dividend_Payout_Fund; Present_Value_Total += Present_Value_Fund; Dividend_Amt_Total += Dividend_Amt_Fund; Notional_PL_Total += Notional_PL_Fund; NetGain_Total += NetGain_Fund;
                                }
                            }
                            DataRow _RowsGT = dt.NewRow();
                            _RowsGT["Transaction_Type"] = "Grand Total/Weighted Average :";
                            _RowsGT["Folio_Number"] = "";
                            _RowsGT["Scheme_Name"] = "";
                            _RowsGT["Transaction_Date"] = "";
                            _RowsGT["Transaction_Price"] = "";
                            _RowsGT["No_of_Units"] = ((double)(Unit_Total)).ToString("N3");
                            _RowsGT["STP_Amount"] = ((double)(Amount_Total - Dividend_Payout_Total)).ToString("N2");
                            _RowsGT["STP_Start_Date"] = "";
                            _RowsGT["STP_End_Date"] = "";
                            _RowsGT["Current_Amount"] = Present_Value_Total.ToString("N2");
                            _RowsGT["Dividend_Payout"] = Dividend_Payout_Total.ToString("N2");
                            _RowsGT["Dividend_Reinvest"] = Dividend_Amt_Total.ToString("N2");
                            _RowsGT["Profit_Loss"] = Notional_PL_Total.ToString("N2");
                            _RowsGT["No_of_Days"] = Math.Round((Age_Total == 0 ? 0 : (Age_Total / Amount_weighted_Total[0])));
                            _RowsGT["Absolute_Return"] = ((double)(ABSReturns_Total == 0 ? 0 : (ABSReturns_Total / Amount_weighted_Total[1]))).ToString("N2");
                            _RowsGT["Annual_Return"] = ((double)(SimAnnReturns_Total == 0 ? 0 : (SimAnnReturns_Total / Amount_weighted_Total[2]))).ToString("N2");
                            _RowsGT["CAGR"] = ((double)(CAGR_Total == 0 ? 0 : (CAGR_Total / Amount_weighted_Total[3]))).ToString("N2");
                            _RowsGT["Net_Gain"] = NetGain_Total.ToString("N2");
                            _RowsGT["XIRR"] = FormatFunctions.C_Format.M_FormatComma(Convert.ToString(Calculate_XIRR(Prv_ClientID, "C", "", "", Present_Value_Total)), "2", "0").ToString();
                            dt.Rows.Add(_RowsGT);
                            Prv_ClientID = "";
                            Age_TotalG += Age_Total; ABSReturns_TotalG += ABSReturns_Total; SimAnnReturns_TotalG += SimAnnReturns_Total; CAGR_TotalG += CAGR_Total; Amount_weighted_TotalG[0] += Amount_weighted_Total[0]; Amount_weighted_TotalG[1] += Amount_weighted_Total[1]; Amount_weighted_TotalG[2] += Amount_weighted_Total[2]; Amount_weighted_TotalG[3] += Amount_weighted_Total[3];
                            Amount_TotalG += Amount_Total; Unit_TotalG += Unit_Total; Dividend_Payout_TotalG += Dividend_Payout_Total; Present_Value_TotalG += Present_Value_Total; Dividend_Amt_TotalG += Dividend_Amt_Total; Notional_PL_TotalG += Notional_PL_Total; NetGain_TotalG += NetGain_Total;
                        }
                    }

                    ds.Tables.Add(dt);
                    return ds;
                }
                else
                {
                    DataTable table = new DataTable("DataTable");
                    table.Columns.Add("DataValues", typeof(string));
                    table.Rows.Add("Data Not Found!!!!");
                    ds.Tables.Add(table);
                    return ds;
                }

            }
            catch (Exception ex)
            {
                DataTable table = new DataTable("DataTable");
                table.Columns.Add("DataValues", typeof(string));
                table.Rows.Add("Data Not Found!!!!");
                ds.Tables.Add(table);
                HttpContext con = HttpContext.Current;
                cs.createfile(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.ToString() + " Method Name : " + System.Reflection.MethodBase.GetCurrentMethod().ToString(), con.Request.Url.ToString(), ex.Message.ToString(), ex.GetType().ToString(), "");
                return ds;
            }
        }

        public DataTable get_Get_ClientAllocation(string Procedures, string PAN)
        {
            try
            {
                nv.Clear();
                nv.Add("@pan", PAN);
                dt = TrObj.GetDataTable(Procedures, nv);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dt.Dispose();
            }
            return dt;
        }

        public DataTable get_Get_Allocation(string Procedures, string PAN, string From_Date, string On_Date)
        {
            try
            {
                nv.Clear();
                nv.Add("@pan", PAN);
                nv.Add("@FromDate", From_Date);
                nv.Add("@OnDate", On_Date);
                dt = TrObj.GetDataTable(Procedures, nv);
            }
            catch (Exception ex)
            {
                HttpContext con = HttpContext.Current;
                cs.createfile(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.ToString() + " Method Name : " + System.Reflection.MethodBase.GetCurrentMethod().ToString(), con.Request.Url.ToString(), ex.Message.ToString(), ex.GetType().ToString(), "");
            }
            finally
            {
                dt.Dispose();
            }
            return dt;
        }

        public double Calculate_XIRR(string Client_ID, string type, string Folio, string scheme, double Currentval)
        {
            DataSet dsX = null;
            double XIRRVal;
            try
            {
                dsX = XIRR_proc_SchemeFolio(Client_ID, type, Folio, scheme, Currentval, (_ID == "2") ? "Y" : "N", ToDate);
                SampleAPI.Models.XIRRFunction.CashFlow[] cfs = new SampleAPI.Models.XIRRFunction.CashFlow[dsX.Tables[0].Rows.Count];

                for (int x = 0; x < dsX.Tables[0].Rows.Count; x++)
                {
                    if (dsX.Tables[0].Rows[x]["Trxn_Date"].ToString() != "" && dsX.Tables[0].Rows[x]["Amount"].ToString() != "")
                    {
                        cfs[x] = new SampleAPI.Models.XIRRFunction.CashFlow(Convert.ToDouble(dsX.Tables[0].Rows[x]["Amount"]), Convert.ToDateTime(dsX.Tables[0].Rows[x]["Trxn_Date"]));
                    }
                }
                XIRRVal = SampleAPI.Models.XIRRFunction.FinFunctions.CalculateXIRR(cfs).Value * 100;
                dsX = null;
            }
            catch (Exception ex)
            {
                HttpContext con = HttpContext.Current;
                cs.createfile(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.ToString() + " Method Name : " + System.Reflection.MethodBase.GetCurrentMethod().ToString(), con.Request.Url.ToString(), ex.Message.ToString(), ex.GetType().ToString(), "");
                XIRRVal = 0.00;
            }
            return XIRRVal;
        }

        public double Calculate_XIRR(string Client_ID, string type, string Folio, string scheme, double Currentval, string reporttype)
        {
            DataSet dsX = null;
            double XIRRVal;
            try
            {
                NameValueCollection nv = new NameValueCollection();
                nv.Add("@ClientID", Client_ID);
                nv.Add("@Type", type);
                nv.Add("@Folio_Number", Folio);
                nv.Add("@Schemecode", scheme);
                nv.Add("@Currentval", Convert.ToString(Currentval));
                if (reporttype == "Fixed_Maturity_Plan_Report")
                {
                    dsX = TrObj.GetDataSet("XIRR_proc_FMPSchemeFolio", nv);
                }
                else if (reporttype == "STP_Report")
                {
                    dsX = TrObj.GetDataSet("XIRR_proc_STPSchemeFolio", nv);
                }
                else
                {
                    dsX = TrObj.GetDataSet("XIRR_proc_SchemeFolio", nv);
                }
                SampleAPI.Models.XIRRFunction.CashFlow[] cfs = new SampleAPI.Models.XIRRFunction.CashFlow[dsX.Tables[0].Rows.Count];

                for (int x = 0; x < dsX.Tables[0].Rows.Count; x++)
                {
                    if (dsX.Tables[0].Rows[x]["Trxn_Date"].ToString() != "" && dsX.Tables[0].Rows[x]["Amount"].ToString() != "")
                    {
                        cfs[x] = new SampleAPI.Models.XIRRFunction.CashFlow(Convert.ToDouble(dsX.Tables[0].Rows[x]["Amount"]), Convert.ToDateTime(dsX.Tables[0].Rows[x]["Trxn_Date"]));
                    }
                }
                XIRRVal = SampleAPI.Models.XIRRFunction.FinFunctions.CalculateXIRR(cfs).Value * 100;
                dsX = null;
                return XIRRVal;
            }
            catch (Exception ex)
            {
                HttpContext con = HttpContext.Current;
                cs.createfile(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.ToString() + " Method Name : " + System.Reflection.MethodBase.GetCurrentMethod().ToString(), con.Request.Url.ToString(), ex.Message.ToString(), ex.GetType().ToString(), "");
                return 0.00;
            }

        }

        public DataSet XIRR_proc_SchemeFolio(string client_Id, string Type, string Folio_Number, string Schemecode, double Currentval, string Redeemed_Folios, string OnDate)
        {
            NameValueCollection nv = new NameValueCollection();

            //if (Folio_Number == "")
            OnDate = DateTime.Now.ToString("dd-MMM-yyyy");

            nv.Add("@ClientID", client_Id);
            nv.Add("@Type", Type);
            nv.Add("@Folio_Number", Folio_Number);
            nv.Add("@Schemecode", Schemecode);
            nv.Add("@Currentval", Convert.ToString(Currentval));
            nv.Add("@Redeemed_Folios", Redeemed_Folios);
            nv.Add("@OnDate", OnDate);
            return TrObj.GetDataSet("XIRR_proc_SchemeFolio_New", nv);
        }

        public double Calculate_XIRR(DataTable dt)
        {
            double XIRRVal = 0;
            SampleAPI.Models.XIRRFunction.CashFlow[] cfs = new SampleAPI.Models.XIRRFunction.CashFlow[dt.Rows.Count];
            for (int x = 0; x < dt.Rows.Count; x++)
            {
                if (dt.Rows[x]["Date"].ToString() != "" && dt.Rows[x]["Amount"].ToString() != "")
                {
                    cfs[x] = new SampleAPI.Models.XIRRFunction.CashFlow(Convert.ToDouble(dt.Rows[x]["Amount"]), Convert.ToDateTime(dt.Rows[x]["Date"]));
                }
            }
            try
            {
                XIRRVal = SampleAPI.Models.XIRRFunction.FinFunctions.CalculateXIRR(cfs).Value * 100;
            }
            catch (Exception ex) {
                HttpContext con = HttpContext.Current;
                cs.createfile(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.ToString() + " Method Name : " + System.Reflection.MethodBase.GetCurrentMethod().ToString(), con.Request.Url.ToString(), ex.Message.ToString(), ex.GetType().ToString(), "");
                dt = null; }
            dt = null;
            return XIRRVal;
        }

        public string Folio_N, sch_Code, Tot_Folio = string.Empty, Tot_Sch = string.Empty, Clnt_Id, UID;

        public DataTable XIRRtable(DataSet ds, string schemecode, string folio)
        {
            DataTable dt = new DataTable();

            dt.Columns.Add("Date", typeof(DateTime));
            dt.Columns.Add("Trxn_Type");
            dt.Columns.Add("Amount");
            if (schemecode != "" && folio != "")
            {
                DataRow[] dataRows = ds.Tables[0].Select("SchemeCode=" + schemecode + " and Folio_Number='" + folio + "'");
                foreach (DataRow dr in dataRows)
                {
                    dt.Rows.Add(new object[] { dr["Trxn_Date"].ToString(), dr["Trxn_Type_NameP"].ToString(), dr["Purchase Amount"].ToString() });
                    dt.Rows.Add(new object[] { dr["Sell Date"].ToString(), dr["Trxn_Type_NameS"].ToString(), "-" + (dr["Sell Amount"].ToString()) });
                }

            }
            else
            {
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    dt.Rows.Add(new object[] { dr["Trxn_Date"].ToString(), dr["Trxn_Type_NameP"].ToString(), dr["Purchase Amount"].ToString() });
                    dt.Rows.Add(new object[] { dr["Sell Date"].ToString(), dr["Trxn_Type_NameS"].ToString(), "-" + (dr["Sell Amount"].ToString()) });
                }

            }
            dt.DefaultView.Sort = "Date ASC";
            return dt;
        }

        public string Calculate_XIRR(string Client_ID, string FromDate, string ToDate, string Folio_Number, string Schemecode, string UID)
        {
            DataTable dsX = null;
            string XIRRVal = "";

            UID = "5";

            FromDate = FormatFunctions.C_Format.M_FormatDate(FromDate, "MM/dd/yyyy").ToString();
            ToDate = FormatFunctions.C_Format.M_FormatDate(ToDate, "MM/dd/yyyy").ToString();
            try
            {
                System.Collections.Specialized.NameValueCollection nv = new System.Collections.Specialized.NameValueCollection();

                nv.Add("@ClientID", Client_ID);
                nv.Add("@FromDate", FromDate);
                nv.Add("@ToDate", ToDate);
                nv.Add("@Folio_Number", Folio_Number);
                nv.Add("@Schemecode", Schemecode);
                nv.Add("@UID", UID);

                dsX = TrObj.GetDataTable("XIRR_Proc_CapitalGainLoss", nv);
                //dsX = objXirr.XIRR_Proc_CapitalGainLoss(ClientID, FromDate, ToDate, Folio_Number, Schemecode, UID);
                SampleAPI.Models.XIRRFunction.CashFlow[] cfs = new SampleAPI.Models.XIRRFunction.CashFlow[dsX.Rows.Count];

                for (int x = 0; x < dsX.Rows.Count; x++)
                {
                    if (dsX.Rows[x]["Trxn_Date"].ToString() != "" && dsX.Rows[x]["Purchase Amount"].ToString() != "")
                    {
                        cfs[x] = new SampleAPI.Models.XIRRFunction.CashFlow(Convert.ToDouble(dsX.Rows[x]["Purchase Amount"]), Convert.ToDateTime(dsX.Rows[x]["Trxn_Date"]));
                    }
                }
                XIRRVal = Convert.ToString(SampleAPI.Models.XIRRFunction.FinFunctions.CalculateXIRR(cfs).Value * 100);
                dsX = null;
            }
            catch (Exception ex)
            {
                HttpContext con = HttpContext.Current;
                cs.createfile(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.ToString() + " Method Name : " + System.Reflection.MethodBase.GetCurrentMethod().ToString(), con.Request.Url.ToString(), ex.Message.ToString(), ex.GetType().ToString(), "");
                XIRRVal = "0";
            }
            return XIRRVal;
        }

        public string Calculate_XIRR_SIP(string SrNo, string Client_ID, string type, string Folio, string scheme, string Currentval, string Amount)
        {
            DataSet dsX = null;
            string XIRRVal = "";
            try
            {

                if (SrNo == "" || SrNo == null)
                {

                }
                else
                {
                    if (Folio == "" || Folio == null)
                    {
                        if (Tot_Folio != string.Empty)
                        {
                            Folio = Tot_Folio.Substring(1);
                            scheme = Tot_Sch.Substring(1);
                        }
                        if (Client_ID == "1")
                            Client_ID = "";
                        else
                            Client_ID = Clnt_Id;

                    }
                    else
                    {
                        Tot_Folio += "," + Folio;
                        Tot_Sch += "," + scheme;
                        Clnt_Id = Client_ID;
                    }

                    dsX = XIRR_proc_SchemeFolio_SIP(Client_ID, type, Folio, scheme, Convert.ToDouble(Currentval), "T", Convert.ToDouble(Amount));
                    SampleAPI.Models.XIRRFunction.CashFlow[] cfs = new SampleAPI.Models.XIRRFunction.CashFlow[dsX.Tables[0].Rows.Count];

                    for (int x = 0; x < dsX.Tables[0].Rows.Count; x++)
                    {
                        if (dsX.Tables[0].Rows[x]["Trxn_Date"].ToString() != "" && dsX.Tables[0].Rows[x]["Amount"].ToString() != "")
                        {
                            cfs[x] = new SampleAPI.Models.XIRRFunction.CashFlow(Convert.ToDouble(dsX.Tables[0].Rows[x]["Amount"]), Convert.ToDateTime(dsX.Tables[0].Rows[x]["Trxn_Date"]));
                        }
                    }
                    XIRRVal = Convert.ToString(SampleAPI.Models.XIRRFunction.FinFunctions.CalculateXIRR(cfs).Value * 100);
                    dsX = null;


                }
                return XIRRVal;
            }
            catch (Exception ex)
            {
                HttpContext con = HttpContext.Current;
                cs.createfile(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.ToString() + " Method Name : " + System.Reflection.MethodBase.GetCurrentMethod().ToString(), con.Request.Url.ToString(), ex.Message.ToString(), ex.GetType().ToString(), "");

                return "0.00";
            }
        }

        public DataSet XIRR_proc_SchemeFolio_SIP(string client_Id, string Type, string Folio_Number, string Schemecode, double Currentval, string SIP, double Amount)
        {

            //DataSet ds;
            NameValueCollection nv = new NameValueCollection();

            nv.Add("@ClientID", client_Id);
            nv.Add("@Type", Type);
            nv.Add("@Folio_Number", Folio_Number);
            nv.Add("@Schemecode", Schemecode);
            nv.Add("@Currentval", Convert.ToString(Currentval));
            nv.Add("@SIP", SIP);
            nv.Add("@Amount", Convert.ToString(Amount));

            return TrObj.GetDataSet("XIRR_proc_SchemeFolio_SIP", nv);
        }
    }
}