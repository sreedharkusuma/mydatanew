﻿using System;
using System.IO;
using System.Web;

namespace SampleAPI.Models
{
    public class Common
    {
        public string flPath = "", flNm = "", Dir, Flexist = "N", start_date = "", end_date = "";

        public void createfile(string methodPageName, string pageName, string exceptionMessage, string exceptionType, string flPath)
        {
            try
            {
                Dir = HttpContext.Current.Server.MapPath("~") + "\\ErrorFiles\\";
                flNm = Dir + "ErrorFile.txt";

                if (!Directory.Exists(Dir))
                    Directory.CreateDirectory(Dir);

                string[] filePaths = Directory.GetFiles(Dir);
                foreach (string fileName in filePaths)
                {
                    if (fileName.ToString() == flNm.ToString())
                    {
                        Flexist = "Y";
                    }
                }
                if (Flexist == "N")
                {
                    if (exceptionType != "System.Threading.ThreadAbortException")
                    {
                        StreamWriter SW = File.CreateText(flNm);
                        SW.WriteLine(methodPageName + Environment.NewLine + "Url:" + pageName + Environment.NewLine + "Exception :" + exceptionMessage + Environment.NewLine + " Exception Type:" + exceptionType + Environment.NewLine + "Date :" + DateTime.Now.ToString("dd MMM yyyy") + Environment.NewLine + "Time :" + DateTime.Now.ToString("hh:mm:ss tt") + Environment.NewLine + "IP Address :" + GetIPAddress() + Environment.NewLine);
                        SW.Close();
                    }
                }
                else
                {
                    if (exceptionType != "System.Threading.ThreadAbortException")
                    {
                        StreamWriter SWA = File.AppendText(flNm);
                        SWA.WriteLine(methodPageName + Environment.NewLine + "Url:" + pageName + Environment.NewLine + " Exception :" + exceptionMessage + Environment.NewLine + " Exception Type:" + exceptionType + Environment.NewLine + "Date :" + DateTime.Now.ToString("dd MMM yyyy") + Environment.NewLine + "Time :" + DateTime.Now.ToString("hh:mm:ss tt") + Environment.NewLine + "IP Address :" + GetIPAddress() + Environment.NewLine);
                        SWA.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public string GetIPAddress()
        {

            String ip = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];

            if (string.IsNullOrEmpty(ip))
            {
                ip = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
            }

            return ip;
        }
    }
}