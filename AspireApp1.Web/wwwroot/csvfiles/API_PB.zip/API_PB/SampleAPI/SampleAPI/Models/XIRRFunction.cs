﻿#region ChangeRequest
/// Created By  : Komal Patil
/// Created On  : 17-Feb-2017
/// Created for : For Calculate XIRR.
#endregion
using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Money = System.Double;
using Rate = System.Double;

namespace SampleAPI.Models
{
    public class XIRRFunction
    {
        public delegate Money XNPVFunc(IEnumerable<CashFlow> cfs, Rate r);
        public struct Pair<T, Z>
        {
            public Pair(T first, Z second)
            { First = first; Second = second; }
            public readonly T First; public readonly Z Second;
        }
        public class CashFlow
        {

            public CashFlow(Money amount, DateTime date) { Amount = amount; Date = date; }

            public readonly Money Amount;
            public readonly DateTime Date;
        }
        public struct AlgorithmResult<TKindOfResult, TValue>
        {
            public AlgorithmResult(TKindOfResult kind, TValue value)
            {
                Kind = kind;
                Value = value;
            }

            public readonly TKindOfResult Kind;
            public readonly TValue Value;
        }
        public enum ApproximateResultKind { ApproximateSolution, ExactSolution, NoSolutionWithinTolerance }

        public static class FinFunctions
        {
            internal static int MaxIteration = 100;
            internal static Rate Guess = 0.1;
            internal static Rate Tolerance = 0.000001;

            internal static Money CalculateXNPV(IEnumerable<CashFlow> cfs, Rate r)
            {
                if (r <= -1)
                    r = -0.99999999;

                //return ( from cf in cfs
                //        let startDate = cfs.OrderBy(cf1 => cf1.Date).First().Date
                //        select cf.Amount / (decimal) Math.Pow(1 + r, (cf.Date - startDate).Days / 365.0)).Sum(); 
                DateTime StartDate = DateTime.Now;
                foreach (CashFlow cf in cfs)
                {
                    StartDate = cf.Date; break;
                }
                Money Val = 0;
                foreach (CashFlow cf in cfs)
                {
                    Val += cf.Amount / (double)Math.Pow(1 + r, ((TimeSpan)(cf.Date - StartDate)).Days / 365.0);
                }
                return Val;
            }
            internal static Pair<Rate, Rate> FindBrackets(XNPVFunc func, IEnumerable<CashFlow> cfs, int maxIter, Rate bracketStep)
            {
                //const int maxIter = 100;
                //const Rate bracketStep = 0.5;
                const Rate guess = 0.1;

                Rate leftBracket = guess - bracketStep;
                Rate rightBracket = guess + bracketStep;
                int iter = 0;

                while (func(cfs, leftBracket) * func(cfs, rightBracket) > 0 && iter++ < maxIter)
                {
                    leftBracket -= bracketStep;
                    rightBracket += bracketStep;
                }

                if (iter >= maxIter)
                    return new Pair<double, double>(0, 0);

                return new Pair<Rate, Rate>(leftBracket, rightBracket);
            }
            internal static AlgorithmResult<ApproximateResultKind, Rate> Bisection(XNPVFunc func, IEnumerable<CashFlow> cfs, Rate r, Pair<Rate, Rate> brackets, Rate tol, int maxIters)
            {
                int iter = 1;

                Money f3 = 0;
                Rate x3 = 0;
                Rate x1 = brackets.First;
                Rate x2 = brackets.Second;

                do
                {
                    Money f1 = func(cfs, x1);
                    Money f2 = func(cfs, x2);

                    if (f1 == 0 && f2 == 0)
                        return new AlgorithmResult<ApproximateResultKind, Rate>(ApproximateResultKind.NoSolutionWithinTolerance, x1);

                    if (f1 * f2 > 0)
                        throw new ArgumentException("x1 x2 values don't bracket a root");

                    x3 = (x1 + x2) / 2;
                    f3 = func(cfs, x3);

                    if (f3 * f1 < 0)
                        x2 = x3;
                    else
                        x1 = x3;

                    iter++;

                } while (Math.Abs(x1 - x2) / 2 > tol && f3 != 0 && iter < maxIters);

                if (f3 == 0)
                    return new AlgorithmResult<ApproximateResultKind, Rate>(ApproximateResultKind.ExactSolution, x3);

                if (Math.Abs(x1 - x2) / 2 < tol)
                    return new AlgorithmResult<ApproximateResultKind, Rate>(ApproximateResultKind.ApproximateSolution, x3);

                if (iter > maxIters)
                    return new AlgorithmResult<ApproximateResultKind, Rate>(ApproximateResultKind.NoSolutionWithinTolerance, x3);

                throw new Exception("It should never get here");
            }

            public static AlgorithmResult<ApproximateResultKind, Rate> CalculateXIRR(IEnumerable<CashFlow> cfs, Rate tolerance, int maxIters, Rate r)
            {
                Pair<Rate, Rate> brackets = FindBrackets(CalculateXNPV, cfs, maxIters, r);

                if (brackets.First == brackets.Second)
                    return new AlgorithmResult<ApproximateResultKind, double>(ApproximateResultKind.NoSolutionWithinTolerance, brackets.First);

                return Bisection(CalculateXNPV, cfs, r, brackets, tolerance, maxIters);
            }
            public static AlgorithmResult<ApproximateResultKind, Rate> CalculateXIRR(IEnumerable<CashFlow> cfs)
            {
                return CalculateXIRR(cfs, Tolerance, MaxIteration, Guess);
            }
        }
    }
}