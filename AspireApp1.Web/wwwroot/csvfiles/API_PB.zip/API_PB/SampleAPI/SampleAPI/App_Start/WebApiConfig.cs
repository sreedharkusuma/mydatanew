﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Web.Routing;
namespace SampleAPI
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            HttpConfigurationExtensions.MapHttpAttributeRoutes(config);
            HttpRouteCollectionExtensions.MapHttpRoute(config.Routes, "Test", "api/{controller}/{action}/{PAN}", (object)new
            {
                PAN = RouteParameter.Optional
            });
            HttpRouteCollectionExtensions.MapHttpRoute(config.Routes, "Portfolio_Summary_Category_Wise_PB/Portfolio_Summary_Redeemed_Live_Units/Portfolio_Holdings/Portfolio_Summary_Live_Units/Portfolio_Detail_Live_Units/SIP_Summary/Account_Statement_Class_Allocation_Chart/Portfolio_Insight/STP_Report/Fixed_Maturity_Plan_Report", "api/{controller}/{action}/{PAN}/{On_Date}/{Type}", (object)new
            {
                PAN = RouteParameter.Optional
            });
            HttpRouteCollectionExtensions.MapHttpRoute(config.Routes, "Account_Statement_FolioWise", "api/Account_Statement_Foliowise/{PAN}/{PRODUCTCODE}/{Type}/{*FOLIONO}", (object)new
            {
                PAN = RouteParameter.Optional
            });
            HttpRouteCollectionExtensions.MapHttpRoute(config.Routes, "Account_Statement/Portfolio_Detail_With_Redemption/Portfolio_Redemption_Report/Dividend_Detail_Report/Dividend_Summary_Report/Gain_Loss_Detail_Report/Taxation_Summary_Report/Portfolio_Details/", "api/{controller}/{action}/{PAN}/{From_Date}/{On_Date}/{Type}", (object)new
            {
                PAN = RouteParameter.Optional
            });
            HttpRouteCollectionExtensions.MapHttpRoute(config.Routes, "getClient_Details/PortfolioInsight_ClientSectorAllocation/PortfolioInsight_ClientCompAllocation/PortfolioInsight_FundCatAllocation/PortfolioInsight_FundPortFolioBreakUp/PortfolioInsight_SchemePortFolioBreakUp/PortfolioInsight_ClientCAPAllocation/PortfolioInsight_ClientAssetAllocation/PortfolioInsight_ClientCashFlow/", "api/{controller}/{action}/{PAN}/{Type}", (object)new
            {
                PAN = RouteParameter.Optional
            });
            HttpRouteCollectionExtensions.MapHttpRoute(config.Routes, "Portfolio_Allocation", "api/{controller}/{action}/{PAN}/{InvestDate}/{Opt}/{TopRecords}/{Type}", (object)new
            {
                PAN = RouteParameter.Optional
            });
        }

        /*public static void Register(HttpConfiguration config)
        {
            // Web API configuration and services
            //routeTemplate: "api/{controller}/{id}",
            // Web API routes
            //[Route("api/Account_Statement/{PAN}/{From_Date}/{On_Date}/{Type}")]
            //[Route("api/Portfolio_Summary_Category_Wise/{PAN}/{On_Date}/{Type}")]
            //[Route("api/Portfolio_Holdings/{PAN}/{On_Date}/{Type}")]
            config.MapHttpAttributeRoutes();

            config.Routes.MapHttpRoute(
            name: "Test",
            routeTemplate: "api/{controller}/{action}/{PAN}",
            defaults: new { PAN = RouteParameter.Optional }
        );

            config.Routes.MapHttpRoute(
             name: "Portfolio_Summary_Category_Wise_PB/Portfolio_Summary_Redeemed_Live_Units/Portfolio_Holdings/Portfolio_Summary_Live_Units/Portfolio_Detail_Live_Units/SIP_Summary/Account_Statement_Class_Allocation_Chart/Portfolio_Insight/STP_Report/Fixed_Maturity_Plan_Report",
             routeTemplate: "api/{controller}/{action}/{PAN}/{On_Date}/{Type}",
             defaults: new { PAN = RouteParameter.Optional }
           );

            config.Routes.MapHttpRoute(
               name: "Account_Statement_FolioWise",
               routeTemplate: "api/Account_Statement_Foliowise/{PAN}/{PRODUCTCODE}/{Type}/{*FOLIONO}",
               defaults: new { PAN = RouteParameter.Optional }
           );
   
            config.Routes.MapHttpRoute(
               name: "Account_Statement/Portfolio_Detail_With_Redemption/Portfolio_Redemption_Report/Dividend_Detail_Report/Dividend_Summary_Report/Gain_Loss_Detail_Report/Taxation_Summary_Report/Portfolio_Details/",
               routeTemplate: "api/{controller}/{action}/{PAN}/{From_Date}/{On_Date}/{Type}",
               defaults: new { PAN = RouteParameter.Optional }
           );

            config.Routes.MapHttpRoute(
             name: "getClient_Details/PortfolioInsight_ClientSectorAllocation/PortfolioInsight_ClientCompAllocation/PortfolioInsight_FundCatAllocation/PortfolioInsight_FundPortFolioBreakUp/PortfolioInsight_SchemePortFolioBreakUp/PortfolioInsight_ClientCAPAllocation/PortfolioInsight_ClientAssetAllocation/PortfolioInsight_ClientCashFlow/",
             routeTemplate: "api/{controller}/{action}/{PAN}/{Type}",
             defaults: new { PAN = RouteParameter.Optional }
           );

            config.Routes.MapHttpRoute(
            name: "Portfolio_Allocation",
            routeTemplate: "api/{controller}/{action}/{PAN}/{InvestDate}/{Opt}/{TopRecords}/{Type}",
            defaults: new { PAN = RouteParameter.Optional }
          );

            //  config.Routes.MapHttpRoute(
            //  name: "Client_ELSS_Maturity_Report",
            //  routeTemplate: "api/{controller}/{action}/{PAN}/{On_Date}/{Opt}/{Type}",
            //  defaults: new { PAN = RouteParameter.Optional }
            //);

            //  config.Routes.MapHttpRoute(
            //  name: "Account_Statement_Foliowise",
            //  routeTemplate: "api/{controller}/{action}/{PAN}/{PRODUCTCODE}/{FOLIONO}/{Type}",
            //  defaults: new { PAN = RouteParameter.Optional }
            //);

            // config.Routes.MapHttpRoute(
            // name: "get_loginDetails",
            // routeTemplate: "api/{controller}/{action}/{Username}/{Password}/{Type}",
            // defaults: new { Username = RouteParameter.Optional }
            //);

        }*/
    }
}
