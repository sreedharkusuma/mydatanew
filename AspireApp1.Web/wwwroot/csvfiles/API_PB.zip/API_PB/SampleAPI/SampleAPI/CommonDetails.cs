using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Globalization;
/// <summary>
/// Summary description for CommonDetails
/// </summary>
public class CommonDetails
{
    public static void CreateErrorLog(string _MethodPageName, string _PageName, string _ExceptionMessage, string _ExceptionType, string _FilePath)
    {
        string JScript;
        string _FileName = string.Empty, _Dir = string.Empty, _IsFileExist = "N";
        //try
        //{
        if (_ExceptionMessage != "Thread was being aborted.")
        {
            _Dir = HttpContext.Current.Server.MapPath("~") + "\\Error\\";
            _FileName = _Dir + DateTime.Now.ToString(format: "dd-MM-yyyy") + ".txt";
            string[] _FilePaths = Directory.GetFiles(_Dir);
            foreach (string FLName in _FilePaths)
            {
                if (FLName.ToString() == _FileName.ToString())
                {
                    _IsFileExist = "Y";
                }
            }
            if (_IsFileExist == "N")
            {
                if (_ExceptionType != "System.Threading.ThreadAbortException")
                {
                    StreamWriter SW = File.CreateText(_FileName);
                    SW.WriteLine(_MethodPageName + Environment.NewLine + "Url : " + _PageName + Environment.NewLine + "Exception : " + _ExceptionMessage + Environment.NewLine + "Exception Type : " + _ExceptionType + Environment.NewLine + "Date : " + DateTime.Now.ToString() + Environment.NewLine + "IP Address : " + CommonDetails.GetIPAddress() +
                    Environment.NewLine + "------------------------------------------------------------------------------------------------------------------------------------------------------------------" + Environment.NewLine);
                    SW.Close();
                }
            }
            else
            {
                if (_ExceptionType != "System.Threading.ThreadAbortException")
                {
                    StreamWriter SWA = File.AppendText(_FileName);
                    //SWA.WriteLine(_MethodPageName + Environment.NewLine + "Url --- " + _PageName + Environment.NewLine + " Exception :--- " + _ExceptionMessage + Environment.NewLine + " Exception Type:---  " + _ExceptionType + Environment.NewLine + " Date : " + DateTime.Now.TimeOfDay.ToString() + "---" + DateTime.Now.Date.ToString() + Environment.NewLine + "IP Address :" + CommonDetails.GetIPAddress() + Environment.NewLine);
                    SWA.WriteLine(_MethodPageName + Environment.NewLine + "Url : " + _PageName + Environment.NewLine + "Exception : " + _ExceptionMessage + Environment.NewLine + "Exception Type : " + _ExceptionType + Environment.NewLine + "Date : " + DateTime.Now.ToString() + Environment.NewLine + "IP Address : " + CommonDetails.GetIPAddress() +
                    Environment.NewLine + "------------------------------------------------------------------------------------------------------------------------------------------------------------------" + Environment.NewLine);
                    SWA.Close();
                }
            }
            //System.Web.HttpContext.Current.Response.Write("<span id='Label1' style='height:16px;Z-INDEX: 102; LEFT: 25px; POSITION: absolute; TOP: 144px; color: #818181;font-family: Arial,Helvetica,sans-serif;font-size: 12px;text-align: left;'>Something went wrong, Please contact to administrator!</span>");
            Page _Page = HttpContext.Current.Handler as Page;
            
            string StrValue = _ExceptionMessage;
            if (!string.IsNullOrEmpty(StrValue))
            {
                //string[] InjectedChars = { "<", ">", @"\", "/*", "*/", "--", "/", "\r", "\n" };
                string[] InjectedChars = { "<", ">", @"\", "/*", "*/", "--", @"""", "/", "\r", "\n", "@", ".", "'" };
                foreach (string item in InjectedChars)
                {
                    StrValue = StrValue.Replace(item, string.Empty);
                }
            }

            if (_Page != null)
            {
                Page page = HttpContext.Current.CurrentHandler as Page;
                JScript = "<script language ='javascript'>bootbox.alert({ message: 'Unable to process this request. A handled exception just occured.<br>Exception:" + StrValue + "' });</script>";
                page.ClientScript.RegisterClientScriptBlock(page.GetType(), "SetAlert();return false;", JScript );
            }


        }
        //}
        //catch (Exception ex)
        //{
        //    ;
        //}
    }
    public static void CreateErrorLogIframe(string _MethodPageName, string _PageName, string _ExceptionMessage, string _ExceptionType, string _FilePath)
    {
        string _FileName = string.Empty, _Dir = string.Empty, _IsFileExist = "N";
        if (_ExceptionMessage != "Thread was being aborted.")
        {
            _Dir = HttpContext.Current.Server.MapPath("~") + "\\Error\\";
            _FileName = _Dir + "IIFL.txt";
            string[] _FilePaths = Directory.GetFiles(_Dir);
            foreach (string FLName in _FilePaths)
            {
                if (FLName.ToString() == _FileName.ToString())
                {
                    _IsFileExist = "Y";
                }
            }
            if (_IsFileExist == "N")
            {
                if (_ExceptionType != "System.Threading.ThreadAbortException")
                {
                    StreamWriter SW = File.CreateText(_FileName);
                    SW.WriteLine(_MethodPageName + Environment.NewLine + "Url : " + _PageName + Environment.NewLine + "Exception : " + _ExceptionMessage + Environment.NewLine + "Exception Type : " + _ExceptionType + Environment.NewLine + "Date : " + DateTime.Now.ToString() + Environment.NewLine + "IP Address : " + CommonDetails.GetIPAddress() +
                    Environment.NewLine + "------------------------------------------------------------------------------------------------------------------------------------------------------------------" + Environment.NewLine);
                    SW.Close();
                }
            }
            else
            {
                if (_ExceptionType != "System.Threading.ThreadAbortException")
                {
                    StreamWriter SWA = File.AppendText(_FileName);
                    SWA.WriteLine(_MethodPageName + Environment.NewLine + "Url : " + _PageName + Environment.NewLine + "Exception : " + _ExceptionMessage + Environment.NewLine + "Exception Type : " + _ExceptionType + Environment.NewLine + "Date : " + DateTime.Now.ToString() + Environment.NewLine + "IP Address : " + CommonDetails.GetIPAddress() +
                    Environment.NewLine + "------------------------------------------------------------------------------------------------------------------------------------------------------------------" + Environment.NewLine);
                    SWA.Close();
                }
            }
            Page _Page = HttpContext.Current.Handler as Page;
            if (_Page != null)
            {
                System.Web.HttpContext.Current.Response.Redirect(GetAppPath(_Page).TrimEnd('/') + "/" + "errorframe.aspx");
            }
        }
    }
    public static string GetIPAddress()
    {
        string hostName = Dns.GetHostName();
        IPHostEntry local = Dns.GetHostEntry(hostName);
        string ipAdd= local.AddressList[1].ToString() ;
        return ipAdd;
        //return HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
    }

    public static string GetAppPath(Page page)
    {
        string applicationPath = string.Empty;
        if (page.Request.Url != null)
            applicationPath = page.Request.Url.AbsoluteUri.Substring(
             0, page.Request.Url.AbsoluteUri.ToLower().IndexOf(
              page.Request.ApplicationPath.ToLower(),
               page.Request.Url.AbsoluteUri.ToLower().IndexOf(
              page.Request.Url.Authority.ToLower()) +
              page.Request.Url.Authority.Length) +
             page.Request.ApplicationPath.Length);
        return applicationPath;
    }

    public static string GetPassword(string TmpPass)
    {
        string ret = "";

        try
        {
            string Data = "";
            string Value = TmpPass;
            int DataLength = Value.Length;
            int Length = 8;
            for (int i = 0; i <= Value.Length - 1; i = i + 8)
            {
                try
                {
                    Data = Value.Substring(i, Length);
                    ret = ret + Data.Substring(Data.Length - 1);
                }
                catch (Exception)
                {
                    int remaining = DataLength - i;
                    break;
                }

            }
            return ret;
        }
        catch (Exception)
        {
            return ret;
        }

    }
}
