﻿using System;
using System.Collections.Specialized;
using System.Data;
using System.IO;
using System.Reflection;
using System.Web;
using System.Web.Http;
using System.Web.Script.Serialization;
using System.Xml;
using SampleAPI.Models;

namespace SampleAPI.Controllers
{
    public class MFBackController : ApiController
    {
        public class RequestObj
        {
            public string Token { get; set; }
        }
        private Methods MethodObj = new Methods();

        private RequestToken objReqToken = new RequestToken();

        private EncryptDecrypt ObjEncDecrypt = new EncryptDecrypt();

        private TransMethod MethodTrObj = new TransMethod();

        private Signature objSign = new Signature();

        private DataSet dsTrans = null;

        private DataSet dsFinal = null;

        private string Value = "";

        private string strToken = "";

        private string decryptToken = "";

        private DataTable dt = new DataTable();

        private NameValueCollection nv = new NameValueCollection();

        private string schemecode;

        private string s_name;

        private string Folio_Number;

        private string Sch_Folio_Unitbal;

        private string currentvalue;

        private string costvalue;

        private string DivReINVST_AmountVal;

        private string dividend;

        private string Notional_ProfitLoss;

        private string WedAvgDays;

        private string AbsoluteReturn;

        private string simpleAnnulisedResults;

        private string XIIRCALC;

        private string CAGR;

        private string NetGain;

        private string Profit_Booked;

        private string className;

        private string NAV;

        private string GroupTotalVal;

        private string GrandTotalVal;

        private string AnnulResults;

        private string trxn_type_Nameval;

        private string Trxn_Dateval;

        private string Priceval;

        private string Unitsval;

        private string ToDate;

        private string _ID;

        private double Amountval;

        private double PortFolio_Unitbalval;

        private double Present_Valueval;

        private double Dividend_Amountval;

        private double NotionalPLval;

        private double Profit_Bookedval;

        private double NetGainval;

        private double Ageval;

        private double Absolute_Returnsval;

        private double DividendPayoutval;

        private double Sim_Ann_Returnsval;

        private double CAGRval;

        protected string SqlCmd;

        protected string SqlCon;
        [HttpPost]
        public void Portfolio_Summary_Category_Wise_PB(RequestToken reqObj)
        {
            try
            {
                objSign = new JavaScriptSerializer().Deserialize<Signature>(objReqToken.getParam(reqObj.Token));
                nv.Add("@PAN", objSign.PAN);
                nv.Add("@OnDate", objSign.On_Date);
                dsTrans = MethodObj.GetDataSet("[API_Get_PortFolioSummary_Liveunits_NEW_PB]", nv);
                dsFinal = MethodTrObj.Portfolio_Summary_Category_Wise_PB(dsTrans, objSign.On_Date, "C");
                dsFinal.Tables.Remove("Table2");
                if (objSign.Type.ToLower() == "json")
                {
                    Value = Newtonsoft.Json.JsonConvert.SerializeObject(dsTrans, Newtonsoft.Json.Formatting.Indented);
                        //(dsTrans, Formatting.Indented);
                }
                else if (objSign.Type.ToLower() == "xml")
                {
                    Value = dsFinal.GetXml();
                }
            }
            catch (Exception ex)
            {
                HttpContext current = HttpContext.Current;
                CommonDetails.CreateErrorLog(MethodBase.GetCurrentMethod().DeclaringType.ToString() + " Method Name : " + MethodBase.GetCurrentMethod().ToString(), current.Request.Url.ToString(), ex.Message.ToString(), ex.GetType().ToString(), "");
                throw ex;
            }
            HttpContext.Current.Response.Write(ObjEncDecrypt.EncryptTextBy_AES(Value + "|"));
            HttpContext.Current.Response.End();
        }
        [HttpPost]
        public void Portfolio_Summary_Redeemed_Live_Units(RequestToken reqObj)
        {
            try
            {
                objSign = new JavaScriptSerializer().Deserialize<Signature>(objReqToken.getParam(reqObj.Token));
                nv.Add("@pan", objSign.PAN);
                nv.Add("@OnDate", objSign.On_Date);
                dsTrans = MethodObj.GetDataSet("[API_Get_PortFolioSummary_RdmUnits]", nv);
                dsFinal = MethodTrObj.Portfolio_Summary_Live_Units(dsTrans);
                dsFinal.Tables.Remove("Table");
                if (objSign.Type.ToLower() == "json")
                {
                    Value = Newtonsoft.Json.JsonConvert.SerializeObject(dsTrans, Newtonsoft.Json.Formatting.Indented);
                }
                else if (objSign.Type.ToLower() == "xml")
                {
                    Value = dsFinal.GetXml();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            HttpContext.Current.Response.Write(ObjEncDecrypt.EncryptTextBy_AES(Value + "|"));
            HttpContext.Current.Response.End();
        }
        [HttpPost]
        public void Account_Statement_Foliowise(RequestToken reqObj)
        {
            try
            {
                objSign = new JavaScriptSerializer().Deserialize<Signature>(objReqToken.getParam(reqObj.Token));
                nv.Add("@pan", objSign.PAN);
                nv.Add("@schemecode", objSign.PRODUCTCODE);
                nv.Add("@Folio_No", objSign.FOLIONO);
                dsTrans = MethodObj.GetDataSet("API_Account_Statement_FolioWise_client", nv);
                if (objSign.Type.ToLower() == "json")
                {
                    Value = Newtonsoft.Json.JsonConvert.SerializeObject(dsTrans, Newtonsoft.Json.Formatting.Indented);
                }
                else if (objSign.Type.ToLower() == "xml")
                {
                    Value = dsTrans.GetXml();
                    DataSet dataSet = new DataSet();
                    TextReader input = new StringReader(Value);
                    XmlReader reader = new XmlTextReader(input);
                    dataSet.ReadXml(reader);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            HttpContext.Current.Response.Write(ObjEncDecrypt.EncryptTextBy_AES(Value + "|"));
            HttpContext.Current.Response.End();
        }

        [HttpPost]
        public void Account_Statement(RequestToken reqObj)
        {
            try
            {
                objSign = new JavaScriptSerializer().Deserialize<Signature>(objReqToken.getParam(reqObj.Token));
                nv.Add("@PAN", objSign.PAN);
                nv.Add("@FromDate", objSign.From_Date);
                nv.Add("@ToDate", objSign.On_Date);
                dsTrans = MethodObj.GetDataSet("[API_ACCOUNT_STATEMENT_CLIENTWISE_CLIENT_NEW]", nv);
                if (dsTrans.Tables[2].Rows.Count <= 0)
                {
                    DataTable dataTable = new DataTable("Table3");
                    dataTable.Columns.Add("DataValues", typeof(string));
                    dataTable.Rows.Add("You do not have any investments as yet.");
                    dsTrans.Tables.Add(dataTable);
                    dsTrans.Tables.Remove("Table2");
                }
                if (objSign.Type.ToLower() == "json")
                {
                    Value = Newtonsoft.Json.JsonConvert.SerializeObject(dsTrans, Newtonsoft.Json.Formatting.Indented);
                }
                else if (objSign.Type.ToLower() == "xml")
                {
                    Value = dsTrans.GetXml();
                    DataSet dataSet = new DataSet();
                    TextReader input = new StringReader(Value);
                    XmlReader reader = new XmlTextReader(input);
                    dataSet.ReadXml(reader);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            HttpContext.Current.Response.Write(ObjEncDecrypt.EncryptTextBy_AES(Value + "|"));
            HttpContext.Current.Response.End();
        }

        [HttpPost]
        public void Portfolio_Detail_With_Redemption(RequestToken reqObj)
        {
            try
            {
                objSign = new JavaScriptSerializer().Deserialize<Signature>(objReqToken.getParam(reqObj.Token));
                _ID = "2";
                nv.Add("@pan", objSign.PAN);
                nv.Add("@FromDate", objSign.From_Date);
                nv.Add("@OnDate", objSign.On_Date);
                dsTrans = MethodObj.GetDataSet("[API_Get_PortFolioDetails_Client]", nv);
                dsFinal = MethodTrObj.Portfolio_Detail_With_Redemption(dsTrans);
                dsFinal.Tables.Remove("Table");
                if (objSign.Type.ToLower() == "json")
                {
                    Value = Newtonsoft.Json.JsonConvert.SerializeObject(dsTrans, Newtonsoft.Json.Formatting.Indented);
                }
                else if (objSign.Type.ToLower() == "xml")
                {
                    Value = dsFinal.GetXml();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            HttpContext.Current.Response.Write(ObjEncDecrypt.EncryptTextBy_AES(Value + "|"));
            HttpContext.Current.Response.End();
        }

        [HttpPost]
        public void Gain_Loss_Detail_Report(RequestToken reqObj)
        {
            try
            {
                objSign = new JavaScriptSerializer().Deserialize<Signature>(objReqToken.getParam(reqObj.Token));
                nv.Add("@pan", objSign.PAN);
                nv.Add("@FromDate", objSign.From_Date);
                nv.Add("@ToDate", objSign.On_Date);
                dsTrans = MethodObj.GetDataSet("[API_Get_CapitalGainLossReport]", nv);
                dsFinal = MethodTrObj.GainLossReport(dsTrans);
                dsFinal.Tables.Remove("Table");
                if (objSign.Type.ToLower() == "json")
                {
                    Value = Newtonsoft.Json.JsonConvert.SerializeObject(dsTrans, Newtonsoft.Json.Formatting.Indented);
                }
                else if (objSign.Type.ToLower() == "xml")
                {
                    Value = dsFinal.GetXml();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            HttpContext.Current.Response.Write(ObjEncDecrypt.EncryptTextBy_AES(Value + "|"));
            HttpContext.Current.Response.End();
        }

        [HttpPost]
        public void Taxation_Summary_Report(RequestToken reqObj)
        {
            try
            {
                objSign = new JavaScriptSerializer().Deserialize<Signature>(objReqToken.getParam(reqObj.Token));
                nv.Add("@pan", objSign.PAN);
                nv.Add("@FromDate", objSign.From_Date);
                nv.Add("@ToDate", objSign.On_Date);
                dsTrans = MethodObj.GetDataSet("[API_Get_CapitalGainLossSummary_Client]", nv);
                dsFinal = MethodTrObj.Taxation_Summary_Report(dsTrans);
                dsFinal.Tables.Remove("Table");
                if (objSign.Type.ToLower() == "json")
                {
                    Value = Newtonsoft.Json.JsonConvert.SerializeObject(dsTrans, Newtonsoft.Json.Formatting.Indented);
                }
                else if (objSign.Type.ToLower() == "xml")
                {
                    Value = dsFinal.GetXml();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            HttpContext.Current.Response.Write(ObjEncDecrypt.EncryptTextBy_AES(Value + "|"));
            HttpContext.Current.Response.End();
        }

        [HttpPost]
        public void Portfolio_Summary_Live_Units(RequestToken reqObj)
        {
            try
            {
                objSign = new JavaScriptSerializer().Deserialize<Signature>(objReqToken.getParam(reqObj.Token));
                _ID = "";
                nv.Add("@pan", objSign.PAN);
                nv.Add("@OnDate", objSign.On_Date);
                nv.Add("@OrderBy", "");
                ToDate = objSign.On_Date;
                dsTrans = MethodObj.GetDataSet("[API_Get_PortFolioSummary_Liveunits]", nv);
                dsFinal = MethodTrObj.Portfolio_Summary_Live_Units(dsTrans);
                dsFinal.Tables.Remove("Table");
                if (objSign.Type.ToLower() == "json")
                {
                    Value = Newtonsoft.Json.JsonConvert.SerializeObject(dsTrans, Newtonsoft.Json.Formatting.Indented);
                }
                else if (objSign.Type.ToLower() == "xml")
                {
                    Value = dsFinal.GetXml();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            HttpContext.Current.Response.Write(ObjEncDecrypt.EncryptTextBy_AES(Value + "|"));
            HttpContext.Current.Response.End();
        }

        [HttpPost]
        public void Portfolio_Detail_Live_Units(RequestToken reqObj)
        {
            try
            {
                objSign = new JavaScriptSerializer().Deserialize<Signature>(objReqToken.getParam(reqObj.Token));
                _ID = "2";
                nv.Add("@pan", objSign.PAN);
                nv.Add("@OnDate", objSign.On_Date);
                dsTrans = MethodObj.GetDataSet("[API_Get_PortFolioDetailsV]", nv);
                dsFinal = MethodTrObj.Portfolio_Detail_Live_Units(dsTrans);
                dsFinal.Tables.Remove("Table");
                if (objSign.Type.ToLower() == "json")
                {
                    Value = Newtonsoft.Json.JsonConvert.SerializeObject(dsTrans, Newtonsoft.Json.Formatting.Indented);
                }
                else if (objSign.Type.ToLower() == "xml")
                {
                    Value = dsFinal.GetXml();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            HttpContext.Current.Response.Write(ObjEncDecrypt.EncryptTextBy_AES(Value + "|"));
            HttpContext.Current.Response.End();
        }

        [HttpPost]
        public void Dividend_Detail_Report(RequestToken reqObj)
        {
            objSign = new JavaScriptSerializer().Deserialize<Signature>(objReqToken.getParam(reqObj.Token));
            try
            {
                nv.Add("@pan", objSign.PAN);
                nv.Add("@FromDate", objSign.From_Date);
                nv.Add("@ToDate", objSign.On_Date);
                dsTrans = MethodObj.GetDataSet("[API_Get_DividendRpt]", nv);
                dsFinal = MethodTrObj.Dividend_Detail_Report(dsTrans);
                dsFinal.Tables.Remove("Table");
                if (objSign.Type.ToLower() == "json")
                {
                    Value = Newtonsoft.Json.JsonConvert.SerializeObject(dsTrans, Newtonsoft.Json.Formatting.Indented);
                }
                else if (objSign.Type.ToLower() == "xml")
                {
                    Value = dsFinal.GetXml();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            HttpContext.Current.Response.Write(ObjEncDecrypt.EncryptTextBy_AES(Value + "|"));
            HttpContext.Current.Response.End();
        }

        [HttpPost]
        public void Portfolio_Holdings(string PAN, string On_Date, string Type)
        {
            nv.Add("@PAN", PAN);
            nv.Add("@OnDate", On_Date);
            dsTrans = MethodObj.GetDataSet("API_Portfolio_Summary_Holding", nv);
            dsFinal = MethodTrObj.Portfolio_Summary_Holding(dsTrans);
            dsFinal.Tables.Remove("Table2");
            if (Type.ToLower() == "json")
            {
                Value = Newtonsoft.Json.JsonConvert.SerializeObject(dsTrans, Newtonsoft.Json.Formatting.Indented);
            }
            else if (Type.ToLower() == "xml")
            {
                Value = dsFinal.GetXml();
                DataSet dataSet = new DataSet();
                TextReader input = new StringReader(Value);
                XmlReader reader = new XmlTextReader(input);
                dataSet.ReadXml(reader);
            }
            HttpContext.Current.Response.Write(Value);
            HttpContext.Current.Response.End();
        }

        [HttpPost]
        public void Portfolio_Summary_Category_Wise(string PAN, string On_Date, string Type)
        {
            try
            {
                nv.Add("@PAN", PAN);
                nv.Add("@OnDate", On_Date);
                dsTrans = MethodObj.GetDataSet("[API_Get_PortFolioSummary_Liveunits_NEW]", nv);
                dsFinal = MethodTrObj.Portfolio_Summary_Category_Wise(dsTrans, On_Date, "C");
                dsFinal.Tables.Remove("Table2");
                if (Type.ToLower() == "json")
                {
                    Value = Newtonsoft.Json.JsonConvert.SerializeObject(dsTrans, Newtonsoft.Json.Formatting.Indented);
                }
                else if (Type.ToLower() == "xml")
                {
                    Value = dsTrans.GetXml();
                    DataSet dataSet = new DataSet();
                    TextReader input = new StringReader(Value);
                    XmlReader reader = new XmlTextReader(input);
                    dataSet.ReadXml(reader);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            HttpContext.Current.Response.Write(Value);
            HttpContext.Current.Response.End();
        }

        [HttpPost]
        public void getClient_Details(string PAN, string Type)
        {
            try
            {
                nv.Add("@pan", PAN);
                dsTrans = MethodObj.GetDataSet("API_Get_clientDetails", nv);
                if (dsTrans.Tables[0].Rows.Count > 0)
                {
                    if (Type.ToLower() == "json")
                    {
                        Value = Newtonsoft.Json.JsonConvert.SerializeObject(dsTrans, Newtonsoft.Json.Formatting.Indented);
                    }
                    else if (Type.ToLower() == "xml")
                    {
                        Value = dsTrans.GetXml();
                        DataSet dataSet = new DataSet();
                        TextReader input = new StringReader(Value);
                        XmlReader reader = new XmlTextReader(input);
                        dataSet.ReadXml(reader);
                    }
                }
                else
                {
                    Value = "{\"Table\" :[ {\"Result\":\"Invalid\"} ]}";
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            HttpContext.Current.Response.Write(Value);
            HttpContext.Current.Response.End();
        }

        [HttpPost]
        public void Portfolio_Redemption_Report(string PAN, string From_Date, string On_Date, string Type)
        {
            nv.Add("@pan", PAN);
            nv.Add("@FromDate", From_Date);
            nv.Add("@ToDate", On_Date);
            dsTrans = MethodObj.GetDataSet("[API_Get_RedemptionReport]", nv);
            dsFinal = MethodTrObj.Portfolio_Redemption_Report(dsTrans);
            dsFinal.Tables.Remove("Table");
            if (Type.ToLower() == "json")
            {
                Value = Newtonsoft.Json.JsonConvert.SerializeObject(dsTrans, Newtonsoft.Json.Formatting.Indented);
            }
            else if (Type.ToLower() == "xml")
            {
                Value = dsFinal.GetXml();
            }
            HttpContext.Current.Response.Write(Value);
            HttpContext.Current.Response.End();
        }

        [HttpPost]
        public void Dividend_Summary_Report(string PAN, string From_Date, string On_Date, string Type)
        {
            nv.Add("@pan", PAN);
            nv.Add("@FromDate", From_Date);
            nv.Add("@ToDate", On_Date);
            dsTrans = MethodObj.GetDataSet("[API_Get_DividendRpt]", nv);
            dsFinal = MethodTrObj.Dividend_Summary_Report(dsTrans);
            dsFinal.Tables.Remove("Table");
            if (Type.ToLower() == "json")
            {
                Value = Newtonsoft.Json.JsonConvert.SerializeObject(dsTrans, Newtonsoft.Json.Formatting.Indented);
            }
            else if (Type.ToLower() == "xml")
            {
                Value = dsFinal.GetXml();
            }
            HttpContext.Current.Response.Write(Value);
            HttpContext.Current.Response.End();
        }

        [HttpPost]
        public void SIP_Summary(RequestToken reqObj)
        {
            objSign = new JavaScriptSerializer().Deserialize<Signature>(objReqToken.getParam(reqObj.Token));
            nv.Add("@pan", objSign.PAN);
            nv.Add("@OnDate", objSign.On_Date);
            dsTrans = MethodObj.GetDataSet("[API_Get_ClientSIPSummary]", nv);
            dsFinal = MethodTrObj.SIP_Summary(dsTrans);
            dsFinal.Tables.Remove("Table");
            if (objSign.Type.ToLower() == "json")
            {
                Value = Newtonsoft.Json.JsonConvert.SerializeObject(dsTrans, Newtonsoft.Json.Formatting.Indented);
            }
            else if (objSign.Type.ToLower() == "xml")
            {
                Value = dsFinal.GetXml();
            }
            HttpContext.Current.Response.Write(ObjEncDecrypt.EncryptTextBy_AES(Value + "|"));
            HttpContext.Current.Response.End();
        }

        [HttpPost]
        public void Account_Statement_Class_Allocation_Chart(string PAN, string On_Date, string Type)
        {
            nv.Add("@pan", PAN);
            nv.Add("@ToDate", On_Date);
            dsTrans = MethodObj.GetDataSet("[API_Account_Statement_Class_Allocation_Chart]", nv);
            DataTable dataTable = dsTrans.Tables["Table"];
            DataTable dataTable2 = new DataTable();
            dataTable2 = dataTable.Copy();
            dataTable2.TableName = "Table3";
            dsTrans.Tables.Add(dataTable2);
            dsTrans.Tables.Remove("Table");
            if (Type.ToLower() == "json")
            {
                Value = Newtonsoft.Json.JsonConvert.SerializeObject(dsTrans, Newtonsoft.Json.Formatting.Indented);
            }
            else if (Type.ToLower() == "xml")
            {
                Value = dsTrans.GetXml();
            }
            HttpContext.Current.Response.Write(Value);
            HttpContext.Current.Response.End();
        }

        [HttpPost]
        public void Portfolio_Insight(string PAN, string On_Date, string Type)
        {
            nv.Add("@pan", PAN);
            nv.Add("@OnDate", On_Date);
            dsTrans = MethodObj.GetDataSet("[API_Get_ClientSIPSummary]", nv);
            dsFinal = MethodTrObj.Portfolio_Insight(dsTrans);
            dsFinal.Tables.Remove("Table");
            if (Type.ToLower() == "json")
            {
                Value = Newtonsoft.Json.JsonConvert.SerializeObject(dsTrans, Newtonsoft.Json.Formatting.Indented);
            }
            else if (Type.ToLower() == "xml")
            {
                Value = dsFinal.GetXml();
            }
            HttpContext.Current.Response.Write(Value);
            HttpContext.Current.Response.End();
        }

        [HttpPost]
        public void PortfolioInsight_ClientSectorAllocation(string PAN, string Type)
        {
            nv.Add("@pan", PAN);
            dsTrans = MethodObj.GetDataSet("[API_Get_ClientSectorAllocation]", nv);
            DataTable dataTable = dsTrans.Tables["Table"];
            DataTable dataTable2 = new DataTable();
            dataTable2 = dataTable.Copy();
            dataTable2.TableName = "Table3";
            dsTrans.Tables.Add(dataTable2);
            dsTrans.Tables.Remove("Table");
            if (Type.ToLower() == "json")
            {
                Value = Newtonsoft.Json.JsonConvert.SerializeObject(dsTrans, Newtonsoft.Json.Formatting.Indented);
            }
            else if (Type.ToLower() == "xml")
            {
                Value = dsTrans.GetXml();
            }
            HttpContext.Current.Response.Write(Value);
            HttpContext.Current.Response.End();
        }

        [HttpPost]
        public void PortfolioInsight_ClientCompAllocation(string PAN, string Type)
        {
            nv.Add("@pan", PAN);
            dsTrans = MethodObj.GetDataSet("[API_Get_ClientCompAllocation]", nv);
            DataTable dataTable = dsTrans.Tables["Table"];
            DataTable dataTable2 = new DataTable();
            dataTable2 = dataTable.Copy();
            dataTable2.TableName = "Table3";
            dsTrans.Tables.Add(dataTable2);
            dsTrans.Tables.Remove("Table");
            if (Type.ToLower() == "json")
            {
                Value = Newtonsoft.Json.JsonConvert.SerializeObject(dsTrans, Newtonsoft.Json.Formatting.Indented);
            }
            else if (Type.ToLower() == "xml")
            {
                Value = dsTrans.GetXml();
            }
            HttpContext.Current.Response.Write(Value);
            HttpContext.Current.Response.End();
        }

        [HttpPost]
        public void PortfolioInsight_FundCatAllocation(string PAN, string Type)
        {
            nv.Add("@pan", PAN);
            dsTrans = MethodObj.GetDataSet("[API_Get_FundCatAllocation]", nv);
            DataTable dataTable = dsTrans.Tables["Table"];
            DataTable dataTable2 = new DataTable();
            dataTable2 = dataTable.Copy();
            dataTable2.TableName = "Table3";
            dsTrans.Tables.Add(dataTable2);
            dsTrans.Tables.Remove("Table");
            if (Type.ToLower() == "json")
            {
                Value = Newtonsoft.Json.JsonConvert.SerializeObject(dsTrans, Newtonsoft.Json.Formatting.Indented);
            }
            else if (Type.ToLower() == "xml")
            {
                Value = dsTrans.GetXml();
            }
            HttpContext.Current.Response.Write(Value);
            HttpContext.Current.Response.End();
        }

        [HttpPost]
        public void PortfolioInsight_FundPortFolioBreakUp(string PAN, string Type)
        {
            nv.Add("@pan", PAN);
            dsTrans = MethodObj.GetDataSet("[API_Get_FundPortFolioBreakUp]", nv);
            DataTable dataTable = dsTrans.Tables["Table"];
            DataTable dataTable2 = new DataTable();
            dataTable2 = dataTable.Copy();
            dataTable2.TableName = "Table3";
            dsTrans.Tables.Add(dataTable2);
            dsTrans.Tables.Remove("Table");
            if (Type.ToLower() == "json")
            {
                Value = Newtonsoft.Json.JsonConvert.SerializeObject(dsTrans, Newtonsoft.Json.Formatting.Indented);
            }
            else if (Type.ToLower() == "xml")
            {
                Value = dsTrans.GetXml();
            }
            HttpContext.Current.Response.Write(Value);
            HttpContext.Current.Response.End();
        }

        [HttpPost]
        public void PortfolioInsight_SchemePortFolioBreakUp(string PAN, string Type)
        {
            nv.Add("@pan", PAN);
            dsTrans = MethodObj.GetDataSet("[API_Get_SchemePortFolioBreakUp]", nv);
            DataTable dataTable = dsTrans.Tables["Table"];
            DataTable dataTable2 = new DataTable();
            dataTable2 = dataTable.Copy();
            dataTable2.TableName = "Table3";
            dsTrans.Tables.Add(dataTable2);
            dsTrans.Tables.Remove("Table");
            if (Type.ToLower() == "json")
            {
                Value = Newtonsoft.Json.JsonConvert.SerializeObject(dsTrans, Newtonsoft.Json.Formatting.Indented);
            }
            else if (Type.ToLower() == "xml")
            {
                Value = dsTrans.GetXml();
            }
            HttpContext.Current.Response.Write(Value);
            HttpContext.Current.Response.End();
        }

        [HttpPost]
        public void PortfolioInsight_ClientCAPAllocation(string PAN, string Type)
        {
            nv.Add("@pan", PAN);
            dsTrans = MethodObj.GetDataSet("[API_Get_ClientCAPAllocations]", nv);
            DataTable dataTable = dsTrans.Tables["Table"];
            DataTable dataTable2 = new DataTable();
            dataTable2 = dataTable.Copy();
            dataTable2.TableName = "Table3";
            dsTrans.Tables.Add(dataTable2);
            dsTrans.Tables.Remove("Table");
            if (Type.ToLower() == "json")
            {
                Value = Newtonsoft.Json.JsonConvert.SerializeObject(dsTrans, Newtonsoft.Json.Formatting.Indented);
            }
            else if (Type.ToLower() == "xml")
            {
                Value = dsTrans.GetXml();
            }
            HttpContext.Current.Response.Write(Value);
            HttpContext.Current.Response.End();
        }

        [HttpPost]
        public void PortfolioInsight_ClientAssetAllocation(string PAN, string Type)
        {
            nv.Add("@pan", PAN);
            dsTrans = MethodObj.GetDataSet("[API_Get_ClientAssetAllocations]", nv);
            DataTable dataTable = dsTrans.Tables["Table"];
            DataTable dataTable2 = new DataTable();
            dataTable2 = dataTable.Copy();
            dataTable2.TableName = "Table3";
            dsTrans.Tables.Add(dataTable2);
            dsTrans.Tables.Remove("Table");
            if (Type.ToLower() == "json")
            {
                Value = Newtonsoft.Json.JsonConvert.SerializeObject(dsTrans, Newtonsoft.Json.Formatting.Indented);
            }
            else if (Type.ToLower() == "xml")
            {
                Value = dsTrans.GetXml();
            }
            HttpContext.Current.Response.Write(Value);
            HttpContext.Current.Response.End();
        }

        [HttpPost]
        public void PortfolioInsight_ClientCashFlow(string PAN, string Type)
        {
            nv.Add("@pan", PAN);
            dsTrans = MethodObj.GetDataSet("[API_Get_ClientCashFlow]", nv);
            DataTable dataTable = dsTrans.Tables["Table"];
            DataTable dataTable2 = new DataTable();
            dataTable2 = dataTable.Copy();
            dataTable2.TableName = "Table3";
            dsTrans.Tables.Add(dataTable2);
            dsTrans.Tables.Remove("Table");
            if (Type.ToLower() == "json")
            {
                Value = Newtonsoft.Json.JsonConvert.SerializeObject(dsTrans, Newtonsoft.Json.Formatting.Indented);
            }
            else if (Type.ToLower() == "xml")
            {
                Value = dsTrans.GetXml();
            }
            HttpContext.Current.Response.Write(Value);
            HttpContext.Current.Response.End();
        }

        [HttpPost]
        public void Portfolio_Details(string PAN, string From_Date, string On_Date, string Type)
        {
            nv.Add("@pan", PAN);
            dsFinal = MethodObj.GetDataSet("[API_Get_ClientAssetAllocation]", nv);
            DataTable table = MethodTrObj.get_Get_ClientAllocation("API_Get_ClientCAPAllocation", PAN);
            DataTable table2 = MethodTrObj.get_Get_Allocation("API_Account_Statement_Class_Allocation", PAN, From_Date, On_Date);
            DataTable table3 = MethodTrObj.get_Get_Allocation("API_Account_Statement_FundWise", PAN, From_Date, On_Date);
            dsFinal.Tables.Add(table);
            dsFinal.Tables.Add(table2);
            dsFinal.Tables.Add(table3);
            if (Type.ToLower() == "json")
            {
                Value = Newtonsoft.Json.JsonConvert.SerializeObject(dsTrans, Newtonsoft.Json.Formatting.Indented);
            }
            else if (Type.ToLower() == "xml")
            {
                Value = dsFinal.GetXml();
            }
            HttpContext.Current.Response.Write(Value);
            HttpContext.Current.Response.End();
        }

        [HttpPost]
        public void STP_Report(string PAN, string On_Date, string Type)
        {
            nv.Add("@pan", PAN);
            nv.Add("@OnDate", On_Date);
            dsTrans = MethodObj.GetDataSet("[API_Get_STPDetails]", nv);
            dsFinal = MethodTrObj.STP_Report(dsTrans);
            dsFinal.Tables.Remove("Table");
            if (Type.ToLower() == "json")
            {
                Value = Newtonsoft.Json.JsonConvert.SerializeObject(dsTrans, Newtonsoft.Json.Formatting.Indented);
            }
            else if (Type.ToLower() == "xml")
            {
                Value = dsFinal.GetXml();
            }
            HttpContext.Current.Response.Write(Value);
            HttpContext.Current.Response.End();
        }

        [HttpPost]
        public void Fixed_Maturity_Plan_Report(string PAN, string On_Date, string Type)
        {
            nv.Add("@pan", PAN);
            nv.Add("@OnDate", On_Date);
            dsTrans = MethodObj.GetDataSet("[API_Get_FMPDetails]", nv);
            dsFinal = MethodTrObj.Fixed_Maturity_Plan_Report(dsTrans);
            dsFinal.Tables.Remove("Table");
            if (Type.ToLower() == "json")
            {
                Value = Newtonsoft.Json.JsonConvert.SerializeObject(dsTrans, Newtonsoft.Json.Formatting.Indented);
            }
            else if (Type.ToLower() == "xml")
            {
                Value = dsFinal.GetXml();
            }
            HttpContext.Current.Response.Write(Value);
            HttpContext.Current.Response.End();
        }

        [HttpPost]
        public void Portfolio_Allocation(string PAN, string InvestDate, string Opt, string TopRecords, string Type)
        {
            if (Opt.ToUpper().Trim() == "AW" || Opt.ToUpper().Trim() == "CW" || Opt.ToUpper().Trim() == "MCAP" || Opt.ToUpper().Trim() == "AMC" || Opt.ToUpper().Trim() == "SCW")
            {
                nv.Add("@pan", PAN);
                nv.Add("@Opt", Opt);
                dsTrans = MethodObj.GetDataSet("[API_Allocations]", nv);
                DataTable dataTable = dsTrans.Tables["Table"];
                DataTable dataTable2 = new DataTable();
                dataTable2 = dataTable.Copy();
                dataTable2.TableName = "Table3";
                dsTrans.Tables.Add(dataTable2);
                dsTrans.Tables.Remove("Table");
            }
            else if (Opt.ToUpper().Trim() == "CMP")
            {
                nv.Add("@pan", PAN);
                nv.Add("@InvDate", InvestDate);
                nv.Add("@Top", TopRecords);
                dsTrans = MethodObj.GetDataSet("[API_Allocation_CompanyWise]", nv);
                DataTable dataTable = dsTrans.Tables["Table"];
                DataTable dataTable2 = new DataTable();
                dataTable2 = dataTable.Copy();
                dataTable2.TableName = "Table3";
                dsTrans.Tables.Add(dataTable2);
                dsTrans.Tables.Remove("Table");
            }
            else if (Opt.ToUpper().Trim() == "SW")
            {
                nv.Add("@pan", PAN);
                nv.Add("@InvDate", InvestDate);
                nv.Add("@Top", TopRecords);
                dsTrans = MethodObj.GetDataSet("[API_Allocation_SectorWise]", nv);
                DataTable dataTable = dsTrans.Tables["Table"];
                DataTable dataTable2 = new DataTable();
                dataTable2 = dataTable.Copy();
                dataTable2.TableName = "Table3";
                dsTrans.Tables.Add(dataTable2);
                dsTrans.Tables.Remove("Table");
            }
            if (Type.ToLower() == "json")
            {
                Value = Newtonsoft.Json.JsonConvert.SerializeObject(dsTrans, Newtonsoft.Json.Formatting.Indented);
            }
            else if (Type.ToLower() == "xml")
            {
                Value = dsTrans.GetXml();
            }
            HttpContext.Current.Response.Write(Value);
            HttpContext.Current.Response.End();
        }

        [HttpPost]
        [Route("api/Transaction_Details/{FromDate}/{ToDate}/{AMC_Code}/{Scheme_Code}/{Trxn_Type}/{SubTrxn_Type}/{Broker_Code}/{Branch_Code}/{Employee_Code}/{Agent_Code}/{Client_Code}/{Folio_Number}/{Cheque_No}/{App_No}/{Tbl}/{UserID}/{Type}")]
        public void Transaction_Details(string FromDate, string ToDate, string AMC_Code, string Scheme_Code, string Trxn_Type, string SubTrxn_Type, string Broker_Code, string Branch_Code, string Employee_Code, string Agent_Code, string Client_Code, string Folio_Number, string Cheque_No, string App_No, string Tbl, string UserID, string Type)
        {
            nv.Add("@FromDate", FromDate);
            nv.Add("@ToDate", ToDate);
            nv.Add("@AMC_Code", AMC_Code);
            nv.Add("@Scheme_Code", Scheme_Code);
            nv.Add("@Trxn_Type", Trxn_Type);
            nv.Add("@SubTrxn_Type", SubTrxn_Type);
            nv.Add("@Broker_Code", Broker_Code);
            nv.Add("@Branch_Code", Branch_Code);
            nv.Add("@Employee_Code", Employee_Code);
            nv.Add("@Agent_Code", Agent_Code);
            nv.Add("@Client_Code", Client_Code);
            nv.Add("@Folio_Number", Folio_Number);
            nv.Add("@Cheque_No", Cheque_No);
            nv.Add("@App_No", App_No);
            nv.Add("@Tbl", Tbl);
            nv.Add("@UserID", UserID);
            nv.Add("@PageNumber", "1");
            nv.Add("@PageSize", "20000");
            dsTrans = MethodObj.GetDataSet("[API_T_RFinalTransaction_Details]", nv);
            dsFinal = MethodTrObj.Transaction_Details(dsTrans);
            if (Type.ToLower() == "json")
            {
                Value = Newtonsoft.Json.JsonConvert.SerializeObject(dsTrans, Newtonsoft.Json.Formatting.Indented);
            }
            else if (Type.ToLower() == "xml")
            {
                Value = dsFinal.GetXml();
            }
            HttpContext.Current.Response.Write(Value);
            HttpContext.Current.Response.End();
        }
    }

}