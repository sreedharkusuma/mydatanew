﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SampleAPI.Controllers
{
    public class HomeController : Controller
    {
        [HttpPost]
        public bool AddEmpDetails(string pan)
        {
            return true;
            //write insert logic  

        }
        [HttpGet]
        public string GetEmpDetails()
        {
            return "Komal Patil";

        }
        [HttpDelete]
        public string DeleteEmpDetails(string id)
        {
            return "Employee details deleted having Id " + id;

        }
        [HttpPut]
        public string UpdateEmpDetails(string Name, String Id)
        {
            return "Employee details Updated with Name " + Name + " and Id " + Id;

        }
    }
}
