﻿#region ChangeRequest
/// Created By  : Komal Patil
/// Created On  : 17-Feb-2017
/// Created for : Added for 3 other's Transfer data through HTTP Services to another software and devices in JSON or XML format.
#endregion

using System;
using System.Web;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAPI.Models;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Data;
using System.IO;
using System.Xml;
using Microsoft.Ajax.Utilities;
using System.Data.SqlClient;
using System.Collections.Specialized;
using System.Configuration;
/// <ChangeManagement>
/// SrNo.   Modified By     Date        Given By    Task Detail
/// 1.      Komal Patil     17-Feb-2017 sam sir       Added API for Account_Statement_Foliowise report & others.          
/// </ChangeManagement>

namespace SampleAPI.Controllers
{
    public class MFBack1Controller : ApiController
    {
        Methods MethodObj = new Methods();
        TransMethod MethodTrObj = new TransMethod();
        DataSet dsTrans = null;
        DataSet dsFinal = null;
        string Value = "";
        DataTable dt = new DataTable();
        System.Collections.Specialized.NameValueCollection nv = new System.Collections.Specialized.NameValueCollection();

        //[HttpGet]
        //[Route("api/Account_Statement_Foliowise/{PAN}/{PRODUCTCODE}/{FOLIONO}/{Type}")]
        //public void Account_Statement_Foliowise(string PAN, string PRODUCTCODE, string FOLIONO, string Type)
        //[HttpPost()]
        //[Route("api/Account_Statement_Foliowise/{PAN}/{PRODUCTCODE}/{Type}/{*FOLIONO}")]
        //public void Account_Statement_Foliowise(string PAN, string PRODUCTCODE, string Type, string FOLIONO)
        //{
        //    try
        //    {
        //        nv.Add("@pan", PAN);
        //        nv.Add("@schemecode", PRODUCTCODE);
        //        nv.Add("@Folio_No", FOLIONO);
        //        dsTrans = MethodObj.GetDataSet("API_Account_Statement_FolioWise_client", nv);
        //        if (Type.ToLower() == "json")
        //        {
        //            Value = Newtonsoft.Json.JsonConvert.SerializeObject(dsTrans, Newtonsoft.Json.Formatting.Indented);

        //        }
        //        else if (Type.ToLower() == "xml")
        //        {
        //            Value = dsTrans.GetXml();
        //            DataSet ds = new DataSet();
        //            TextReader txtReader = new StringReader(Value);
        //            XmlReader reader = new XmlTextReader(txtReader);
        //            ds.ReadXml(reader);
        //        }
        //    }
        //    catch (Exception Ex)
        //    {
        //        throw Ex;
        //    }
        //    //return Ok(Value);
        //    HttpContext.Current.Response.Write(ObjEncDecrypt.EncryptTextBy_AES(Value));
        //    HttpContext.Current.Response.End();
        //}
       
        [HttpPost()]
        [Route("api/Client_ELSS_Maturity_Report/{PAN}/{On_Date}/{Opt}/{Type}")]
        public void Client_ELSS_Maturity_Report(string PAN, string On_Date, string Opt, string Type)
        {
            nv.Add("@pan", PAN);
            nv.Add("@Date_To", On_Date);
            nv.Add("@isMaturityInvest", Opt);
            dsTrans = MethodObj.GetDataSet("[API_Get_ClientELSSReport]", nv);
            dsFinal = MethodTrObj.Client_ELSS_Maturity_Report(dsTrans);
            dsFinal.Tables.Remove("Table");
            if (Type.ToLower() == "json")
            {
                Value = Newtonsoft.Json.JsonConvert.SerializeObject(dsFinal, Newtonsoft.Json.Formatting.Indented);
            }
            else if (Type.ToLower() == "xml")
            {
                Value = dsFinal.GetXml();
            }
            HttpContext.Current.Response.Write(Value);
            HttpContext.Current.Response.End();
        }

        [HttpPost()]
        [Route("api/get_loginDetails/{Username}/{Password}/{Type}")]
        public void get_loginDetails(string Username, string Password, string Type)
        {
            LoginDetails log = new LoginDetails();
            string ID;
            bool chk = log.GetLogin(Username, Password, out ID);
            if (chk)
            {
                try
                {
                    nv.Add("@ID", ID);
                    dsTrans = MethodObj.GetDataSet("API_Get_AgentDetails", nv);
                    if (dsTrans.Tables[0].Rows.Count > 0)
                    {
                        if (Type.ToLower() == "json")
                        {
                            Value = Newtonsoft.Json.JsonConvert.SerializeObject(dsTrans, Newtonsoft.Json.Formatting.Indented);

                        }
                        else if (Type.ToLower() == "xml")
                        {
                            Value = dsTrans.GetXml();
                            DataSet ds = new DataSet();
                            TextReader txtReader = new StringReader(Value);
                            XmlReader reader = new XmlTextReader(txtReader);
                            ds.ReadXml(reader);
                        }
                    }
                    else
                    {
                        Value = "{\"Table\" :[ {\"Result\":\"Invalid\"} ]}";
                    }
                }
                catch (Exception Ex)
                {
                    throw Ex;
                }
            }
            else
            {
                Value = "{\"Table\" :[ {\"Result\":\"Invalid\"} ]}";
            }
            HttpContext.Current.Response.Write(Value);
            HttpContext.Current.Response.End();
        }


        [HttpPost()]
        [Route("api/Transaction_Details/{FromDate}/{ToDate}/{AMC_Code}/{Scheme_Code}/{Trxn_Type}/{SubTrxn_Type}/{Broker_Code}/{Employee_Code}/{Agent_Code}/{Client_Code}/{Folio_Number}/{Cheque_No}/{App_No}/{Tbl}/{UserID}/{PageNumber}/{PageSize}/{Type}")]
        public void Transaction_Details(string FromDate, string ToDate, string AMC_Code, string Scheme_Code, string Trxn_Type, string SubTrxn_Type, string Broker_Code, string Branch_Code, string Employee_Code, string Agent_Code, string Client_Code, string Folio_Number, string Cheque_No,
            string App_No, string Tbl, string UserID, string PageNumber, string PageSize, string Type)
        {
            nv.Add("@FromDate", FromDate);
            nv.Add("@ToDate", ToDate);
            nv.Add("@AMC_Code", AMC_Code);
            nv.Add("@Scheme_Code", Scheme_Code);
            nv.Add("@Trxn_Type", Trxn_Type);
            nv.Add("@SubTrxn_Type", SubTrxn_Type);
            nv.Add("@Broker_Code", Broker_Code);
            nv.Add("@Employee_Code", Employee_Code);
            nv.Add("@Agent_Code", Agent_Code);
            nv.Add("@Client_Code", Client_Code);
            nv.Add("@Folio_Number", Folio_Number);
            nv.Add("@Cheque_No", Cheque_No);
            nv.Add("@App_No", App_No);
            nv.Add("@Tbl", Tbl);
            nv.Add("@UserID", UserID);
            nv.Add("@PageNumber", PageNumber);
            nv.Add("@PageSize", PageSize);
            dsTrans = MethodObj.GetDataSet("[API_T_RFinalTransaction_Details]", nv);
            dsFinal = MethodTrObj.Client_ELSS_Maturity_Report(dsTrans);
            dsFinal.Tables.Remove("Table");
            if (Type.ToLower() == "json")
            {
                Value = Newtonsoft.Json.JsonConvert.SerializeObject(dsFinal, Newtonsoft.Json.Formatting.Indented);
            }
            else if (Type.ToLower() == "xml")
            {
                Value = dsFinal.GetXml();
            }
            HttpContext.Current.Response.Write(Value);
            HttpContext.Current.Response.End();
        }
    }
}
