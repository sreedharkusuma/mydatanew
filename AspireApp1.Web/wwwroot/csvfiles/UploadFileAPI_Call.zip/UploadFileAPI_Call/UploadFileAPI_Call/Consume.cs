﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace UploadFileAPI_Call
{
    public class Consume
    {
        public string API_Url { get; set; }
        async Task<HttpResponseMessage> Upload(byte[] fileBytes, string projectname, string filename, string filenameUnique)
        {
            using (var httpClient = new HttpClient())
            {
                httpClient.Timeout = TimeSpan.FromMinutes(10);
                using (var request = new HttpRequestMessage(new HttpMethod("POST"), API_Url + @"/api/Upload/proceed"))
                {
                    var multipartContent = new MultipartFormDataContent();

                    //filenameUnique = filenameUnique.Substring(filenameUnique.Length - 8);
                    multipartContent.Add(new StringContent(projectname), "clientname");
                    multipartContent.Add(new StringContent(filenameUnique), "filename");
                    /*System.IO.Stream fs = File.OpenRead(pathFile);
                    System.IO.BinaryReader br = new System.IO.BinaryReader(fs);
                    Byte[] bytes = br.ReadBytes((Int32)fs.Length);*/
                    ByteArrayContent bac = new ByteArrayContent(fileBytes);
                    //oreach (var filename in pdfFiles)
                    {
                        multipartContent.Add(bac, "files", filename);
                    }
                    request.Content = multipartContent;

                    var response = await httpClient.SendAsync(request);
                    return response;
                }
            }
            return null;
        }
        public bool isUpload(byte[] fileBytes, string projectName, string filename, string filenameUnique)
        {
            try
            {
                //string filenameUnique = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss.fff", System.Globalization.CultureInfo.InvariantCulture).Replace("-", "").Replace(":", "").Replace(".", "").Replace(" ", "");
                var result_ = Task.Run(async () => await Upload(fileBytes, projectName, filename, filenameUnique)).Result;
                string sss = "";
                if (result_.IsSuccessStatusCode)
                {
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        public bool CheckFileUploadOrNot(string projectName, string filename, string ext)
        {
            try
            {
                using (var client = new MyWebClient()) //WebClient  
                {
                    client.Headers.Add("Content-Type:application/json"); //Content-Type  
                    client.Headers.Add("Accept:application/json");
                    var result = client.DownloadString(API_Url + @"/api/Upload/checkfile/" + projectName + @"/" + filename + @"/" + ext);
                    if (result.ToLower() == "exists".ToLower())
                    {
                        return true;
                    }
                }
                return false;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        public bool SanitizeFile(string projectName, string filename, string ext)
        {
            try
            {
                using (var client = new MyWebClient()) //WebClient  
                {
                    client.Headers.Add("Content-Type:application/json"); //Content-Type  
                    client.Headers.Add("Accept:application/json");
                    var result = client.DownloadString(API_Url + @"/api/Upload/sanitizefile/" + projectName + @"/" + filename + @"/" + ext);
                    if (result.ToLower() == "valid".ToLower())
                    {
                        return true;
                    }
                }
                return false;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        public bool IsValidFile(byte[] fileBytes, string projectName, string filename, string ext)
        {
            try
            {
                if (isUpload(fileBytes, projectName, filename, ""))
                {
                    if (CheckFileUploadOrNot(projectName, filename, ext))
                    {
                        if (SanitizeFile(projectName, filename, ext))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        public bool IsCsvFile(byte[] fileBytes)
        {
            try
            {
                string mimeType = MimeSniffer.GetMime(fileBytes);
                if (mimeType.ToLower() == "text/plain")
                {
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}
