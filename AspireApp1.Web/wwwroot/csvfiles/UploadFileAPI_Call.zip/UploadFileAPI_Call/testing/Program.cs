﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UploadFileAPI_Call;

namespace testing
{
    class Program
    {
        static void Main(string[] args)
        {
            Consume consume = new Consume();
            //consume.API_Url =  @"http://10.20.50.2:229/";
            consume.API_Url = @"http://localhost:51348/";
            string filepath = @"D:\IMP_DATA\SREEDHARK\Profile\Desktop\R2A.dbf";
            System.IO.Stream fs = File.OpenRead(filepath);
            System.IO.BinaryReader br = new System.IO.BinaryReader(fs);
            Byte[] bytes = br.ReadBytes((Int32)fs.Length);
            bool isUploaded = false;
            bool isSuccessfullyUploaded = false;
            bool isValidFile = false;
            string filename=DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss.fff", System.Globalization.CultureInfo.InvariantCulture).Replace("-", "").Replace(":", "").Replace(".", "").Replace(" ", "");
            filename = filename.Substring(filename.Length - 8);
            isUploaded = consume.isUpload(bytes, "Base", Path.GetFileName(filepath), filename);
            if (isUploaded)
            {
                isSuccessfullyUploaded = consume.CheckFileUploadOrNot("Base", filename, Path.GetExtension(filepath).Replace(".", ""));
                if (isSuccessfullyUploaded)
                {
                    isValidFile = consume.SanitizeFile("Base", filename, Path.GetExtension(filepath).Replace(".", ""));
                }
            }
            Console.WriteLine("isUploaded : " + isUploaded);
            Console.WriteLine("isSuccessfullyUploaded : " + isSuccessfullyUploaded);
            Console.WriteLine("isValidFile : " + isValidFile);
            //Console.WriteLine(consume.IsValidFile(bytes, "Base", Path.GetFileName(filepath), Path.GetExtension(filepath).Replace(".", "")));
            Console.ReadKey();
        }
    }
}
